# encoding=utf8

import numpy as np


'''
函数功能：从预先训练分词文件中读取 预分词 信息用于 训练

         特别重要：
                     预分词的句子 一定要 和 用于训练 或者测试的句子 对应上， 否则出错！（训练的句子做了长度限制，开发和测试
                     对句子长度无限制）

'''


def prepareData_fromPreSegment(path):
    seqs, wlenss, idxss = [], [], []
    f = open(path,encoding="utf-8")

    for line in f.readlines():
        sent = line.strip().split()
        seqs.append(list(''.join(sent[:])))
        wlenss.append([len(word) for word in sent])

    f.close()

    for wlens in wlenss:
        idxss.append(SMEB(wlens))

    return seqs, wlenss, idxss

def SMEB(lens):
    idxs = []
    for len in lens:
        for i in range(len - 1):
            idxs.append(0)
        idxs.append(len)
    return idxs

'''
函数功能：把一个 batch 的 预 分词信息变成 4维 向量
参数说明：
          PresegTags，一个batch，一行 一个 句子，每个句子经过 无监督 统计分词
          
返回值：一个三维张量：[PresegTags.shape[0], PresegTags.shape[1], 4]
'''
def generatePresegInfo( PresegTags ):

    sentsPos = 0
    A= np.zeros((PresegTags.shape[0], PresegTags.shape[1], 4))

    for sents in PresegTags:
        for indx, value in enumerate(sents):
            if indx ==0 and value == 0:
                A[sentsPos][indx][:] = np.asarray((1, 0, 0, 0)) # 'B'
            elif indx > 0 and value==0 and sents[indx-1] > 0:
                A[sentsPos][indx][:] = np.asarray((1, 0, 0, 0))  # 'B'
            elif indx > 0 and value == 0 and sents[indx-1] == 0:
                A[sentsPos][indx][:] = np.asarray((0, 1, 0, 0)) # 'M'
            elif value >= 2:
                A[sentsPos][indx][:] = np.asarray((0, 0, 1, 0))  # 'E'
            elif value == 1:
                A[sentsPos][indx][:] = np.asarray((0, 0, 0, 1))  # 'S'
            else:
                A[sentsPos][indx][:] = np.asarray((-1, -1, -1, -1))  # 其他情况

        sentsPos+=1

    return A

'''
函数功能： 把形如“00300310202...” 的分词信息转换成"12312341313..."
          约定：采用BMES标签，B=1，M=2，E=3，S=4
参数说明：preseginfoLst，包含分词信息的List

返回值：长度和输入相同的 List
'''
def getTagFromList( preseginfoLst ):

    tags = []

    for indx, value in enumerate(preseginfoLst):
        if indx == 0 and value == 0:
            tags.append(1)  # 'B'
        elif indx > 0 and value == 0 and preseginfoLst[indx - 1] > 0:
            tags.append(1)  # 'B'
        elif indx > 0 and value == 0 and preseginfoLst[indx - 1] == 0:
            tags.append(2)   # 'M'
        elif value >= 2:
            tags.append(3)   # 'E'
        elif value == 1:
            tags.append(4)  # 'S'
        else:
            tags.append(0)  # 其他情况

    return tags


def convertTag_to_TagIndex( preseginfoLst ):

    tags = []

    for indx, value in enumerate(preseginfoLst):
        if value == 'B':
            tags.append(1)  # 'B'
        elif value == 'M':
            tags.append(2)   # 'M'
        elif value == 'E':
            tags.append(3)   # 'E'
        elif value == 'S':
            tags.append(4)  # 'S'
        else:
            tags.append(0)  # 其他情况

    return tags



'''
函数功能： 把一个 batch 的 tag list 变成 一个 多重嵌套 list
参数说明：  batchpresegTags， 二重 list， 
           第一重： batch 的句子 级别
           第二重： 一个句子中的 字符的 tag
           
返回值： 三重 list
         第一重：batch 的句子级别
         第二重：一个句子的字符
         第三重：preTag 对应的 list
'''
def convertTags2List(batchpresegTags):

    batchLst=[]

    for tagLine in batchpresegTags:
        LineTagLst=[]
        for tag in tagLine:
            if tag == 1:
                LineTagLst.append([1, 0, 0, 0])  # B
            elif tag == 2:
                LineTagLst.append([0, 1, 0, 0])  # M
            elif tag == 3:
                LineTagLst.append([0, 0, 1, 0])  # E
            elif tag == 4:
                LineTagLst.append([0, 0, 0, 1])  # S
            else:
                LineTagLst.append([0, 0, 0, 0])  # 全是 0

        batchLst.append(LineTagLst)

    return  batchLst