# coding=utf-8

import re

'''
函数功能：加载标准（golden）、和 统计预训练分词文件
参数说明：sFilepathName ，文件名
返回值：
        x: (句子维度，词 维度)
        y：（句子维度，词维度）
        z：（句子维度，词维度，字符维度）

'''


def load_golden_segment(sFilepathName):
    f = open(sFilepathName, 'r', encoding='utf8')
    lst = []

    sents = []
    tagLst = []

    sents_char = []
    chars_in_word = []

    for line in f:
        if line.strip() == "" or "////////" in line:
            if len(sents) > 0 and len(tagLst) > 0:
                lst.append((sents, tagLst, sents_char))
                sents = []  # 开始 下一句
                tagLst = []  # 开始 下一句
                sents_char = []  # 下一句

        else:
            word, tag = parse_line(line)
            sents.append(word.lower())
            tagLst.append(tag)

            chars_in_word = []
            for ch in word.lower():
                chars_in_word.append(ch)

            sents_char.append(chars_in_word)

    if len(sents) > 0 and len(tagLst) > 0:
        lst.append((sents, tagLst, chars_in_word))

    x = []
    y = []
    z = []

    for i in range(len(lst)):
        x.append(lst[i][0])
        y.append(lst[i][1])
        z.append(lst[i][2])

    return x, y, z


'''
函数功能：加载 词性 标注
'''


def load_POS(sFilepathName):
    f = open(sFilepathName, 'r', encoding='utf8')
    lst = []

    sents = []
    tagLst = []

    for line in f:
        if line.strip() == "" or "////////" in line:
            if len(sents) > 0 and len(tagLst) > 0:
                lst.append((sents, tagLst))
                sents = []  # 开始 下一句
                tagLst = []  # 开始 下一句


        else:
            word, tag = parse_line(line)
            sents.append(word.lower())
            tagLst.append(tag)

    if len(sents) > 0 and len(tagLst) > 0:
        lst.append((sents, tagLst))

    x = []
    y = []

    for i in range(len(lst)):
        x.append(lst[i][0])
        y.append(lst[i][1])

    return x, y


'''
函数功能：把一个 形如：“quê B”的 字符串 解析成 “quê” 和“B”，并返回
参数说明：sLine, 一个字符串
返回值：单词和 标签，如 “quê” ，“B”
'''


def parse_line(sLine):
    sLine = sLine.strip()
    res = sLine.split()

    if not res or len(res) != 2:
        raise Exception("Error! 发生了 错误！！")
    else:
        return res[0], res[1]


'''
函数功能：解析字典行，即把一个 形如：“một:7,2136490”的 字符串 解析成 “một” ，并返回
参数说明：sLine, 一个字符串
返回值：单词，如 “một”,词序，词频
'''


def parse_dictionary_line(sLine):
    sLine = sLine.strip()

    res = re.split(r"[:,]", sLine)

    if not res or len(res) != 3:
        raise Exception("Error! 发生了 错误！！")
    else:
        return res[0], res[1], res[2]


'''
函数功能：加载 字典，方便 单词到索引的检索，以及索引到单词的检索
参数说明: sFilepathName，字典的文件名
返回值：单词到索引的映射，索引到单词的映射
    特  别 注  意：第0个元素 保留，留给OOV或者 长度对齐时补零
'''


def load_dictionary(sFilepathName):
    f = open(sFilepathName, 'r', encoding='utf8')
    lst = []

    dic_word2index = {}
    dic_index2word = {}

    dic_word2index['OOOV'] = 1
    dic_index2word[1] = 'OOOV'
    index = 2
    '''
        for line in f:
            if line.strip() != "":
                word, nouse1, nouse2 = parse_dictionary_line(line)
                dic_word2index[word] = index
                dic_index2word[index] = word
                index = index + 1
    '''

    # 文件结构发生了 变化，直接存，不解析了
    for line in f:
        word = line.strip()
        if word != "":
            dic_word2index[word] = index
            dic_index2word[index] = word
            index = index + 1

    return dic_word2index, dic_index2word


'''
函数功能：加载 字典，方便 字符到索引的检索，以及索引到字符的检索
参数说明: sFilepathName，字典的文件名
返回值：字符到索引的映射，索引到字符的映射
    特  别 注  意：第0个元素 保留，留给OOch或者 长度对齐时补零
'''


def load_char_dictionary(sFilepathName):
    f = open(sFilepathName, 'r', encoding='utf8')
    lst = []

    dic_char2index = {}
    dic_index2char = {}

    dic_char2index['OOOch'] = 1
    dic_index2char[1] = 'OOOch'
    index = 2

    # 文件结构发生了 变化，直接存，不解析了
    for line in f:
        word = line.strip()
        if word != "":
            dic_char2index[word] = index
            dic_index2char[index] = word
            index = index + 1

    return dic_char2index, dic_index2char


def get_indice_for_input(x, dic_word2index):
    lst = []

    for sents in x:
        s = []
        for word in sents:
            if word in dic_word2index.keys():
                s.append(dic_word2index[word])
            else:
                s.append(1)  # 索引 1 的位置 是 OOV
        lst.append(s)

    return lst


'''
函数功能：把输入的 字符 序列 转换为 索引
参数说明:x，输入，一般是3重列表，第一维是 句子数，第二维 是句子长度，第三维 是 字符长度
         dic_char2index, 字符到索引的映射 

         特别提示：索引 1 的位置 是 OOV

返回值：索引，结构同 x

'''


def get_char_indice_for_input(chars, dic_char2index):
    lst = []
    max_word_len = -10000

    for sents in chars:  # 句子 级别，句子1 句子2 句子3
        s = []
        for word in sents:  # 词级别，词1 词2 词3
            chs = []
            for ch in word:  # 字符级别
                if ch in dic_char2index.keys():
                    chs.append(dic_char2index[ch])
                else:
                    chs.append(1)  # 索引 1 的位置 是 OOV
            s.append(chs)

            if len(word) > max_word_len:
                max_word_len = len(word)

        lst.append(s)

    for sent in lst:
        for word in sent:
            if len(word) < max_word_len:
                for k in range(max_word_len - len(word)):
                    word.append(0)

    return lst


'''
函数功能：把输入的 字符 序列 转换为 索引, 并用 0 补够足够的 长度
参数说明:x，输入，一般是3重列表，第一维是 句子数，第二维 是句子长度，第三维 是 字符长度
         dic_char2index, 字符到索引的映射 

         特别提示：索引 1 的位置 是 OOV

返回值：索引，结构同 x

'''


def get_char_indice_for_input_MaxLen(chars, dic_char2index, maxLen):
    lst = []

    for sents in chars:  # 句子 级别，句子1 句子2 句子3
        s = []
        for word in sents:  # 词级别，词1 词2 词3
            chs = []
            for ch in word:  # 字符级别
                if ch in dic_char2index.keys():
                    chs.append(dic_char2index[ch])
                else:
                    chs.append(1)  # 索引 1 的位置 是 OOV
            s.append(chs)
        lst.append(s)

    for sent in lst:
        for word in sent:
            if len(word) < maxLen:
                for k in range(maxLen - len(word)):
                    word.append(0)

    return lst


'''
函数功能：把标签 'B','M','E','S' 转换为 one-hot 向量
参数说明:output, 二重列表，第一维，句子数，第二维，句子单词对应的标签

返回值：三重列表，最后一维是 标签 的 one-hot 向量
'''


def get_one_hot_of_y(output):
    lst = []

    for tagLst in output:
        s = []
        for t in tagLst:
            if t == 'B':
                s.append([1.0, 0.0, 0.0, 0.0])
            elif t == 'M':
                s.append([0.0, 1.0, 0.0, 0.0])
            elif t == 'E':
                s.append([0.0, 0.0, 1.0, 0.0])
            else:
                s.append([0.0, 0.0, 0.0, 1.0])
        lst.append(s)

    return lst


'''
函数功能：把标签 'B','M','E','S' 转换为 标签索引 值
参数说明:output, 二重列表，第一维，句子数，第二维，句子单词对应的标签

返回值：2重列表，第一维，句子数，第二维，标签对应的索引
'''


def get_tag_indics_of_y(output):
    lst = []

    for tagLst in output:
        s = []
        for t in tagLst:
            if t == 'B':
                s.append(0)  # 从1 开始， 0 保留给 pad_sequence 用
            elif t == 'M':
                s.append(1)
            elif t == 'E':
                s.append(2)
            else:
                s.append(3)
        lst.append(s)

    return lst


'''
函数功能：把标签 'B_*','M_*','E_*','S*' 转换为 标签索引 值
参数说明:output, 二重列表，第一维，句子数，第二维，句子单词对应的标签

返回值：2重列表，第一维，句子数，第二维，标签对应的索引
'''


def get_tag_indics_of_POS(output, posTags2index):
    lst = []

    for tagLst in output:
        s = []
        for t in tagLst:
            s.append(posTags2index[t])  # 直接从  映射里面 查找 即可

        lst.append(s)

    return lst
