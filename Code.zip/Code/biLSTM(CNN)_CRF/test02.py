# coding=utf-8
import tensorflow as tf2
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Dense, LSTM, Dropout
from common_fun import load_golden_segment
from common_fun import parse_line
import numpy as np

data = np.array([[1,2,3],[1,2],[3,4,5,6]])
data = keras.preprocessing.sequence.pad_sequences(data,maxlen=3,padding='post',truncating='post',value=0)
print("data is ：\n")
print(data)

data_emb_mask = layers.Embedding(1000, 4, input_length=4, mask_zero=True)(data)

lstmout = layers.LSTM(units=4, return_sequences=True)(data_emb_mask)

print("Lstm out:\n")
print(lstmout)




