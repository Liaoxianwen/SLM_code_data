# coding=utf-8

import tensorflow as tf
from tensorflow.keras.layers import Layer, Dense, LSTM, Embedding, TimeDistributed
from tensorflow.keras.preprocessing.sequence import pad_sequences
import tensorflow_addons as tf_ad
from tensorflow.keras import Model
import numpy as np

'''
类说明：实现 CRF 层
注意：原来 CRF 是继承了 keras.Layer，但是有报道说，这样的实现存在 梯度不能更新的 bug，但是 继承model却没有这样的问题

    特 别 注意：调用 crf_log_likelihood 计算序列的极大似然值时，labels 存储的是标签的索引值，索引一定要 从 0 开始，重复2遍。

'''

wordSegTag = {0: 'B', 1: 'M', 2: 'E', 3: 'S'}
posTags = ['NOUN', 'ADP', 'X', 'VERB', 'ADJ', 'PUNCT', 'SCONJ', 'NUM', 'DET', 'CCONJ', 'PROPN', 'AUX', 'PART', 'INTJ']

posTags2index = {}
posindex2tags = {}
posTagFlag = {}

for i in range(len(posTags)):
    posTags2index['B_' + posTags[i]] = i * 4 + 0
    posTags2index['M_' + posTags[i]] = i * 4 + 1
    posTags2index['E_' + posTags[i]] = i * 4 + 2
    posTags2index['S_' + posTags[i]] = i * 4 + 3
    posindex2tags[i * 4 + 0] = 'B_' + posTags[i]
    posindex2tags[i * 4 + 1] = 'M_' + posTags[i]
    posindex2tags[i * 4 + 2] = 'E_' + posTags[i]
    posindex2tags[i * 4 + 3] = 'S_' + posTags[i]
    posTagFlag[posTags[i]] = i * 100

# 再 添加 ERR 标签
posTags2index['S_ERR'] = len(posTags2index)
posindex2tags[len(posindex2tags)] = 'S_ERR'  # 记得一定要加 一个 前缀
posTagFlag['ERR'] = len(posTags) * 100  # 不用 加 前缀

### ----------   NER  的 标签 -----------------------------###

ner_Tags = ['PER', 'LOC', 'ORG', 'O']  # O 只用到 S_O，没有用到 B_O,M_O,E_O,
ner_Tags2index = {}
ner_index2Tags = {}
ner_TagFlag = {}
ner_Tag2Flag = {}

for i in range(len(ner_Tags)):
    ner_Tags2index['B_' + ner_Tags[i]] = i * 4 + 0
    ner_Tags2index['M_' + ner_Tags[i]] = i * 4 + 1
    ner_Tags2index['E_' + ner_Tags[i]] = i * 4 + 2
    ner_Tags2index['S_' + ner_Tags[i]] = i * 4 + 3
    ner_index2Tags[i * 4 + 0] = 'B_' + ner_Tags[i]
    ner_index2Tags[i * 4 + 1] = 'M_' + ner_Tags[i]
    ner_index2Tags[i * 4 + 2] = 'E_' + ner_Tags[i]
    ner_index2Tags[i * 4 + 3] = 'S_' + ner_Tags[i]
    ner_TagFlag[ ner_Tags[i]] = i * 100
    ner_Tag2Flag[ner_Tags[i]] = i * 100

# 再 添加 ERR 标签
ner_Tags2index['S_ERR'] = len(ner_Tags2index)
ner_index2Tags[len(ner_index2Tags)] = 'S_ERR'  # 记得一定要加 一个 前缀
ner_TagFlag['ERR'] = len(ner_Tags) * 100  # 不用 加 前缀
ner_Tag2Flag['ERR'] = len(ner_Tags) * 100


class CRF(Model):

    def __init__(self, Num_of_Labels, **kwargs):
        super(CRF, self).__init__(**kwargs)
        self.Num_of_Labels = Num_of_Labels
        self.dense = Dense(Num_of_Labels, use_bias=True)  # 不加 激活函数看看怎么样
        # self.supports_masking = True
        self.transition_params = tf.Variable(initial_value=tf.random.uniform(shape=(Num_of_Labels, Num_of_Labels)),
                                             trainable=True)

    '''
    函数功能：实现 调用 函数。
    参数说明：inputs，Lstm/Bi-lstm输出。
             text_lens,真实的序列长度
             labels，真实的标签
             training，是否是训练模式
    返回值：见return，训练模式和预测模式 不同
    '''

    def call(self, inputs, text_lens, labels=None, training=None):

        logits = self.dense(inputs)
        if labels is not None:
            log_likelihood, self.transition_params = tf_ad.text.crf_log_likelihood(
                # labels 存储的是标签的索引值，索引一定要 从 0 开始，重复2遍。
                logits, labels, text_lens, transition_params=self.transition_params)
            return logits, text_lens, log_likelihood
        else:
            return logits, text_lens


''' 继承 Layer 需要重写 下面的函数
    def get_config(self):
        config = {
            'Num_of_Labels': self.Num_of_Labels,
            'transition_params': self.transition_params

        }
        base_config = super(CRF, self).get_config()
        dense_config = self.dense.get_config()  # dense是一个对象，要这样来搞才行的

        return dict(list(base_config.items()) + list(config.items()) + list(dense_config.items()))
'''


class CharCNN(Layer):

    def __init__(self, filters, kernel_size, max_word_len, channels=1, **kwargs):  # 对于字符 embeding 序列，通道数 为 1
        super(CharCNN, self).__init__(**kwargs)
        self.filters = filters
        self.kernel_size = kernel_size
        self.channels = channels
        self.max_word_len = max_word_len
        # self.kernel = tf.Variable(initial_value=tf.random.uniform(shape=(kernel_size, channels, filters)), trainable=True)
        self.conv1d = tf.keras.layers.Conv1D(filters=filters,
                                             kernel_size=kernel_size,
                                             strides=1, activation=None, use_bias=True, padding='same',
                                             trainable=True)
        # self.maxpool = tf.keras.layers.MaxPool1D(pool_size=max_word_len-kernel_size+1)

    '''
    函数功能：实现 卷积 和 maxpooling
    参数说明：inputs，一个单词的 字符 嵌入 序列 。（batchsize，max_word_len, embeding_size）
             training，是否是训练模式，没有用
    返回值：见return，训练模式和预测模式 不同
    '''

    def call(self, inputs, training=None):
        # conv1d = tf.nn.conv1d(input=inputs, filters=self.kernel, stride=1, padding='VALID')
        conv1d = self.conv1d(inputs)
        # maxp = self.maxpool(conv1d)

        return conv1d

    #  继承 Layer 需要重写 下面的函数
    def get_config(self):
        config = {
            'filters': self.filters,
            'kernel_size': self.kernel_size,
            'channels': self.channels,
            'max_word_len': self.max_word_len
        }
        base_config = super(CharCNN, self).get_config()
        # dense_config = self.dense.get_config()  # dense是一个 层 对象，要这样来搞才行的
        conv1d_config = self.conv1d.get_config()
        # maxpoo_config = self.maxpool.get_config()

        return dict(list(base_config.items()) + list(config.items()) + list(conv1d_config.items()))


'''
类说明：LSTM CRF 模型的实现
'''


class LSTM_CRF(Model):

    def __init__(self, lstm_unit, embeding_weights, label_size, embedding_size, max_sents_len, char_table_size,
                 char_embeding_size, max_word_len):
        super(LSTM_CRF, self).__init__()
        self.num_hidden = lstm_unit
        self.vocab_size = len(embeding_weights)
        self.label_size = label_size
        self.char_table_size = char_table_size
        self.char_embeding_size = char_embeding_size
        self.max_word_len = max_word_len

        self.embedding = Embedding(input_dim=self.vocab_size,  # 把 OOV 加回来
                                   output_dim=embedding_size,
                                   weights=[embeding_weights],
                                   input_length=max_sents_len,
                                   trainable=True,
                                   mask_zero=True
                                   )

        char_embeding_weight = self.get_char_embeding_weights(char_table_size,
                                                              char_embeding_size)  # 为了 安全起见，自己构造 weight

        self.char_embedding = Embedding(input_dim=len(char_embeding_weight),  # 把 OOV 加回来
                                        output_dim=self.char_embeding_size,
                                        weights=[char_embeding_weight],
                                        input_length=self.max_word_len,
                                        trainable=True,
                                        mask_zero=True
                                        )

        #self.lstm = tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(lstm_unit, return_sequences=True))
        self.lstm = LSTM(lstm_unit, return_sequences=True)
        self.dropout = tf.keras.layers.Dropout(0.3)
        self.crf = CRF(label_size)

        #  注意了 这里 好像发现了一个 bug：dropout 和 recurrent_dropout，如果用默认值0，会被当做int 报错，故传递一个很小的数给它
        self.chars_lstm = tf.keras.layers.Bidirectional(
            tf.keras.layers.LSTM(15, return_sequences=False, dropout=0.01, recurrent_dropout=0.01))

        self.timedistributed = TimeDistributed(self.chars_lstm, dtype=tf.float32)

    '''
    函数功能：随机初始化 char Embeding 层的 embeding 矩阵。因为要保证 第 0 个元素是0向量，所以不能用随机初始化，
              随机初始化 不能 保证 第0个元素为 0 向量，这可能 使得 mask=True 不起作用，
              所以还是保险起见，自己构造初始化 embeding 矩阵
    
    参数说明：char_table_size，字符表的大小，不包括保留的第0个元素
             char_embeding_size，嵌入向量的 大小
             
    返回值：Embeding weight 矩阵
    
    '''

    def get_char_embeding_weights(self, char_table_size, char_embeding_size):
        weight_matrix = np.zeros((char_table_size + 1, char_embeding_size), dtype=np.float32)  # 第 0 个 保留，所以要加1

        for i in range(1, char_table_size + 1):
            weight_matrix[i] = np.random.uniform(-3, 3, char_embeding_size)  # 随机填充

        return weight_matrix

    def call(self, text, labels=None, x_chars=None, training=None, preSeg=None):

        charemb = None

        if self.chars_lstm is not None:
            if x_chars is not None:
                x_chars = tf.cast(x_chars, dtype=tf.float32)
                charsEmb = self.char_embedding(x_chars)
                charemb = self.timedistributed(charsEmb)

        inputs1 = self.embedding(text)

        if charemb is not None:
            inputs1 = tf.concat([inputs1, charemb], axis=-1)

        inputs1 = self.dropout(inputs1, training)

        if preSeg is not None:
            preSeg = tf.cast(preSeg, dtype=tf.float32)
            inputs1 = tf.concat([inputs1, preSeg], axis=-1)

        Masking = self.embedding.compute_mask(text)
        actual_sequence_len = tf.reduce_sum(tf.cast(Masking, dtype=tf.int32), axis=-1)
        lstmout = self.lstm(inputs1)

        return self.crf(lstmout, actual_sequence_len, labels)


'''
类说明：CNN LSTM CRF 模型的实现
'''


class CNN_LSTM_CRF(Model):

    def __init__(self, lstm_unit, embeding_weights, label_size, embedding_size, max_sents_len, char_table_size,
                 char_embeding_size, max_word_len, filters, kernel_size, channels=1):
        super(CNN_LSTM_CRF, self).__init__()
        self.num_hidden = lstm_unit
        self.vocab_size = len(embeding_weights)
        self.label_size = label_size
        self.char_table_size = char_table_size
        self.char_embeding_size = char_embeding_size
        self.max_word_len = max_word_len

        self.embedding = Embedding(input_dim=self.vocab_size,  # 把 OOV 加回来
                                   output_dim=embedding_size,
                                   weights=[embeding_weights],
                                   input_length=max_sents_len,
                                   trainable=True,
                                   mask_zero=True
                                   )

        char_embeding_weight = self.get_char_embeding_weights(char_table_size,
                                                              char_embeding_size)  # 为了 安全起见，自己构造 weight

        self.char_embedding = Embedding(input_dim=len(char_embeding_weight),  # 把 OOV 加回来
                                        output_dim=self.char_embeding_size,
                                        weights=[char_embeding_weight],
                                        input_length=self.max_word_len,
                                        trainable=True,
                                        mask_zero=True
                                        )

        self.lstm = tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(lstm_unit, return_sequences=True))
        # self.lstm = LSTM(lstm_unit, return_sequences=True)
        self.dropout = tf.keras.layers.Dropout(0.3)
        self.crf = CRF(label_size)

        #  注意了 这里 好像发现了一个 bug：dropout 和 recurrent_dropout，如果用默认值0，会被当做int 报错，故传递一个很小的数给它
        # self.chars_lstm = tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(15, return_sequences=False, dropout=0.01, recurrent_dropout=0.01))

        self.char_cnn = CharCNN(filters, kernel_size, max_word_len, channels=channels)

        self.timedistributed = TimeDistributed(self.char_cnn, dtype=tf.float32)

        self.maxpool = tf.keras.layers.MaxPool1D(pool_size=max_word_len, strides=1)
        self.maxpool.supports_masking = True

        self.timedistbMaxpool = TimeDistributed(self.maxpool, dtype=tf.float32)
        # self.timedistbMaxpool.supports_masking = False

    '''
    函数功能：随机初始化 char Embeding 层的 embeding 矩阵。因为要保证 第 0 个元素是0向量，所以不能用随机初始化，
              随机初始化 不能 保证 第0个元素为 0 向量，这可能 使得 mask=True 不起作用，
              所以还是保险起见，自己构造初始化 embeding 矩阵

    参数说明：char_table_size，字符表的大小，不包括保留的第0个元素
             char_embeding_size，嵌入向量的 大小

    返回值：Embeding weight 矩阵

    '''

    def get_char_embeding_weights(self, char_table_size, char_embeding_size):
        weight_matrix = np.zeros((char_table_size + 1, char_embeding_size), dtype=np.float32)  # 第 0 个 保留，所以要加1

        for i in range(1, char_table_size + 1):
            weight_matrix[i] = np.random.uniform(-3, 3, char_embeding_size)  # 随机填充

        return weight_matrix

    def call(self, text, labels=None, x_chars=None, training=None, preSeg=None):

        charemb = None

        if self.char_cnn is not None:
            if x_chars is not None:
                x_chars = tf.cast(x_chars, dtype=tf.float32)
                charsEmb = self.char_embedding(x_chars)
                batchsz = charsEmb.shape[0]
                sentlen = charsEmb.shape[1]
                charemb = self.timedistributed(charsEmb)

                charemb = self.timedistbMaxpool(charemb)

                features = charemb.shape[-1]

                charemb = tf.reshape(charemb, shape=(batchsz, sentlen, features))

        inputs1 = self.embedding(text)

        if charemb is not None:
            inputs1 = tf.concat([inputs1, charemb], axis=-1)

        inputs1 = self.dropout(inputs1, training)

        if preSeg is not None:
            preSeg = tf.cast(preSeg, dtype=tf.float32)
            inputs1 = tf.concat([inputs1, preSeg], axis=-1)

        Masking = self.embedding.compute_mask(text)
        actual_sequence_len = tf.reduce_sum(tf.cast(Masking, dtype=tf.int32), axis=-1)
        lstmout = self.lstm(inputs1)

        return self.crf(lstmout, actual_sequence_len, labels)


'''
函数 功能：对模型进行 一个 batch 的 训练
参数说明：x_batch，一个batch的句子
          y_batch，一个batch的句子对应的标签
          model，模型
          optimizer，优化器
          
返回值: loss，模型的损失
        logits，crf的输入
        text_lens，句子的实际长度（去掉 pad）
'''


def train_one_step(x_batch, y_batch, y_pre, x_chars, model, optimizer):
    with tf.GradientTape() as tape:
        logits, text_lens, log_likelihood = model(x_batch, y_batch, x_chars, training=True, preSeg=y_pre)
        loss = - tf.reduce_mean(log_likelihood)
        gradients = tape.gradient(loss, model.trainable_variables)
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))
    return loss, logits, text_lens


'''
函数 功能：进行预测
参数说明：x_batch，一个batch的句子
          y_batch,真实标签
          y_pre，预分词标签
          model，模型

返回值: P，精确度
        R，召回率
        F，F值
'''


def predict(x_batch, y_batch, y_pre, model, x_chars=None):
    P = 0
    R = 0
    F = 0

    paths = []

    golden_word_num = 0
    pred_word_num = 0
    correct_word_num = 0

    logits, text_lens = model(x_batch, None, x_chars=x_chars, training=False, preSeg=y_pre)

    for logit, text_len, labels in zip(logits, text_lens, y_batch):
        viterbi_path, _ = tf_ad.text.viterbi_decode(logit[:text_len], model.crf.transition_params)

        true_label = labels[:text_len]
        viterbi_path = correct_the_tagList(viterbi_path)

        golden_word_num += get_seg_word_num(true_label)
        pred_word_num += get_seg_word_num(viterbi_path)
        correct_word_num += get_correct_word_num(true_label, viterbi_path)

    P = correct_word_num / pred_word_num
    R = correct_word_num / golden_word_num
    F = (2 * P * R) / (P + R)

    return P, R, F


'''
函数 功能：进行预测
参数说明：x_batch，一个batch的句子
          y_batch,真实标签
          y_pre，预分词标签
          model，模型

返回值: P，精确度
        R，召回率
        F，F值
'''


def predict_POS(x_batch, y_batch, y_pre, model, x_chars=None):
    P = 0
    R = 0
    F = 0

    golden_pos_num = 0
    pred_pos_num = 0
    correct_pos_num = 0

    logits, text_lens = model(x_batch, None, x_chars=x_chars, training=False, preSeg=y_pre)

    for logit, text_len, labels in zip(logits, text_lens, y_batch):
        viterbi_path, _ = tf_ad.text.viterbi_decode(logit[:text_len], model.crf.transition_params)

        true_label = labels[:text_len]
        viterbi_path = correct_the_POSTag(viterbi_path)

        golden_pos_num += get_POS_tags_num(true_label)
        pred_pos_num += get_POS_tags_num(viterbi_path)
        correct_pos_num += get_correct_POS_num(true_label, viterbi_path)

    P = correct_pos_num / pred_pos_num
    R = correct_pos_num / golden_pos_num
    F = (2 * P * R) / (P + R)

    return P, R, F


def predict_NER(x_batch, y_batch, y_pre, model, x_chars=None):

    golden_ner_num = 0
    pred_ner_num = 0
    correct_ner_num = 0

    correct_PER = 1
    total_PER = 1
    pred_PER = 1

    correct_ORG = 1
    total_ORG = 1
    pred_ORG = 1

    correct_LOC = 1
    total_LOC = 1
    pred_LOC = 1

    epsilion = 0.000001


    logits, text_lens = model(x_batch, None, x_chars=x_chars, training=False, preSeg=y_pre)

    for logit, text_len, labels in zip(logits, text_lens, y_batch):
        viterbi_path, _ = tf_ad.text.viterbi_decode(logit[:text_len], model.crf.transition_params)

        true_label = labels[:text_len]
        viterbi_path = correct_the_NER_Tag(viterbi_path, ner_index2Tags, ner_Tags2index)

        golden_ner_num += get_NER_tags_num(true_label, ner_index2Tags)
        pred_ner_num += get_NER_tags_num(viterbi_path, ner_index2Tags)
        correct_ner_num += get_correct_NER_num(true_label, viterbi_path)

        total_PER += get_NER_tags_num_specific_Type(true_label, ner_index2Tags, 'PER')
        total_LOC += get_NER_tags_num_specific_Type(true_label, ner_index2Tags, 'LOC')
        total_ORG += get_NER_tags_num_specific_Type(true_label, ner_index2Tags, 'ORG')

        pred_PER  += get_NER_tags_num_specific_Type(viterbi_path, ner_index2Tags, 'PER')
        pred_LOC  += get_NER_tags_num_specific_Type(viterbi_path, ner_index2Tags, 'LOC')
        pred_ORG  += get_NER_tags_num_specific_Type(viterbi_path, ner_index2Tags, 'ORG')

        correct_PER += get_correct_NER_num_specific_Type(true_label, viterbi_path, 'PER')
        correct_LOC += get_correct_NER_num_specific_Type(true_label, viterbi_path, 'LOC')
        correct_ORG += get_correct_NER_num_specific_Type(true_label, viterbi_path, 'ORG')




    P = correct_ner_num / pred_ner_num
    R = correct_ner_num / golden_ner_num
    F = (2 * P * R) / (P + R)

    P_per = correct_PER / pred_PER + epsilion
    R_per = correct_PER / total_PER + epsilion
    F_per = (2 * P_per * R_per)/(P_per + R_per)

    P_loc = correct_LOC / pred_LOC + epsilion
    R_loc = correct_LOC / total_LOC + epsilion
    F_loc = (2 * P_loc * R_loc)/(P_loc + R_loc)

    P_org = correct_ORG / pred_ORG + epsilion
    R_org = correct_ORG / total_ORG + epsilion
    F_org = (2 * P_org * R_org)/(P_org + R_org)

    return P, R, F, P_per, R_per, F_per, P_loc, R_loc, F_loc, P_org, R_org, F_org


'''
函数功能：矫正预测序列中的错误标签。 比如 'B','S','M','B','S'... 存在很多不合理的标签，把这些错误的标签都改过来(用'S'去替换错误的标签)
         也就是如果一个分词标签 组合 错误，比如：'B','S','E','M','B' ,这些不合理的标签 都以 'S' 计。
         
         核心算法 包括 前向 和 后向 扫描, 时间 复杂度为 O(n)
         
参数说明：tagLst, 一个标签序列

返回值：一个正确的标签序列

'''


def correct_the_tagList(tagLst):
    if tagLst is None:
        return None

    sz = len(tagLst)

    if sz == 0:
        return tagLst

    if sz == 1:
        if wordSegTag[tagLst[0]] != 'S':
            tagLst[0] = 3

        return tagLst

    ## 前向 扫描 开始

    if not (wordSegTag[tagLst[0]] == 'B' or wordSegTag[tagLst[0]] == 'S'):
        tagLst[0] = 3

    pretag = wordSegTag[tagLst[0]]

    for i in range(1, sz):
        currTag = wordSegTag[tagLst[i]]

        if pretag == 'B':
            if not (currTag == 'M' or currTag == 'E'):  # B->M,E
                tagLst[i] = 3
        elif pretag == 'M':
            if not (currTag == 'M' or currTag == 'E'):  # M->M,E
                tagLst[i] = 3
        elif pretag == 'E':
            if not (currTag == 'B' or currTag == 'S'):  # E->B,S
                tagLst[i] = 3
        elif pretag == 'S':
            if not (currTag == 'S' or currTag == 'B'):  # S->B,S
                tagLst[i] = 3
        else:
            raise Exception("调用 is_the_tag_list_is_correct 时，标签 错误！！")

        # pretag = currTag tagLst[i]的值可能会发生变化，
        pretag = wordSegTag[tagLst[i]]

    # 前向扫描 结束
    # 后向扫描 开始
    sz = len(tagLst)
    if not (wordSegTag[tagLst[sz - 1]] == 'E' or wordSegTag[tagLst[sz - 1]] == 'S'):
        tagLst[sz - 1] = 3

    postTag = wordSegTag[tagLst[sz - 1]]

    for i in range(sz - 2, -1, -1):  # [start, step, stop) (不包括 stop)
        currTag = wordSegTag[tagLst[i]]

        if postTag == 'B':
            if not (currTag == 'E' or currTag == 'S'):  # E,S->B
                tagLst[i] = 3
        elif postTag == 'M':
            if not (currTag == 'B' or currTag == 'M'):  # B,M->M
                tagLst[i] = 3
        elif postTag == 'E':
            if not (currTag == 'B' or currTag == 'M'):  # B,M->E
                tagLst[i] = 3
        elif postTag == 'S':
            if not (currTag == 'S' or currTag == 'E'):  # S,E->S
                tagLst[i] = 3
        else:
            raise Exception("调用 is_the_tag_list_is_correct 时，标签 错误！！")

        postTag = wordSegTag[tagLst[i]]

    return tagLst


'''
函数功能：计算一个标准序列 的 分词数， 比如 'B','M','E' 这三个标签算一个词

参数说明：tagLst，标签序列（标签前后关系正确合理）

返回值：词（WSU）的数量

'''


def get_seg_word_num(tagLst):
    if tagLst is None:
        return 0

    sz = len(tagLst)

    if sz == 0:
        return 0

    if sz == 1:
        return 1

    wordcnt = 0

    for i in range(sz):
        if wordSegTag[tagLst[i]] == 'B' or wordSegTag[tagLst[i]] == 'S':
            wordcnt += 1

    return wordcnt


'''
函数功能：计算一个标准序列 的 词性标签数量， 比如 'B_ADJ','M_ADJ','E_ADJ' 这三个标签算一个词性标签

参数说明：tagLst，标签序列（标签前后关系正确合理）

返回值：词性标签（POS）的数量

'''


def get_POS_tags_num(tagLst):
    if tagLst is None:
        return 0

    sz = len(tagLst)

    if sz == 0:
        return 0

    if sz == 1:
        return 1

    pos_cnt = 0

    for i in range(sz):
        if is_B(posindex2tags[tagLst[i]]) or is_S(posindex2tags[tagLst[i]]):
            pos_cnt += 1

    return pos_cnt


def get_NER_tags_num(tagLst, posindex2tags):
    if tagLst is None:
        return 0

    sz = len(tagLst)

    if sz == 0:
        return 0

    if sz == 1:
        return 1

    pos_cnt = 0

    for i in range(sz):
        if is_B(posindex2tags[tagLst[i]]) or is_S(posindex2tags[tagLst[i]]):
            pos_cnt += 1

    return pos_cnt


def get_NER_tags_num_specific_Type(tagLst, posindex2tags, tagType):
    if tagLst is None:
        return 0

    sz = len(tagLst)

    if sz == 0:
        return 0

    if sz == 1:
        return 1

    pos_cnt = 0

    for i in range(sz):
        tag = posindex2tags[tagLst[i]]
        if (is_B(tag) or is_S(tag)) and (tag[2:] == tagType):
            pos_cnt += 1

    return pos_cnt


'''
函数功能：以真实标签序列为参考，获得预测标签序列 正确的分词数（获得两个序列相同的分词数量）

参数说明：trueTagLst, 真实的标签序列
          predTagLst, 预测的标签序列（原始标签序列经过矫正所得）
          
返回值：正确分词（WSU）的数量。
'''


def get_correct_word_num(trueTagLst, predTagLst):
    if trueTagLst is None or predTagLst is None:
        raise Exception("求正确的WSU分词数量时，有一个列表为 None！")

    if len(trueTagLst) == 0 or len(predTagLst) == 0:
        raise Exception("求正确的WSU分词数量时，有一个列表的长度为 0 ！")

    if len(trueTagLst) != len(predTagLst):
        raise Exception("求正确的WSU分词数量时，两个序列的长度 不相等 ！")

    sz = len(trueTagLst)

    trueLst_flag = get_WSU_Flag(trueTagLst)
    predLst_flag = get_WSU_Flag(predTagLst)

    corret_word_num = 0

    for i in range(sz):
        if trueLst_flag[i] == predLst_flag[i] and trueLst_flag[i] > 0:
            corret_word_num += 1

    return corret_word_num


'''
函数功能：以真实标签序列为参考，获得预测标签序列 正确的分词数（获得两个序列相同的分词数量）

参数说明：trueTagLst, 真实的标签序列
          predTagLst, 预测的标签序列（原始标签序列经过矫正所得）

返回值：正确词性标签（POS）的数量。
'''


def get_correct_POS_num(trueTagLst, predTagLst):
    if trueTagLst is None or predTagLst is None:
        raise Exception("求正确的POS数量时，有一个列表为 None！")

    if len(trueTagLst) == 0 or len(predTagLst) == 0:
        raise Exception("求正确的POS数量时，有一个列表的长度为 0 ！")

    if len(trueTagLst) != len(predTagLst):
        raise Exception("求正确的POS数量时，两个序列的长度 不相等 ！")

    sz = len(trueTagLst)

    trueLst_flag = get_POS_Flag(trueTagLst)
    predLst_flag = get_POS_Flag(predTagLst)

    corret_pos_num = 0

    for i in range(sz):
        if trueLst_flag[i] == predLst_flag[i] and trueLst_flag[i] > 0:
            corret_pos_num += 1

    return corret_pos_num


def get_correct_NER_num(trueTagLst, predTagLst):
    if trueTagLst is None or predTagLst is None:
        raise Exception("求正确的 NER 数量时，有一个列表为 None！")

    if len(trueTagLst) == 0 or len(predTagLst) == 0:
        raise Exception("求正确的 NER 数量时，有一个列表的长度为 0 ！")

    if len(trueTagLst) != len(predTagLst):
        raise Exception("求正确的 NER 数量时，两个序列的长度 不相等 ！")

    sz = len(trueTagLst)

    trueLst_flag = get_NER_Flag(trueTagLst, ner_index2Tags, ner_TagFlag)
    predLst_flag = get_NER_Flag(predTagLst, ner_index2Tags, ner_TagFlag)

    corret_pos_num = 0

    for i in range(sz):
        if trueLst_flag[i] == predLst_flag[i] and trueLst_flag[i] > 0:
            corret_pos_num += 1

    return corret_pos_num


def get_correct_NER_num_specific_Type(trueTagLst, predTagLst, Type):
    if trueTagLst is None or predTagLst is None:
        raise Exception("求正确的 NER 数量时，有一个列表为 None！")

    if len(trueTagLst) == 0 or len(predTagLst) == 0:
        raise Exception("求正确的 NER 数量时，有一个列表的长度为 0 ！")

    if len(trueTagLst) != len(predTagLst):
        raise Exception("求正确的 NER 数量时，两个序列的长度 不相等 ！")

    sz = len(trueTagLst)

    trueLst_flag = get_NER_Flag(trueTagLst, ner_index2Tags, ner_TagFlag)
    predLst_flag = get_NER_Flag(predTagLst, ner_index2Tags, ner_TagFlag)

    val = ner_Tag2Flag[Type]

    corret_num = 0

    for i in range(sz):
        if trueLst_flag[i] == predLst_flag[i] and trueLst_flag[i] > 0 and value_is_the_same_type(val, trueLst_flag[i]) :
            corret_num += 1

    return corret_num


'''
函数功能：获得一个 标签 序列的 WSU flag.
         例如一个标签序列： B M E S S B E B E S S B E
         对应的WSU_Flag为：0  0 3 1 1 0 2 0 2 1 1 0 2
         
参数说明: tagLst，标签序列 
 
返回值：WSU 标志 序列
'''


def get_WSU_Flag(tagLst):
    if tagLst is None:
        raise Exception("求序列的WSU 标志序列时，序列为 None！")

    if len(tagLst) == 0:
        raise Exception("求序列的WSU 标志序列时，序列长度为 0 ！")

    sz = len(tagLst)
    WSU_Flag = []
    wsu_len = 0

    for i in range(sz):
        if wordSegTag[tagLst[i]] == 'E' or wordSegTag[tagLst[i]] == 'S':
            wsu_len += 1
            WSU_Flag.append(wsu_len)
            wsu_len = 0
        else:
            WSU_Flag.append(0)
            wsu_len += 1

    return WSU_Flag


'''
函数功能：获得一个 标签 序列的 pos flag.
         例如一个标签序列： B_ADJ M_ADJ E_ADJ S_NOUN S_X B_CONJ E_CONJ B E S S B E
         对应的WSU_Flag为：  0     0      3    101   201  0      202 ........
         
         特别注意 ：tagLst 是经过纠正过的，否则 会出错 ！！

参数说明: tagLst，标签序列 

返回值：WSU 标志 序列
'''


def get_POS_Flag(tagLst):
    if tagLst is None:
        raise Exception("求序列的POS 标志序列时，序列为 None！")

    if len(tagLst) == 0:
        raise Exception("求序列的POS 标志序列时，序列长度为 0 ！")

    sz = len(tagLst)
    POS_Flag = []
    pos_len = 0

    for i in range(sz):
        tag = posindex2tags[tagLst[i]]
        if is_E(tag) or is_S(tag):
            pos_len += 1
            POS_Flag.append(pos_len + posTagFlag[tag[2:]])
            pos_len = 0
        else:
            POS_Flag.append(0)
            pos_len += 1

    return POS_Flag


def get_NER_Flag(tagLst, posindex2tags, posTagFlag):
    if tagLst is None:
        raise Exception("求序列的NER 标志序列时，序列为 None！")

    if len(tagLst) == 0:
        raise Exception("求序列的NER 标志序列时，序列长度为 0 ！")

    sz = len(tagLst)
    POS_Flag = []
    pos_len = 0

    for i in range(sz):
        tag = posindex2tags[tagLst[i]]
        if is_E(tag) or is_S(tag):
            pos_len += 1
            POS_Flag.append(pos_len + posTagFlag[tag[2:]])
            pos_len = 0
        else:
            POS_Flag.append(0)
            pos_len += 1

    return POS_Flag


'''
函数功能：获得一个周期 训练集的 预测精度

参数说明：logits, LSTM的输出
         text_lens，实际的文本长度
         labels_batch，真实的标签序列
         model，预测所用的模型
         
返回值：训练集 的 测试 精度

'''


def get_acc_one_step(logits, text_lens, labels_batch, model):
    paths = []
    accuracy = 0

    for logit, text_len, labels in zip(logits, text_lens, labels_batch):
        viterbi_path, _ = tf_ad.text.viterbi_decode(logit[:text_len], model.transition_params)
        paths.append(viterbi_path)
        correct_prediction = tf.equal(
            tf.convert_to_tensor(pad_sequences([viterbi_path], padding='post'), dtype=tf.int32),
            tf.convert_to_tensor(pad_sequences([labels[:text_len]], padding='post'), dtype=tf.int32))

        accuracy = accuracy + tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    accuracy = accuracy / len(paths)
    return accuracy


'''
函数功能：矫正预测序列中的错误标签。 比如 'B','S','M','B','S'... 存在很多不合理的标签，把这些错误的标签都改过来(用'S'去替换错误的标签)
         也就是如果一个分词标签 组合 错误，比如：'B','S','E','M','B' ,这些不合理的标签 都以 'S' 计。

         核心算法 包括 前向 和 后向 扫描, 时间 复杂度为 O(n)

参数说明：tagLst, 一个标签序列

返回值：一个正确的标签序列

映射：
posTags2index
posindex2tags

tagLst 里面存的是 数字

'''


def correct_the_POSTag(tagLst):
    if tagLst is None:
        return None

    sz = len(tagLst)

    if sz == 0:
        return tagLst

    if sz == 1:
        if is_S(posindex2tags[tagLst[0]]):
            tagLst[0] = posTags2index['S_ERR']  # 赋予 错误的 标签

        return tagLst

    ## 前向 扫描 开始

    if not (is_B(posindex2tags[tagLst[0]]) or is_S(posindex2tags[tagLst[0]])):
        tagLst[0] = posTags2index['S_ERR']  # 赋予 错误的 标签

    pretag = posindex2tags[tagLst[0]]

    for i in range(1, sz):
        currTag = posindex2tags[tagLst[i]]

        if is_B(pretag):
            if not (is_M(currTag) or is_E(currTag)):  # B->M,E
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(pretag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_M(pretag):
            if not (is_M(currTag) or is_E(currTag)):  # M->M,E
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(pretag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_E(pretag):
            if not (is_B(currTag) or is_S(currTag)):  # E->B,S
                tagLst[i] = posTags2index['S_ERR']
            #  新标签开始，不 需要再检查标签的 类型

        elif is_S(pretag):
            if not (is_B(currTag) or is_S(currTag)):  # S->B,S
                tagLst[i] = posTags2index['S_ERR']
            #  新标签开始，不 需要再检查标签的 类型

        else:
            raise Exception("调用函数 correct_the_POSTag 时，标签 错误！！")

        # pretag = currTag tagLst[i]的值可能会发生变化，
        pretag = posindex2tags[tagLst[i]]

    # 前向扫描 结束
    # 后向扫描 开始
    sz = len(tagLst)
    if not (is_E(posindex2tags[tagLst[sz - 1]]) or is_S(posindex2tags[tagLst[sz - 1]])):  # 不是E也不是S，纠正过来
        tagLst[sz - 1] = posTags2index['S_ERR']

    postTag = posindex2tags[tagLst[sz - 1]]

    for i in range(sz - 2, -1, -1):  # [start, step, stop) (不包括 stop)
        currTag = posindex2tags[tagLst[i]]

        if is_B(postTag):
            if not (is_E(currTag) or is_S(currTag)):  # E,S->B
                tagLst[i] = posTags2index['S_ERR']
            # 不用检查 类型的关系

        elif is_M(postTag):
            if not (is_B(currTag) or is_M(currTag)):  # B,M->M
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(postTag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_E(postTag):
            if not (is_B(currTag) or is_M(currTag)):  # B,M->E
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(postTag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_S(postTag):
            if not (is_S(currTag) or is_E(currTag)):  # S,E->S
                tagLst[i] = posTags2index['S_ERR']
            # 不用检查 类型的关系
        else:
            raise Exception("调用 is_the_tag_list_is_correct 时，标签 错误！！")

        postTag = posindex2tags[tagLst[i]]

    return tagLst


# 矫正 NER 序列中的错误 标签
def correct_the_NER_Tag(tagLst, posindex2tags, posTags2index):
    if tagLst is None:
        return None

    sz = len(tagLst)

    if sz == 0:
        return tagLst

    if sz == 1:
        if is_S(posindex2tags[tagLst[0]]):
            tagLst[0] = posTags2index['S_ERR']  # 赋予 错误的 标签

        return tagLst

    ## 前向 扫描 开始

    if not (is_B(posindex2tags[tagLst[0]]) or is_S(posindex2tags[tagLst[0]])):
        tagLst[0] = posTags2index['S_ERR']  # 赋予 错误的 标签

    pretag = posindex2tags[tagLst[0]]

    for i in range(1, sz):
        currTag = posindex2tags[tagLst[i]]

        if is_B(pretag):
            if not (is_M(currTag) or is_E(currTag)):  # B->M,E
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(pretag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_M(pretag):
            if not (is_M(currTag) or is_E(currTag)):  # M->M,E
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(pretag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_E(pretag):
            if not (is_B(currTag) or is_S(currTag)):  # E->B,S
                tagLst[i] = posTags2index['S_ERR']
            #  新标签开始，不 需要再检查标签的 类型

        elif is_S(pretag):
            if not (is_B(currTag) or is_S(currTag)):  # S->B,S
                tagLst[i] = posTags2index['S_ERR']
            #  新标签开始，不 需要再检查标签的 类型

        else:
            raise Exception("调用函数 correct_the_POSTag 时，标签 错误！！")

        # pretag = currTag tagLst[i]的值可能会发生变化，
        pretag = posindex2tags[tagLst[i]]

    # 前向扫描 结束
    # 后向扫描 开始
    sz = len(tagLst)
    if not (is_E(posindex2tags[tagLst[sz - 1]]) or is_S(posindex2tags[tagLst[sz - 1]])):  # 不是E也不是S，纠正过来
        tagLst[sz - 1] = posTags2index['S_ERR']

    postTag = posindex2tags[tagLst[sz - 1]]

    for i in range(sz - 2, -1, -1):  # [start, step, stop) (不包括 stop)
        currTag = posindex2tags[tagLst[i]]

        if is_B(postTag):
            if not (is_E(currTag) or is_S(currTag)):  # E,S->B
                tagLst[i] = posTags2index['S_ERR']
            # 不用检查 类型的关系

        elif is_M(postTag):
            if not (is_B(currTag) or is_M(currTag)):  # B,M->M
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(postTag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_E(postTag):
            if not (is_B(currTag) or is_M(currTag)):  # B,M->E
                tagLst[i] = posTags2index['S_ERR']
            elif not tag_is_the_same_type(postTag, currTag):  # 符合BMES的规则，不同标签类型也不行
                tagLst[i] = posTags2index['S_ERR']

        elif is_S(postTag):
            if not (is_S(currTag) or is_E(currTag)):  # S,E->S
                tagLst[i] = posTags2index['S_ERR']
            # 不用检查 类型的关系
        else:
            raise Exception("调用 is_the_tag_list_is_correct 时，标签 错误！！")

        postTag = posindex2tags[tagLst[i]]

    return tagLst


'''
函数功能：判断 一个标签 是否是 某个 prefix 开头的
参数说明：tag，标签字符串
         prefix，前缀
         
返回值：True，是，反之 否
'''


def is_a_Tag(tag, prefix):
    if tag is None or len(tag) < 2 or prefix is None or len(prefix) != 1:
        return False

    if tag[0] == prefix and tag[1] == '_':
        return True

    return False


# 判断 标签是否是 B 开头
def is_B(tag):
    return is_a_Tag(tag, 'B')


# 判断 标签是否是 M 开头
def is_M(tag):
    return is_a_Tag(tag, 'M')


# 判断 标签是否是 E 开头
def is_E(tag):
    return is_a_Tag(tag, 'E')


# 判断 标签是否是 S 开头
def is_S(tag):
    return is_a_Tag(tag, 'S')


'''
函数功能：判断两个 标签是否是 同一种类型，例如 B_ADJ 和 E_ADJ是同种类型，
          B_NUM和 B_NOUN就不是同种类型的 
          
参数说明: tag1, 标签1
          tag2，标签2
          
返回值：相同 true，反之 false

'''


def tag_is_the_same_type(tag1, tag2):
    if tag1 is None or tag2 is None:
        return False

    if len(tag1) < 3 or len(tag2) < 3:
        return False

    type1 = tag1[2:]
    type2 = tag2[2:]

    return type1 == type2

'''
函数功能：判断两个 值 val1 和 val2 是否是 同一 类型，
         判断方法：判断 百位数 是否 相同，相同就是 同种类型，反之就不是同种类型
         
参数说明：val1, val2, 表示类型的值

返回值：True, 相同类型
        False, 不同类型

'''
def value_is_the_same_type( val1, val2):
    if val1 < 0 or val2 < 0 :
        raise Exception("用于判断 类型的值 小于 0， 不可能！")

    t1 = val1 - val1 % 100 # 保留 百位
    t2 = val2 - val2 % 100 # 保留 百位

    return t1 == t2
