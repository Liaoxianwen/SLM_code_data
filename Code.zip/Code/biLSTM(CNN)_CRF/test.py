# coding=utf-8
import tensorflow as tf2
from LSTM_CRF_Model import CRF
from tensorflow.keras.layers import Input,Embedding,LSTM,Dense, TimeDistributed,Bidirectional,Flatten,concatenate

from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import ModelCheckpoint

from common_fun import load_golden_segment
from common_fun import load_dictionary
from common_fun import load_word_embeding
from common_fun import get_indice_for_input
from common_fun import get_one_hot_of_y
from common_fun import get_tag_indics_of_y

#tf2.equal
#tf2.argmax

Max_Sentence_Len = -1 # 后面再赋值
Vocab_Size = -1 # 后面再 赋值
Word_Embedding_dim = 100
Lstm_unit = 50

sfilenameTrain = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vi-ud-train_segment.txt'
sfilenameTest  = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vi-ud-test_segment.txt'

sfilenameCross_Test  = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\test1_segment_BMES.txt'
sfilenameDictionary = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vianameseVocabulary.txt'
sfilenamePretrained = 'D:\PyProj\\1th_修回\\vinamesePretrain_embeding\\vec_100_wiki_vinamese'

dic_word2index, dic_index2word = load_dictionary(sfilenameDictionary)

x, y = load_golden_segment(sfilenameTrain)
Test_x, Test_tag = load_golden_segment(sfilenameTest)
CrossTest_x, CrossTest_tag = load_golden_segment(sfilenameCross_Test)

word_embeding = load_word_embeding(sfilenamePretrained,dic_word2index,Word_Embedding_dim)

x = get_indice_for_input(x, dic_word2index)
Test_x = get_indice_for_input(Test_x, dic_word2index)
CrossTest_x = get_indice_for_input(CrossTest_x, dic_word2index)

'''
y = get_one_hot_of_y(y)
Test_tag = get_one_hot_of_y(Test_tag)
CrossTest_tag = get_one_hot_of_y(CrossTest_tag)
'''
y = get_tag_indics_of_y(y)
Test_tag = get_tag_indics_of_y(Test_tag)
CrossTest_tag = get_tag_indics_of_y(CrossTest_tag)

x = pad_sequences(x, padding='post')
Test_x = pad_sequences(Test_x, padding='post')
CrossTest_x = pad_sequences(CrossTest_x, padding='post')

y = pad_sequences(y, padding='post')
Test_tag = pad_sequences(Test_tag, padding='post')
CrossTest_tag = pad_sequences(CrossTest_tag, padding='post')

ttt_x = x[0:50]
ttt_y = y[0:50]

#train_data = tf2.data.Dataset.from_tensor_slices((x, y)).batch(64)  #训练数据

Max_Sentence_Len = len(x[0]) # pad 过长度之后 ，都一样

#word_input = Input(shape=(Max_Sentence_Len,), name="word_input")

Vocab_Size = len(word_embeding) # 已经包含了 所有的词汇，包括预留的 第0个。 第 0 个元素 谁都不能用

emb_layer = Embedding(input_dim=Vocab_Size, # 把 OOV 加回来
                 output_dim=Word_Embedding_dim,
                 weights=[word_embeding],
                 input_length=Max_Sentence_Len,
                 trainable=True,
                 mask_zero=True
                 )

word = emb_layer(ttt_x)

# orthographic word representation: char embeddings -> BiLSTM
'''
char_input = Input(shape=(self.max_sentence, self.max_word), name="char_input")

char = TimeDistributed(

    Embedding(input_dim=self.char_dim, output_dim=char_embedding_dim,

              input_length=self.max_word)

)(char_input)

char = TimeDistributed(

    Bidirectional(

        LSTM(char_lstm_cell, return_sequences=True),

        merge_mode='concat'

    )

)(char)

char = TimeDistributed(Flatten())(char)

# concatenate word + char representations

inputs = concatenate([word, char])
'''


# main BiLSTM model

#bilstm_out = Bidirectional(LSTM(Lstm_unit, return_sequences=True), merge_mode='concat')(word)
bilstm_out = LSTM(Lstm_unit, return_sequences=True)(word)

#model = TimeDistributed(Dense(self.output_dim, activation='softmax'))(model)

Masking = emb_layer.compute_mask(ttt_x)

actual_sequence_len = tf2.reduce_sum(tf2.cast(Masking, dtype=tf2.int32), axis=-1)

crf = CRF(4, name="output")

logits, text_lens, log_likelihood = crf(bilstm_out, actual_sequence_len, ttt_y) #inputs, text_lens, labels=None, training=None

loss = 0 - tf2.reduce_mean(log_likelihood)

model = Model(inputs=word_input, outputs=loss)

model.compile(loss=crf.loss_function, optimizer='adam', metrics=[crf.accuracy])

model.summary()

checkpointer = ModelCheckpoint(filepath='best_LSTMCRF_model.{epoch:02d}-{val_loss:.4f}.hdf5', monitor='val_loss', verbose=0, save_best_only=True)

model.fit(train_data, shuffle=True, validation_data=(Test_x, Test_tag), validation_batch_size=64, callbacks=[checkpointer])

