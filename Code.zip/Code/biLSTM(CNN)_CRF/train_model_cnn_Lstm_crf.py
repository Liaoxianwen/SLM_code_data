# coding=utf-8
import tensorflow as tf2
from LSTM_CRF_Model import LSTM_CRF
from LSTM_CRF_Model import CNN_LSTM_CRF
from LSTM_CRF_Model import get_acc_one_step
from LSTM_CRF_Model import train_one_step
from LSTM_CRF_Model import predict
from LSTM_CRF_Model import predict_POS
from LSTM_CRF_Model import posTags2index

from LSTM_CRF_Model import correct_the_tagList
from tensorflow.keras.layers import Input,Embedding,LSTM,Dense, TimeDistributed,Bidirectional,Flatten,concatenate

from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import ModelCheckpoint
import numpy as np

from common_fun import load_golden_segment
from common_fun import load_dictionary, load_char_dictionary
from common_fun import load_word_embeding
from common_fun import get_indice_for_input, get_char_indice_for_input_MaxLen
from common_fun import get_one_hot_of_y
from common_fun import get_tag_indics_of_y
from common_fun import get_tag_indics_of_POS
from common_fun import load_POS

Max_Sentence_Len = -1 # 后面再赋值
Vocab_Size = -1 # 后面再 赋值
Word_Embedding_dim = 100
Lstm_unit = 35

output_dir = 'D:\\PyProj\\1th_修回\\LSTM_CRF\\output_dir'
sfilenameDictionary = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vianameseVocabulary.txt'
sfilename_char_Dic = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vianameseChars.txt'
# pre-Trained Embeding
sfilenamePretrained = 'D:\PyProj\\1th_修回\\vinamesePretrain_embeding\\vec_100_wiki_vinamese'
dic_word2index, dic_index2word = load_dictionary(sfilenameDictionary)
dic_char2index, dic_index2char = load_char_dictionary(sfilename_char_Dic)
word_embeding = load_word_embeding(sfilenamePretrained,dic_word2index,Word_Embedding_dim)

# train data
sfilenameTrain = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\jaist_train.txt'#
sfilenameTrain_preSeg = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\jaist_train_preSeg.txt'
sfilenameTest = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\jaist_test.txt'
sfilenameTest_preSeg = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\jaist_test_preSeg.txt'

# cross domain test data
sfilenameCross_Test = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\conll2017_test.txt'
sfilenameCross_Test_Pre = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\conll2017_test_preSeg.txt'

# POS train ，test data
sfilename_Pos_train = 'D:\PyProj\\1th_修回\\vinamese_segment_data\\conll2017_train_POS.txt'
sfilename_Pos_test = 'D:\PyProj\\1th_修回\\vinamese_segment_data\\conll2017_test_POS.txt'


x, y_golden, x_chars = load_golden_segment(sfilenameTrain)
n_0, y_pre, _ = load_golden_segment(sfilenameTrain_preSeg)

Test_x, Test_golden, Test_x_chars = load_golden_segment(sfilenameTest)
n_1, Test_pre, _ = load_golden_segment(sfilenameTest_preSeg)

CrossTest_x, CrossTest_golden, CrossTest_x_chars = load_golden_segment(sfilenameCross_Test)
n_2, CrossTest_pre, _ = load_golden_segment(sfilenameCross_Test_Pre)

### load POS
pos_train_x, pos_train_golden_tags = load_POS(sfilename_Pos_train)
pos_test_x, pos_test_golden_tags = load_POS(sfilename_Pos_test)


x = get_indice_for_input(x, dic_word2index)
Test_x = get_indice_for_input(Test_x, dic_word2index)
CrossTest_x = get_indice_for_input(CrossTest_x, dic_word2index)

#maxchars = 29
maxchars = 50
x_chars = get_char_indice_for_input_MaxLen(x_chars, dic_char2index,maxchars)
Test_x_chars = get_char_indice_for_input_MaxLen(Test_x_chars, dic_char2index,maxchars)
CrossTest_x_chars = get_char_indice_for_input_MaxLen(CrossTest_x_chars, dic_char2index,maxchars)

'''
y = get_one_hot_of_y(y)
Test_tag = get_one_hot_of_y(Test_tag)
CrossTest_tag = get_one_hot_of_y(CrossTest_tag)
'''

y_golden = get_tag_indics_of_y(y_golden)
Test_golden = get_tag_indics_of_y(Test_golden)
CrossTest_golden = get_tag_indics_of_y(CrossTest_golden)

y_golden_POS = get_tag_indics_of_POS(pos_train_golden_tags, posTags2index)
test_golden_POS = get_tag_indics_of_POS(pos_test_golden_tags, posTags2index)

y_pre = get_one_hot_of_y(y_pre)
Test_pre = get_one_hot_of_y(Test_pre)
CrossTest_pre = get_one_hot_of_y(CrossTest_pre)


x = pad_sequences(x, padding='post')
Test_x = pad_sequences(Test_x, padding='post')
CrossTest_x = pad_sequences(CrossTest_x, padding='post')

y_golden = pad_sequences(y_golden, padding='post',value=-1)
Test_golden = pad_sequences(Test_golden, padding='post',value=-1)
CrossTest_golden = pad_sequences(CrossTest_golden, padding='post',value=-1)

y_golden_POS = pad_sequences(y_golden_POS, padding='post',value=-1)
test_golden_POS = pad_sequences(test_golden_POS, padding='post',value=-1)

y_pre = pad_sequences(y_pre, padding='post')
Test_pre = pad_sequences(Test_pre, padding='post')
CrossTest_pre = pad_sequences(CrossTest_pre, padding='post')

#train_data = tf2.data.Dataset.from_tensor_slices((x, y)).batch(64)  #训练数据
x_dataset = tf2.data.Dataset.from_tensor_slices(x)
y_dataset = tf2.data.Dataset.from_tensor_slices(y_golden)
ypre_dataset = tf2.data.Dataset.from_tensor_slices(y_pre)

y_golden_POS_dataset = tf2.data.Dataset.from_tensor_slices(y_golden_POS)


Test_x_dataset = tf2.data.Dataset.from_tensor_slices(Test_x)
Test_golden_dataset = tf2.data.Dataset.from_tensor_slices(Test_golden)
Test_PRE_dataset = tf2.data.Dataset.from_tensor_slices(Test_pre)

CrossTest_x_dataset = tf2.data.Dataset.from_tensor_slices(CrossTest_x)
CrossTest_golden_dataset = tf2.data.Dataset.from_tensor_slices(CrossTest_golden)
CrossTest_PRE_dataset=tf2.data.Dataset.from_tensor_slices(CrossTest_pre)

x_chars = pad_sequences(x_chars, padding='post')
Test_x_chars = pad_sequences(Test_x_chars, padding='post')
CrossTest_x_chars = pad_sequences(CrossTest_x_chars, padding='post')

x_chars_dataset = tf2.data.Dataset.from_tensor_slices(x_chars)
Test_x_chars_dataset = tf2.data.Dataset.from_tensor_slices(Test_x_chars)
CrossTest_x_chars_dataset = tf2.data.Dataset.from_tensor_slices(CrossTest_x_chars)

train_data = tf2.data.Dataset.zip((x_dataset, y_dataset, ypre_dataset, x_chars_dataset)).batch(256)
train_data_pos = tf2.data.Dataset.zip((x_dataset, y_golden_POS_dataset, ypre_dataset, x_chars_dataset)).batch(64)
labelsize = 4
#labelsize = 57

Max_Sentence_Len = max([len(x[0]), len(Test_x[0]), len(CrossTest_x[0])])# pad 过长度之后 ，都一样

char_table_size = len(dic_char2index)
char_embeding_size = 20
max_word_len = max([len(x_chars[-1, 0]), len(Test_x_chars[-1, 0]), len(CrossTest_x_chars[-1, 0])])

#model = LSTM_CRF(lstm_unit=50, embeding_weights=word_embeding, label_size=labelsize, embedding_size=100, max_sents_len=Max_Sentence_Len, char_table_size=char_table_size,char_embeding_size=char_embeding_size,max_word_len=max_word_len)


model = CNN_LSTM_CRF(lstm_unit=75,
                     embeding_weights=word_embeding,
                     label_size=labelsize,
                     embedding_size=100,
                     max_sents_len=Max_Sentence_Len,
                     char_table_size=char_table_size,
                     char_embeding_size=char_embeding_size,
                     max_word_len=max_word_len,
                     filters=40,
                     kernel_size=3,
                     channels=1)

optimizer = tf2.keras.optimizers.Adam()

ckpt = tf2.train.Checkpoint(optimizer=optimizer, model=model)
ckpt.restore(tf2.train.latest_checkpoint(output_dir))
ckpt_manager = tf2.train.CheckpointManager(ckpt, output_dir, checkpoint_name='model.ckpt', max_to_keep=3)

epoch = 50
best_acc = 0
best_F = 0
best_F_ct = 0
step = 0

train_data = train_data

for ep in range(epoch):
    train_data = train_data.shuffle(2000000)
    print("ep=:" + str(ep))

    for _, (x_batch, y_batch, y_pre, x_chars) in enumerate(train_data):  # train_data
        step = step + 1
        #y_pre = None
        #Test_pre = None
        #CrossTest_pre = None
        #x_chars = None
        #Test_x_chars = None
        #CrossTest_x_chars = None
        loss, logits, text_lens = train_one_step(x_batch, y_batch, y_pre, x_chars, model, optimizer)

        if step % 10 == 0:
            accuracy = get_acc_one_step(logits, text_lens, y_batch,model.crf)
            P, R, F            = predict(   Test_x,      Test_golden,      Test_pre, model,      Test_x_chars)
            P_ct, R_ct, F_ct = predict(CrossTest_x, CrossTest_golden, CrossTest_pre, model, CrossTest_x_chars)
            #P, R, F = predict_POS(Test_x, test_golden_POS, Test_pre, model, Test_x_chars)

            print("epoch %d, P   = %.4f, R   = %.4f , F   = %.4f" % (ep, P, R, F))
            print("epoch %d, P_ct= %.4f, R_ct= %.4f , F_ct= %.4f" % (ep, P_ct, R_ct, F_ct))

            if F > best_F:
                best_F = F
                ckpt_manager.save()
                print("model saved")

            if F_ct > best_F_ct:
                best_F_ct = F_ct

            print(
                'epoch %d, step %d, loss %.4f , acc %.4f, bestTrainAcc:%.4f,test_F:%04f,best_F:%.4f, best_F_ct:%.4f' % (
                ep, step, loss, accuracy, best_acc, F, best_F, best_F_ct))
