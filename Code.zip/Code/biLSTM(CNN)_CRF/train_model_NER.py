# coding=utf-8
import tensorflow as tf2
from LSTM_CRF_Model import LSTM_CRF
from LSTM_CRF_Model import get_acc_one_step
from LSTM_CRF_Model import train_one_step
from LSTM_CRF_Model import predict
from LSTM_CRF_Model import predict_POS
from LSTM_CRF_Model import predict_NER
from LSTM_CRF_Model import posTags2index
from LSTM_CRF_Model import ner_Tags2index

from LSTM_CRF_Model import correct_the_tagList
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense, TimeDistributed, Bidirectional, Flatten, concatenate

from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import ModelCheckpoint
import numpy as np

from common_fun import load_golden_segment
from common_fun import load_dictionary, load_char_dictionary
from common_fun import load_word_embeding
from common_fun import get_indice_for_input, get_char_indice_for_input
from common_fun import get_one_hot_of_y
from common_fun import get_tag_indics_of_y
from common_fun import get_tag_indics_of_POS
from common_fun import load_POS

Max_Sentence_Len = -1  # 后面再赋值
Vocab_Size = -1  # 后面再 赋值
Word_Embedding_dim = 100
Lstm_unit = 35

output_dir = 'D:\\PyProj\\1th_修回\\LSTM_CRF\\output_dir'
sfilenameDictionary = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vianameseVocabulary.txt'
sfilename_char_Dic = 'D:\\PyProj\\1th_修回\\vinamese_segment_data\\vianameseChars.txt'
# pre-Trained Embeding
sfilenamePretrained = 'D:\PyProj\\1th_修回\\vinamesePretrain_embeding\\vec_100_wiki_vinamese'
dic_word2index, dic_index2word = load_dictionary(sfilenameDictionary)
dic_char2index, dic_index2char = load_char_dictionary(sfilename_char_Dic)
word_embeding = load_word_embeding(sfilenamePretrained, dic_word2index, Word_Embedding_dim)

# train data
sfilenameTrain = 'D:\\PyProj\\1th_修回\\Vietnamese_NER\\vi_ner_train.txt'
sfilenameTrain_preSeg = 'D:\\PyProj\\1th_修回\\Vietnamese_NER\\vi_ner_train_preSeg.txt'
sfilenameTest = 'D:\\PyProj\\1th_修回\\Vietnamese_NER\\vi_ner_test.txt'
sfilenameTest_preSeg = 'D:\\PyProj\\1th_修回\\Vietnamese_NER\\vi_ner_test_preSeg.txt'

x, y_golden, x_chars = load_golden_segment(sfilenameTrain)
n_0, y_pre, _ = load_golden_segment(sfilenameTrain_preSeg)

Test_x, Test_golden, Test_x_chars = load_golden_segment(sfilenameTest)
n_1, Test_pre, _ = load_golden_segment(sfilenameTest_preSeg)

x = get_indice_for_input(x, dic_word2index)
Test_x = get_indice_for_input(Test_x, dic_word2index)

x_chars = get_char_indice_for_input(x_chars, dic_char2index)
Test_x_chars = get_char_indice_for_input(Test_x_chars, dic_char2index)

'''
y = get_one_hot_of_y(y)
Test_tag = get_one_hot_of_y(Test_tag)
CrossTest_tag = get_one_hot_of_y(CrossTest_tag)
'''

y_golden = get_tag_indics_of_POS(y_golden, ner_Tags2index)          # 和 NER 一样的套路
Test_golden = get_tag_indics_of_POS(Test_golden, ner_Tags2index)

y_pre = get_one_hot_of_y(y_pre)
Test_pre = get_one_hot_of_y(Test_pre)

x = pad_sequences(x, padding='post')
Test_x = pad_sequences(Test_x, padding='post')

y_golden = pad_sequences(y_golden, padding='post', value=-1)
Test_golden = pad_sequences(Test_golden, padding='post', value=-1)

y_pre = pad_sequences(y_pre, padding='post')
Test_pre = pad_sequences(Test_pre, padding='post')

# train_data = tf2.data.Dataset.from_tensor_slices((x, y)).batch(64)  #训练数据
x_dataset = tf2.data.Dataset.from_tensor_slices(x)
y_dataset = tf2.data.Dataset.from_tensor_slices(y_golden)
ypre_dataset = tf2.data.Dataset.from_tensor_slices(y_pre)


Test_x_dataset = tf2.data.Dataset.from_tensor_slices(Test_x)
Test_golden_dataset = tf2.data.Dataset.from_tensor_slices(Test_golden)
Test_PRE_dataset = tf2.data.Dataset.from_tensor_slices(Test_pre)

x_chars = pad_sequences(x_chars, padding='post')
Test_x_chars = pad_sequences(Test_x_chars, padding='post')

x_chars_dataset = tf2.data.Dataset.from_tensor_slices(x_chars)
Test_x_chars_dataset = tf2.data.Dataset.from_tensor_slices(Test_x_chars)

train_data = tf2.data.Dataset.zip((x_dataset, y_dataset, ypre_dataset, x_chars_dataset)).batch(64)

#labelsize = 4
labelsize = 17

Max_Sentence_Len = max([len(x[0]), len(Test_x[0])])  # pad 过长度之后 ，都一样

char_table_size = len(dic_char2index)
char_embeding_size = 15
max_word_len = max([len(x_chars[-1, 0]), len(Test_x_chars[-1, 0])])

model = LSTM_CRF(lstm_unit=100, embeding_weights=word_embeding, label_size=labelsize, embedding_size=100,
                 max_sents_len=Max_Sentence_Len, char_table_size=char_table_size, char_embeding_size=char_embeding_size,
                 max_word_len=max_word_len)

optimizer = tf2.keras.optimizers.Adam()

ckpt = tf2.train.Checkpoint(optimizer=optimizer, model=model)
ckpt.restore(tf2.train.latest_checkpoint(output_dir))
ckpt_manager = tf2.train.CheckpointManager(ckpt, output_dir, checkpoint_name='model.ckpt', max_to_keep=3)

epoch = 150
best_acc = 0
best_F = 0
step = 0

best_F_per = 0
best_F_loc = 0
best_F_org = 0

train_data = train_data

for ep in range(epoch):
    train_data = train_data.shuffle(2000000)
    print("ep=:" + str(ep))

    for _, (x_batch, y_batch, y_pre, x_chars) in enumerate(train_data):
        step = step + 1
        y_pre = None
        Test_pre = None
        CrossTest_pre = None
        x_chars = None
        Test_x_chars = None
        CrossTest_x_chars = None
        loss, logits, text_lens = train_one_step(x_batch, y_batch, y_pre, x_chars, model, optimizer)

        if step % 10 == 0:
            accuracy = get_acc_one_step(logits, text_lens, y_batch, model.crf)
            #P, R, F = predict(Test_x, Test_golden, Test_pre, model, Test_x_chars)

            P, R, F, P_per, R_per, F_per, P_loc, R_loc, F_loc, P_org, R_org, F_org = predict_NER(Test_x, Test_golden, Test_pre, model, Test_x_chars)

            print("epoch %d, P     = %.4f, R     = %.4f , F     = %.4f" % (ep, P, R, F))
            print("epoch %d, P_per = %.4f, R_per = %.4f , F_per = %.4f" % (ep, P_per, R_per, F_per))
            print("epoch %d, P_loc = %.4f, R_loc = %.4f , F_loc = %.4f" % (ep, P_loc, R_loc, F_loc))
            print("epoch %d, P_org = %.4f, R_org = %.4f , F_org = %.4f" % (ep, P_org, R_org, F_org))

            if F > best_F:
                best_F = F
                ckpt_manager.save()
                print("model saved")

            if F_per > best_F_per:
                best_F_per = F_per

            if F_loc > best_F_loc:
                best_F_loc = F_loc

            if F_org > best_F_org:
                best_F_org = F_org

            print(
                'epoch %d, step %d, loss %.4f , acc %.4f, bestTrainAcc:%.4f,test_F:%04f,best_F:%.4f,best_F_per:%.4f,best_F_loc:%.4f,best_F_org:%.4f' % (
                ep, step, loss, accuracy, best_acc, F, best_F, best_F_per, best_F_loc, best_F_org))
