﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace ViWordAna
{
    public class DBConn
    {

       public MySqlConnection m_mysqlConn;
        
       public DBConn()
        {
            m_sUserName = "";
            m_sDbConn = "Server=127.0.0.1;Database=viwdb;Uid=root;Pwd=123456;CharSet=utf8; Allow User Variables=True;";

            InitDBconn();

            m_mysqlCmd = new MySqlCommand();
            m_mysqlCmd.Connection = m_mysqlConn;
        }

       ~DBConn()
       {
           CloseDbConn();
       }

        /*
         * 函数功能：初始化数据库连接
         * 
         */
       private void InitDBconn()
       {
           try
           {
               m_mysqlConn = new MySqlConnection();
               m_mysqlConn.ConnectionString = m_sDbConn; // 设置连接字符串

               m_mysqlConn.Open(); // 打开连接

           }
           catch (MySqlException ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       /*
        * 函数功能：把一批 sql 语句当事务来处理。
        * 参数说明：LSql，一批sql 语句
        * 返回值：无
        */
       public void  WriteWCO2DB( List<string> LSql )
       {

          // string sQueryString = "insert into tbl set w0=" + w0.ToString() + ",w1=" + w1.ToString() + ",w2=" + w2.ToString() + ",coe=1 on duplicate key update coe=coe+1; ";
          // string sQueryString = "insert into tbl values(" + w0.ToString() + "," + w1.ToString() + "," + w2.ToString() + ",coe=1); ";

           if (LSql == null || LSql.Count == 0)
           {
               return;
           }

           MySqlTransaction ta = m_mysqlConn.BeginTransaction();

           try
           {
               MySqlCommand mysqlCmd = new MySqlCommand( );
               mysqlCmd.Connection = m_mysqlConn;
               mysqlCmd.Transaction = ta;

               int i = 0;

               for (i = 0; i < LSql.Count; ++i)
               {
                   mysqlCmd.CommandText = LSql[i];
                   mysqlCmd.ExecuteNonQuery();
               }

               ta.Commit();
           }
           catch( System.Exception ee)
           {
               MessageBox.Show("RollBack 发生！\n" + ee.ToString());

               ta.Rollback();
               MessageBox.Show("写入关联表时发生了错误！事务已经回滚！\n"+ ee.ToString());
           }
       }

        /*
         * 
         * 
         */
       public int GetWordNumFromDB(int[] i,string tableName ,int tblno)
       {
           int rt = 0;

           if (i == null || i.Length == 0)
           {
               return 0;
           }

           if (i.Length > 8)
           {
               MessageBox.Show("不支持这么多的字段查询！字段数量等于：" + i.Length);
               return 0;
           }

           string sCmd = "select sum(coe) from " + tableName + tblno.ToString() + "  where w0=" + i[0].ToString();

           int k = 0;

           for (k = 1; k < i.Length; ++k)
           {
               sCmd += " and w" + k.ToString() + " = " + i[k].ToString();
           }

           try
           {
               //MySqlCommand mysqlCmd = new MySqlCommand(sCmd, m_mysqlConn);
               m_mysqlCmd.CommandText = sCmd;
               MySqlDataReader myReader = m_mysqlCmd.ExecuteReader();

               while (myReader.Read())
               {
                   //string strt = (string)myReader[0]; //类型转换不对时，可以用这句话来试错

                   if (myReader.IsDBNull(0))
                   {
                       break;
                   }

                   rt = (int)((Decimal)myReader[0]);
               }

               myReader.Close();
           }
           catch (System.Exception ee)
           {
               MessageBox.Show("读数据库时 发生了错误！\n<sql 语句：" + sCmd + ">\n" + ee.ToString());
           }

           return rt;
       }

        /*
         * 函数功能：获得数组 i 的出现次数
         * 参数说明：i数组，1阶词，2阶词，3阶词
         * 返回值：词出现的次数
         * 
         */
       public int GetWordNumFromDB( int[] i, int tblno )
       {
           return GetWordNumFromDB(i, "tb_coll2017_jaist_ner_all_", tblno) + GetWordNumFromDB(i, "tb", tblno);
       }

       private void CloseDbConn()
       {
           m_mysqlConn.Close(); // 关闭数据库连接
       }

       public static string m_sUserName; // 记录当前登陆的用户名称
       public static string m_sDbConn;   // 数据库连接字符串

       public UInt32[] m_WordNums = null;  

       private MySqlCommand m_mysqlCmd;

    }
}
