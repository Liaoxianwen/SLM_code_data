﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace ViWordAna
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        /*
         * 函数功能：统计所有词的出现次数，并按出现次数降序保存在文件中
         * 参数说明：略
         * 返回值： 无。输出结果是降序排序的词频文件。
         * 
         */

        private void m_btnLoadViFile_Click(object sender, EventArgs e)
        {
            string []FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};

            //string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            StreamWriter sw = new StreamWriter("viwords.txt",false);
            wordCoExist_O2 wco2 = new wordCoExist_O2(FilePathName);

            m_lbStatus.Text = "";
            UInt32 num = wco2.ExtractWords(m_lbStatus);

             wco2.SaveWords(sw);

             sw.Close();
             sw.Dispose();

            MessageBox.Show(num.ToString());
        }

        /*
         * 函数功能:简单的测试 代码
         * 参数说明：
         * 返回值：无
         */

        private void m_btnTest_Click(object sender, EventArgs e)
        {

            preProc_Vi_NER ppvin = new preProc_Vi_NER();

            //ppvin.convert_2_standard_NER_tags();

            ppvin.GetSentencesFrom_Standard_ner_file();



            return;


            string[] words = null;
            string str = " Các  ngôi- sao  sao  thi đấu ở nước  Các- ngôi sao  sao  thi  sao  thi thi ，đấu Chanathip  ở nước ngoài như  như Chanathip hay Dangda， đều được  đều được được HLV nước HLV HLV ，Rajevac nước nước nước nước nước  nước  đều đều "; ;

            string str1 = "Văn hóa Hy Lạp có ảnh hưởng sâu rộng đến La Mã và nền văn minh phương Tây.";

            List<string> LSql = new List<string>();

            WCE_FromFile_DB wcef2 = new WCE_FromFile_DB();
            //wcef2.ReadWordCoExistArr();

            wordSeg ws = new wordSeg();
            words = ws.dowordSeg(str);

            WordSentenceNumPair  t= wcef2.Add_8_CoWords_2DB(words, str, null, LSql);

            MessageBox.Show("分句数量 ：" + t.m_SentenceNum.ToString()  +"\n"+
                            "N元词数量：" + t.m_NGramWordNum.ToString());


        }

        private void OnTimer(object sender, EventArgs e)
        {

            m_lbStatus.Text = "已经过去："+ m_tmpCnt.ToString() +"秒";
            m_tmpCnt++;
        }
        
        private int m_tmpCnt = 0;


        /*
         * 函数功能：写入 1阶关联词表
         * 参数说明：无
         * 
         * 返回值：无
         *
         */

        private void m_btnMk1Order_Click(object sender, EventArgs e)
        {
            /*
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};*/


            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            //string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();

            //wco.Make_1_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;
            TimeSpan ts = dEnd - dBeg;
            MessageBox.Show("1阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }


        /*
         * 函数功能：生成 2阶 关联词表，并保存在文件中
         * 参数说明：
         * 返回值：无
         */
        private void m_btnGenCoArr_Click(object sender, EventArgs e)
        {
            /*string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};*/

            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };
                                       

            //string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();

            //wco.Make_2_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;
            TimeSpan ts = dEnd - dBeg;
            MessageBox.Show("2阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }

        private void m_btnWSeg_Click(object sender, EventArgs e)
        {
            //string str = "Các ngôi sao sáng giá nhất đang thi đấu ở nước ngoài như Chanathip hay Dangda đều được HLV Rajevac gọi về";//giúp cô gái Ê đê
            string str = " tràn đầy năng lượng và sự tự tin giúp cô gái Ê đê ghi dấu ấn ở cuộc thi nhan sắc quốc tế";

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.ReadWordCoExistArr(); // 读取2阶关联矩阵

            splitsentence sp = new splitsentence(wco, str);

            sp.doSplit(str);

            MessageBox.Show("分词完成！");
        }

        // 概率观察测试
        private void m_btnProbWatch_Click(object sender, EventArgs e)
        {

            //SentsLenStatics sls = new SentsLenStatics("vi-ud-train_rawSentences_PreSplit只是条件概率检查.txt"); 统计句子最大长度、平均长度等等。。。

            //return;

            string str = "buôn lậu";

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.ReadWordCoExistArr(); // 读取2阶关联矩阵

            splitsentence sp = new splitsentence(wco, str);

            sp.Test(wco,str);

            MessageBox.Show("分词完成！");
        }

        private void m_btnMk3Order_Click(object sender, EventArgs e)
        {
            /*string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};*/

            //string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };
            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            DialogResult dr= MessageBox.Show("是否生成 3 阶 关联词？？", "是否确定？", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                return;
            }

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.Make_3_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;

            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("三阶 关联 写到数据库完成！！\n"+ "共耗时："+ts.ToString());
        }

        private void m_btnSSplit3_Click(object sender, EventArgs e)
        {
            //string str = "Các ngôi sao sáng giá nhất đang thi đấu ở nước ngoài như Chanathip hay Dangda đều được HLV Rajevac gọi về";//giúp cô gái Ê đê
            //string str = " tràn đầy năng lượng và sự tự tin giúp cô gái Ê đê ghi dấu ấn ở cuộc thi nhan sắc quốc tế";

            string str = "Các  ngôi  sao  sáng  giá  nhất";

            WCE_FromFile_DB wco2 = new WCE_FromFile_DB();
            splitsent_3odr sp3 = new splitsent_3odr(wco2,str);
            

            sp3.doSplit(str);

            MessageBox.Show("分词完成！");
        }

        private void m_btnMk4Order_Click(object sender, EventArgs e)
        {
           /* string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};*/

            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            DialogResult dr = MessageBox.Show("是否生成 4 阶 关联词？？", "是否确定？", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                return;
            }

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.Make_4_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;

            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("4阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }

        private void m_btnMk5Order_Click(object sender, EventArgs e)
        {
            /*
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};*/

            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08" };

            DialogResult dr = MessageBox.Show("是否生成 5 阶 关联词？？", "是否确定？", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                return;
            }

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();

            try
            {
                //wco.Make_5_CoExist(FilePathName);
            }
            catch (SystemException ee)
            {
                MessageBox.Show("在外面出错了\n"+ee.ToString());
            }

            DateTime dEnd = System.DateTime.Now;

            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("5阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }

        private void m_btnMk6Order_Click(object sender, EventArgs e)
        {
            /*
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};*/

            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            DialogResult dr = MessageBox.Show("是否生成 6 阶 关联词？？", "是否确定？", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                return;
            }

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.Make_6_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;

            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("6阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }

        private void m_btnMk7Order_Click(object sender, EventArgs e)
        {
            /*
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};
             * */
            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            DialogResult dr = MessageBox.Show("是否生成 7 阶 关联词？？", "是否确定？", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                return;
            }

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.Make_7_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;

            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("7阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }

        private void m_btnMk8Order_Click(object sender, EventArgs e)
        {
            /*
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};
             * */

            string[] FilePathName = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\all_vi_ner_sents2DB.txt" };

            string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            DialogResult dr = MessageBox.Show("是否生成 8 阶 关联词？？", "是否确定？", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                return;
            }

            DateTime dBeg = System.DateTime.Now;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.Make_8_CoExist(FilePathName);

            DateTime dEnd = System.DateTime.Now;

            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("8阶 关联 写到数据库完成！！\n" + "共耗时：" + ts.ToString());
        }

        /*
         * 函数功能：手动对一个越南语 语句进行分词
         * 
         */
        private void m_btnSplit_6_Click(object sender, EventArgs e)
        {
            //string str = "Mỗi người cần một lượng thời gian ngủ khác nhau";
            //string str = "PPPK- PPPK, PPPK Mỗi PPPK PPPK  PPPK PPPK  PPPK PPPK người  người  người  người PPPK cần một，，。 lượng thời -gian ngủ khác nhau- PPPK";
            //string str = "Bạn đã nghe việc ngồi một chỗ có thể cướp đi tính mạng của chúng ta chưa";
            
            //string str = "Các ngôi sao sáng giá nhất đang thi đấu ở nước ngoài như Chanathip hay Dangda đều được HLV Rajevac gọi về";//giúp cô gái Ê đê
            
            //string str = " tràn đầy năng lượng và sự tự tin giúp cô gái Ê đê ghi dấu ấn ở cuộc thi nhan sắc quốc tế";

            //string str = "tràn đầy năng lượng ";

            //string str = "và  sự  tự  tin";

            //string str = "đưa được một người con trở về với gia đình cũng chính là các thám tử đã giúp một cuộc đời non trẻ thoát khỏi một cạm bẫy";
            string str="dự án qui hoạch phát triển khu dân cư mới tại xã xuân hải được đầu tư theo phương thức chuyển giao quyền sử dụng đất xây dựng nhà ở ";

            //string str = "dự án qui hoạch phát triển khu dân cư mới tại xã xuân hải được đầu tư theo phương thức chuyển giao quyền";//看看20个单词要多久

            //str = GetStringFromFile("庆佛活动_vnexp.txt");
            //str = " Thủ phạm không ai khác chính là chiếc điện thoại di động  ";

            //str = "thuật ngữ để chỉ những chiếc xe";// hatchback nhỏ có công suất lớn";
            str = "cả hai phiên bản này đều có tốc độ chơi khá chậm chạp và bạn có thể cân nhắc và suy đoán được những hoạt động tiếp theo";// Zhou bị hạ đường huyết và chậm phát triển trí tuệ";bắc   kinh
            str = "huy chương liên hiệp quốc để trao cho những thành viên quân sự tham gia vào việc gìn giữ các thỏa thuận hòa bình của tổ chức này";

            //str = "gia đình phải đeo giỏ đi buôn lậu";
           // str = "lớn hơn đáng kể so với người lớn bình thường và kích hoạt não rất mạnh trong quá trình tính toán";

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            //wco.ReadWordCoExistArr(); // 读取2阶关联矩阵

            DBConn db = new DBConn();

            CalcProbCond cpc = new CalcProbCond(db, wco.m_WordDic2,wco.m_WordNums);

            FindMinH4Sents fmh = new FindMinH4Sents(str,cpc);

            fmh.PrintH4Sents();

            //PreSplit ps = new PreSplit(cpc);
            //ps.Split__Va___(str);

            return;
            

            PreSplit psl = new PreSplit(cpc);

            List<string> sLst = psl.PreSplit4WordSeg(str);
            
           // tempSave(sLst);

            //return;

           // string s1 = sLst[0];

            string s1 = str;

            SplitSents sps = new SplitSents(cpc, s1);

            sps.doSplit(s1);

            MessageBox.Show("6阶分词完成！");
        }

        /*
         * 函数功能：从一个文件中所有的字符串 连接起来，然后返回
         * 参数说明:sFilePathName,文件的路径名
         * 
         * 返回值：一个字符串
         * 
         * **/

        private string GetStringFromFile(string sFilePathName)
        {
            string str = "";

            StreamReader sr = new StreamReader(sFilePathName);

            while (!sr.EndOfStream)
            {
                str += sr.ReadLine();
            }

            sr.Close();
            sr.Dispose();

            return str;
        }

        private void tempSave( List<string> Lst)
        {
            int i = 0;
            StreamWriter sw = new StreamWriter("庆佛活动_vnexp_PreSplit.txt", false);

            for (i = 0; i < Lst.Count; ++i)
            {
                sw.WriteLine(Lst[i]);
            }

            sw.Close();
            sw.Dispose();

            MessageBox.Show("保存 PreSplit.txt 完成！");
        }

        /*
         * 函数功能：越南语测试，本方法分词结果 和 人主观分词的 对比
         * 
         * 新闻1：庆佛
         * 新闻2：禁毒
         * 人物故事：周Story
         * 
         */
        private void m_btnViTest_Click(object sender, EventArgs e)
        {
           // Test4Vi_CONIL2017 tvic = new Test4Vi_CONIL2017("vi-ud-train.conllu");

            //Test4Vi_CONIL2017 tvic = new Test4Vi_CONIL2017("禁毒_vnexp_PreSplit.txt", true);

            //tvic.DoCompareWithStandard();

            string sFileA = @"D:\C_Sharp_Proj\ViWordAna\Corpus\VI标注实验\周伟_STD.txt";
            string sFileB = @"D:\C_Sharp_Proj\ViWordAna\Corpus\VI标注实验\周伟VN.txt";

            //sFileA = @"D:\C_Sharp_Proj\ViWordAna\Corpus\VI标注实验\test.txt";

            Test4Vi_Annotation tva = new Test4Vi_Annotation();


            double pPri = tva.GetPricsi(sFileA, sFileB, 3);
            double pRec = tva.GetReCall(sFileA, sFileB, 3);
            double pErR = tva.GetErrorR(sFileA, sFileB, 3);


            MessageBox.Show("P=" + Math.Round(pPri, 3).ToString()+"\n"+
                            "R=" + Math.Round(pRec, 3).ToString()+"\n"+
                            "F1="+ Math.Round((2*pPri*pRec)/(pPri+pRec), 3).ToString()+"\n"+
                            "ER="+ Math.Round(pErR, 3).ToString()+"\n");

            //MessageBox.Show(Math.Round(p, 3).ToString());

            return;

            //double avgSubSentencsLength = tvic.GetOriAvgLength();

            //MessageBox.Show(avgSubSentencsLength.ToString());

            //tvic.GetTrainSentence("ttttt.txt");


        }

        private void m_btnSpWholeFile_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(ProcessFunction);

            th.Start();
            //ProcessFunction();

        }

        // 函数功能：获取当前已经标记到的位置 
        private int GetCurrentPos(string sFileName2Save)
        {
            StreamReader sr = new StreamReader(sFileName2Save);
            string sFinalPosLine = "";
            string sLine = "";

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();

                if (sLine.IndexOf("/////////////////") >= 0)
                {
                    sFinalPosLine = sLine;
                }
            }

            sr.Close();
            sr.Dispose();

            string []sp = { "::"};
            string[] A = sFinalPosLine.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            if (A.Length == 2)
            {
                return Convert.ToInt32(A[1]);
            }
            else
            {
                return -1;
            }
        }

        // 一个方法，为了启动线程用
        private void ProcessFunction()
        {
            double[] logBase = { 1.414};

            int indxx = 0;

            for (indxx = 0; indxx < logBase.Length; ++indxx)
            {

                WCE_FromFile_DB wco = new WCE_FromFile_DB();
                DBConn db = new DBConn();
                CalcProbCond cpc = new CalcProbCond(db, wco.m_WordDic2, wco.m_WordNums);

                //FindMinH4Sents fmh = new FindMinH4Sents(str,cpc);
                //return;

                PreSplit psl = new PreSplit(cpc);

                //string sFileName = @"D:\分词\越南语分词语料\visegcorpus.txt";
                //string sFileName = @"D:\分词\越南语分词语料1\test.txt";
                //string sFileName2Save = @"D:\分词\越南语分词语料1\visegcorpus_spRes5000_tagged.txt";

                string sFileName = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_test_sents4preseg.txt";
                string sFileName2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_test_preSeg_logbase"+logBase[indxx].ToString()+"_.txt";

                int CurrPos = -1;

                if (File.Exists(sFileName2Save))
                {
                    CurrPos = GetCurrentPos(sFileName2Save);
                }

                List<string> lst = GetLstStrFromFile(sFileName); // 获取文件的 文本行

                StreamWriter sw = new StreamWriter(sFileName2Save, true); // 在文件末尾追加 

                List<viWord> Lvi = new List<viWord>();
                SplitSents sps = new SplitSents(cpc, "");
                sps.m_logBase = logBase[indxx];


                int i = 0;
                int j = 0;

                for (i = 0; i < lst.Count; ++i)
                {
                    if (i <= CurrPos)
                    {
                        //continue;
                    }

                    try
                    {
                        string str = lst[i];

                        List<string> sLst = psl.PreSplit4WordSeg(str);

                        List<string> LLLL = new List<string>();
                        FindMinH4Sents fmh4s = new FindMinH4Sents("", cpc);

                        for (j = 0; j < sLst.Count; ++j)
                        {
                            wordSeg ws = new wordSeg();
                            string[] ta = ws.dowordSeg(sLst[j]);

                            if (ta.Length > 15)
                            {
                                List<string> sl = fmh4s.SplitBy_H(sLst[j]);
                                LLLL = LLLL.Concat(sl).ToList<string>();
                            }
                            else
                            {
                                LLLL.Add(sLst[j]);
                            }

                        }

                        sLst = SplitSomeLongString(LLLL, cpc);   // 再拆分一次
                        sLst = SplitSomeLongString(sLst, cpc);  // 又拆分一次
                        //sLst = SplitSomeLongString(sLst, cpc);  // 第三次拆分，希望这次足够短，太长了 真受不了 啊 ~~~！！

                        m_lbCurrprocPos.Text = "size = :" + cpc.m_DicProHasCalc.Count.ToString();


                        for (j = 0; j < sLst.Count; ++j)
                        {
                            //  m_tbCurrProcContent.Text = sLst[j];

                            List<viWord> ll = sps.doSplit(sLst[j]);



                            Lvi = Lvi.Concat(ll).ToList<viWord>();
                        }

                        //WriteViword2File_Tagged(sw, Lvi, str, i);
                        WriteViword2File_Tagged_SeperatedBY_Space_and_Tab(sw, Lvi, str, i);

                        sw.Flush(); // 写入文件

                        Lvi.Clear();
                    }
                    catch (SystemException see)
                    {
                        MessageBox.Show(see.ToString() + "\n\n" + i.ToString());
                    }

                }

                sw.WriteLine("///////////////////////");
                sw.WriteLine("///////////////////////");
                sw.WriteLine("///////////////////////");
                sw.WriteLine("///////////////////////");

                sw.Close();
                sw.Dispose();
            }

            //MessageBox.Show(sFileName +  "\n分词完成！");
            MessageBox.Show("所有 底 对数 分词完成！");
        }


        /*
         * 函数功能：对一些长的字符串，继续拆分成短的字符串
         * 参数说明：LLL，存储字符串的列表
         *           cpc，数据库查询接口
         * 
         * 返回值：字符串列表
         */

        private List<string> SplitSomeLongString(List<string> LLL, CalcProbCond cpc)
        {
            List<string> Lrt = new List<string>();
            FindMinH4Sents fmh4s = new FindMinH4Sents("", cpc);

            int i = 0;

            for (i = 0; i < LLL.Count; ++ i )
            {
                wordSeg ws = new wordSeg();
                string[] ta = ws.dowordSeg(LLL[i]);

                if (ta.Length > 15)
                {
                    List<string> sl = fmh4s.SplitBy_H(LLL[i]);
                    Lrt = Lrt.Concat(sl).ToList<string>();
                }
                else
                {
                    Lrt.Add(LLL[i]);
                }
            }

            return Lrt;
        }


        /*
         * 函数功能：把分词结果 写入到文件中去 
         * 参数说明：sw，文件流
         *           lvi,分词结果（有些数字被过滤和分解了 ）
         *           str，原始的字符串，用于恢复被过滤的字符
         *           indx，行号
         *           
         * 返回值：无
         * 
         * **/
        private void WriteViword2File(StreamWriter sw,List<viWord> lvi,string str,int indx )
        {
            int i = 0;

            sw.WriteLine("///////////////////////::"+indx.ToString());

            FindMinH4Sents.ResStoreWord(lvi,str);

            for (i = 0; i < lvi.Count; ++i)
            {
                lvi[i].Write2File(sw);
            }
            
        }

        /*
        * 函数功能：把分词结果 写入到文件中去 ,为每个分词结果打上BMES标签，用于神经网络的预训练
         *          注意：分词之前  没  有 过滤 任何标点 和数字
        * 参数说明：sw，文件流
        *           lvi,分词结果（有些数字被过滤和分解了 ）
        *           str，原始的字符串，用于恢复被过滤的字符
        *           indx，行号
        *           
        * 返回值：无
        * 
        * **/
        private void WriteViword2File_Tagged_SeperatedBY_Space_and_Tab(StreamWriter sw, List<viWord> lvi, string str, int indx)
        {
            int i = 0;

            sw.WriteLine("///////////////////////::" + indx.ToString());

            if (lvi.Count == 0)
            {
                return;
            }

            for (i = 0; i < lvi.Count ; ++i)
            {
                lvi[i].Write2File_Tagged(sw);
            }

        }


        /*
         * 函数功能：把分词结果 写入到文件中去 ,为每个分词结果打上BIO标签，用于神经网络的预训练
         * 参数说明：sw，文件流
         *           lvi,分词结果（有些数字被过滤和分解了 ）
         *           str，原始的字符串，用于恢复被过滤的字符
         *           indx，行号
         *           
         * 返回值：无
         * 
         * **/
        private void WriteViword2File_Tagged(StreamWriter sw, List<viWord> lvi, string str, int indx)
        {
            int i = 0;

            sw.WriteLine("");
            sw.WriteLine("///////////////////////::" + indx.ToString());

            if (lvi.Count == 0)
            {
                return;
            }


            FindMinH4Sents.ResStoreWord(lvi, str);

            str = str.ToLower();
            str = wordSeg.FiltPlaceHolder(str);

            int k = 0;
            int FindPosSt = 0;
            viWord v1 = null;
            viWord v2 = null;

            List<viWord> lt = Get_Pre_Seperator(lvi[0], str);
            for (k = 0; k < lt.Count; ++k)
            {
                lt[k].Write2File_Seperator(sw);
            }


            for (i = 0; i < lvi.Count-1; ++i)
            {
                lvi[i].Write2File_Tagged(sw);

                v1 = lvi[i];
                v2 = lvi[i+1];

                List<viWord> Lvsp = Get_A_Seperator(v1, v2, str, FindPosSt);

                for (k = 0; k < Lvsp.Count; ++k)
                {
                    Lvsp[k].Write2File_Seperator(sw);
                }
   
                int t1 = Get_Word_End_Pos(v1, str, FindPosSt);

                if (t1 > 0) // A5520SA 的情况 会导致 两个 
                {
                    FindPosSt = t1;
                }
                else
                {
                    // 什么也不做
                }

                int t2 = Get_Word_Start_Pos(v2, str, FindPosSt); // 下一次查找的起始位置

                if (t2 > 0) // A5520SA 的情况 会导致 两个 
                {
                    FindPosSt = t2;
                }
                else
                {
                    // 什么也不做
                }

            }

            lvi[lvi.Count - 1].Write2File_Tagged(sw); // 把最后一个单词 写入 

            FindPosSt = Get_Word_End_Pos(lvi[lvi.Count - 1],str,FindPosSt);

            List<viWord> Lvf = GetFinal_Seperator(lvi[lvi.Count - 1], str, FindPosSt);

            for (k = 0; k < Lvf.Count; ++k)
            {
                Lvf[k].Write2File_Seperator(sw);
            }
        }

        /*
         * 函数功能：找出单词 v1和 v2之间的 非空格字符，该非空格字符就是单词的 分隔符
         * 参数说明：v1，第一个越南语单词
         *           v2，第二个越南语单词
         *           sLine,原始字符串
         *           FindPosSt，查找起始位置
         *       
         * 返回值：vw，一个天然分隔符构成的越南语单词
         *         null，空格
         * 
         * **/

        private List<viWord> Get_A_Seperator(viWord v1, viWord v2, string sLine, int FindPosSt)
        {
            int v1_endPos = Get_Word_End_Pos(v1,sLine, FindPosSt); // 第一个词结束的下一个位置
            int v2_stPos = Get_Word_Start_Pos(v2,sLine, v1_endPos);// 第二个词开始的位置

            if (v1_endPos < v2_stPos)
            {
                string subStr = sLine.Substring(v1_endPos, v2_stPos-v1_endPos);

                return Get_Seperators_in_str(subStr);

            }

            return new List<viWord>();
        }

        /*
         * 函数功能：获得一个字符串中 用 空格 \t 隔开的 所有 分隔符。
         * 
         * 参数说明：sLine，包含任意分隔符的 字符串
         * 
         * 返回值：分隔符 list
         * 
         */
        private List<viWord> Get_Seperators_in_str(string sLine)
        {
            List<viWord> lst_viw = new List<viWord>();

            if (sLine == null || sLine.Trim().Equals(""))
            {
                return lst_viw;
            }

            List<string> lst = Get_seperatorLst_seperatedby_space(sLine);
            int i = 0;

            for (i = 0; i < lst.Count; ++i)
            {
                viWord vw = new viWord();
                vw.m_sLst.Add(lst[i].Trim());
                lst_viw.Add(vw);
            }
            return lst_viw;

        }

        // 获取 句子 最后的 分隔符 

        /*
         * 函数功能：获得 在句子最后的 若干个 分隔符
         * 
         * 参数说明：v ,一个单词
         *           sLine，一句话
         *           FindPosSt， 这些分隔符的起始位置
         *           
         * 返回值：分隔符（一个分隔符一个viword） list，
         * **/
        private List<viWord> GetFinal_Seperator(viWord v, string sLine, int FindPosSt)
        {
            int Len = sLine.Length - FindPosSt;
            List<viWord> lst_viw = new List<viWord>();


            if (Len > 0)
            {
                string substr = sLine.Substring(FindPosSt,Len);
                return Get_Seperators_in_str(substr);
            }
            return lst_viw;
        }

        // 获取 句子 最 前面 的 分隔符 
        private List<viWord> Get_Pre_Seperator(viWord v, string sLine)
        {
            List<viWord> lst_viw = new List<viWord>();
            int stPos = Get_Word_Start_Pos(v, sLine, 0);// 第二个词开始的位置
            int Len = stPos;

            if (Len > 0)
            {
                string substr = sLine.Substring(0, Len);
                return Get_Seperators_in_str(substr);
            }
            return lst_viw;
        }

        /*
         * 函数功能：用 ‘空格’和‘\t’去拆分一个字符串，返回 字串 list
         * 
         * 参数说明：ss，一个字符串
         * 
         * 返回值：字串 list
         * 
         */
        private List<string> Get_seperatorLst_seperatedby_space(string ss)
        {
            List<string> lst = new List<string>();
            string[] sp = {" ","\t" };// 空格 \t 

            if (ss == null)
            {
                return lst;
            }

            ss = ss.Trim();

            string[] res = ss.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            int i = 0;

            for (i = 0; i < res.Length; ++i)
            {
                lst.Add(res[i]);
            }

            return lst;
        }

        /*
         * 函数功能：计算 单词 vw 在字符串 str中结束位置的 下一个 位置
         * 参数说明：vw，一个单词
         *           str，原始字符串
         *           FindPosSt，查找的起始位置，这个参数保证在有重复单词的情况下 计算结果正确
         *           
         * 返回值:单词结束位置的下一个位置
         */

        private int Get_Word_End_Pos(viWord vw, string str,int FindPosSt)
        {
            int i = 0;
            string subStr = null;
            int pos = 0;


            for (i = 0; i < vw.m_sLst.Count; ++i)
            {
                subStr = vw.m_sLst[i];

                pos = str.IndexOf(subStr, FindPosSt);

                //if (pos < 0|| pos > FindPosSt+8)
                //{
                //    return FindPosSt;
                //}

                FindPosSt = pos + subStr.Length;
            }

            return FindPosSt;
        }

        /*
         * 函数功能：计算越南语单词 vw 在 str中的起始位置
         * 参数说明：vw，越南语单词
         *           str,原始字符串
         *           FindPosSt,查找起始位置
         * 
         * 返回值：pos, vw的起始位置
         *         -1，vw为空
         *         -1，没找到
         */

        private int Get_Word_Start_Pos(viWord vw, string str, int FindPosSt)
        {

            int i = 0;
            string subStr = null;
            int pos = 0;

            for (i = 0; i < vw.m_sLst.Count; ++i)
            {
                subStr = vw.m_sLst[i];

                pos = str.IndexOf(subStr, FindPosSt);

                //if (pos < 0 || pos > FindPosSt + 8) // 非常特殊的情况 ， 可能会找到后面很远的地方去
               // {
                //    return FindPosSt;
               // }

                return pos;
            }

            return -1;
        }






        /*
         * 函数功能: 从文件 按每一行 读出，并返回
         * 参数说明：sFileName，文件名
         * 
         * 返回值：List<string> 没行一个字符串
         *  
         * **/


        private List<string> GetLstStrFromFile(string sFileName)
        {
            List<string> lst = new List<string>();

            StreamReader sr = new StreamReader(sFileName);

            while (!sr.EndOfStream)
            {
                lst.Add(sr.ReadLine());
            }

            sr.Close();
            sr.Dispose();

            return lst;
        }

        /*
         * 函数功能：使用 jaist 语料库 评估 本文方法 和 vnTokenizer的分词结果
         * 
         * **/
        private void m_btnViTest_jaist_Click(object sender, EventArgs e)
        {
            TestVi_jaistCorpus tvj = new TestVi_jaistCorpus();
            
            string sFilePathNameVNT=@"D:\分词\越南语分词语料1\sentsfromcorpus_VnTokenizer_5000.xml";
            string sFilePathNameOA = @"D:\分词\越南语分词语料1\visegcorpus_spRes5000_va_sp_no_inter_check.txt";
            string sFilePathNameCps = @"D:\分词\越南语分词语料1\visegcorpus.txt";

            List<WordsOFSentence> LwVNT = tvj.GetWordsFrom_VnT_SpRes(sFilePathNameVNT);
            List<WordsOFSentence> LwOA = tvj.GetWordsFromFile_OurApproach(sFilePathNameOA);

            List<WordsOFSentence> LwCps = tvj.GetWordsFromCorpus(sFilePathNameCps);


            Test4Vi_Annotation tva = new Test4Vi_Annotation();

           // double simm = tva.GetSimilarity(LwCps, LwOA);

            int odr = 3;

            double pPri = tva.GetPricision(LwCps, LwOA, odr);

            tva.ResetAccessFlag(LwCps);
            tva.ResetAccessFlag(LwOA);


            double pRec = tva.GetReCall(LwCps, LwOA, odr);

            tva.ResetAccessFlag(LwCps);
            tva.ResetAccessFlag(LwOA);

            double pErR = tva.GetErrorRate(LwCps, LwOA, odr);


            MessageBox.Show("P=" + Math.Round(pPri, 3).ToString() + "\n" +
                            "R=" + Math.Round(pRec, 3).ToString() + "\n" +
                            "F1=" + Math.Round((2 * pPri * pRec) / (pPri + pRec), 3).ToString() + "\n" +
                            "ER=" + Math.Round(pErR, 3).ToString() + "\n");



        }

        private void m_btnUniF1_8_2DB_Click(object sender, EventArgs e)
        {
            /// 在统一的句子空间中 写入 1到8 阶 关联词。这样做有个很大的问题，先看下面的越南语句子：
            /// Ai muốn lao động ở nước ngoài, xã làm cầu nối... 500 liệt sĩ! 750 hộ gia đình chính sách! 176 thương binh!...
            ///  在 统一的句子空间中写入1到8阶造成的问题：
            ///  （1）低阶关联词数量会大量 减少，例如上面的句子中，一个关联词都生成不了（因为没有满足8个单词的最短句子长度）。
            ///  （2）数字后面一般都接单位之类的，这些词都很短，这些词没法写入数据库。
            ///  统一句子空间 写入数据库的函数是 ：  Add2AllTbls， 在8阶 关联词 写入函数中 被 调用。
            ///

        }

        private void m_btnProcCONLL2017_Click(object sender, EventArgs e)
        {
            prePreocess_CONLL2017 ppconll2017 = new prePreocess_CONLL2017();

            ppconll2017.get_POS_from_train_dev_test_Dataset();

            //MessageBox.Show("Finish");

            //ppconll2017.get_Raw_sentences_from_train_dev_test_Dataset();
            //ppconll2017.get_PosTag_from_train_dev_test_Dataset();

            //ppconll2017.get_Golden_segmentation_from_train_dev_test_Dataset();
        }

        private void m_btn_proc_jaist_Click(object sender, EventArgs e)
        {
            TestVi_jaistCorpus tjc = new TestVi_jaistCorpus();
            string sfilepathName = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料1\test1.iob2";
            string sfilepathName2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料1\test1_segment_BMES.txt";

            //tjc.Convert_Tag_2_BMES(sfilepathName, sfilepathName2Save);
            //tjc.GetSentencesFromCorpus();

            MessageBox.Show("finish!"); 
        }

        private void m_btnGensin_Click(object sender, EventArgs e)
        {
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08"};

            //string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            StreamWriter sw = new StreamWriter("vinameseText4gensim.txt", false,Encoding.UTF8);

            int i = 0;
 
            string str = null;

            string s1 = ((char)0x200B).ToString(); // 特殊占位字符
            string s2 = ((char)0x00AD).ToString(); // 特殊占位字符

            for (i = 0; i < FilePathName.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathName[i]);
          

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    str = str.Replace(s1, ""); // 过滤掉前面列出的特殊占位字符
                    str = str.Replace(s2, ""); // 

                    str = str.ToLower();

                    str = str.Replace(".", " . ");
                    str = str.Replace(",", " , ");

                    str = str.Replace("(", " ( ");
                    str = str.Replace(")", " ) ");

                    str = str.Replace(":", " : ");
                    str = str.Replace(";", " ; ");

                    str = str.Replace("\"", " \" ");
                    str = str.Replace(" ", " "); // 从文本里面复制过来的，不知道是不是  \t,把它替换为空格

                    str = str.Replace("\t", " ");

                    str = str.Replace("\'", " \' ");
                    str = str.Replace("/", " / ");


                    if (!str.Trim().Equals(""))
                    {
                        sw.WriteLine(str);
                    }

                }
                sr.Dispose();
            }

            sw.Dispose();


            MessageBox.Show("finish!");
        }

        private void m_btnMakeVocabulary_Click(object sender, EventArgs e)
        {
            string sfilename = @"vinameseText4gensim_.txt";
            string sLine = "";
            int i = 0;
            Dictionary<string, int> dic = new Dictionary<string, int>();
            Dictionary<string, int> charDic = new Dictionary<string, int>();

            StreamReader sr = new StreamReader(sfilename, Encoding.UTF8);
            wordSeg ws = new wordSeg();

            long total_WordNum = 0;

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();
                string[] arr = ws.dowordSeg_Seperated_BY_Space_and_Tab(sLine);

                for (i = 0; i < arr.Length; ++i)
                {
                    string aWord = arr[i];
                    if (!dic.ContainsKey(aWord))
                    {
                        //dic[aWord] = 1;
                    }
                    else
                    {
                        //dic[aWord]++;
                    }
                    total_WordNum++;

                    // 以下为统计 字符数量
                    int k=0;
                    for( k =0; k< aWord.Length; ++ k)
                    {
                        string achar = aWord[k].ToString();
                        if (!charDic.ContainsKey(achar))
                        {
                            charDic[achar] = 1;
                        }
                        else
                        {
                            charDic[achar]++;
                        }
                    }

                }
            }

            Dictionary<string,int> dicfinal = dic.OrderByDescending(p=>p.Value).ToDictionary(p => p.Key, o => o.Value);
            Dictionary<string,int> dicCharfinal = charDic.OrderByDescending(p=>p.Value).ToDictionary(p => p.Key, o => o.Value);


            StreamWriter sw = new StreamWriter("nouse__.txt",false,Encoding.UTF8);
            StreamWriter swChar = new StreamWriter("vianameseChars.txt",false,Encoding.UTF8);



            foreach (string word in dicfinal.Keys)
            {
                if (dicfinal[word] > 30)
                {
                    sw.WriteLine(word);
                }
            }

            foreach (string word in dicCharfinal.Keys)
            {
                if (dicCharfinal[word] > 200)// 为什么要大于200，不断地测试，感觉200比较合理了
                {
                    swChar.WriteLine(word);
                }
            }

            sr.Dispose();
            sw.Dispose();
            swChar.Dispose();

            MessageBox.Show(total_WordNum.ToString());

        }

        private void m_btn_count_length_Click(object sender, EventArgs e)
        {
            string[] filenames = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase1.414_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase1.732_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase2_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase2.718_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase3.84_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase4_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase5.76_.txt",
                                   @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_train_preSeg_logbase6.18_.txt"
                                  };

            int i = 0;
            string sL = "";
            string[] sp = { " ", "  " };// 空格，tab

            for (i = 0; i < filenames.Length; ++i)
            {
                StreamReader sr = new StreamReader(filenames[i], Encoding.UTF8);

                int sumLen = 0;
                int n = 0;

                while (!sr.EndOfStream)
                {
                    sL = sr.ReadLine();

                    if (sL.Trim().Equals(""))
                    {
                        continue;
                    }

                    
                    string[] res = sL.Split();

                    if (res.Length == 2 && (res[1].Trim().Equals("B") || res[1].Trim().Equals("S")))
                    {
                        n++;
                        sumLen += 1;
                    }
                    else if (res.Length == 2)
                    {
                        sumLen += 1;
                    }

                    

                }

                sr.Dispose();

                MessageBox.Show(filenames[i] + "\n" + ((double)sumLen / n).ToString());

            }

        }

        private void m_btn_statViword_3th_Click(object sender, EventArgs e)
        {
            string[] FilePathName = {@"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00",
                                     @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_01",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_02",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_03",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_04",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_05",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_06",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_07",
                                    @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_08",
                                    @"D:\新闻爬取\dantri.txt",
                                    @"D:\新闻爬取\laodong.txt",
                                    @"D:\新闻爬取\tuoitre.txt",
                                    @"D:\新闻爬取\vietnamnet.txt",
                                    @"D:\新闻爬取\vnexpress.txt"
                                    };

            //string[] tt = { @"D:\C_Sharp_Proj\ViWordAna\Corpus\wiki_00" };

            StreamWriter sw = new StreamWriter("Viwords_Cased.txt", false);
            wordCoExist_O2 wco2 = new wordCoExist_O2(FilePathName);

            m_lbStatus.Text = "";
            UInt32 num = wco2.ExtractWords_cased(m_lbStatus);

            wco2.SaveWords(sw);

            sw.Close();
            sw.Dispose();

            MessageBox.Show(num.ToString());
        }

    }

    
}
