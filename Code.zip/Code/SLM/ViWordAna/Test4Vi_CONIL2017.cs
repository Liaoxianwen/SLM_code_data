﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace ViWordAna
{
    /*
     * 类说明：比较结果的表示，总共多少个，，正确的多少个。。
     *
     */
    public class CmpRes
    {
        public CmpRes()
        {
        }

        public int m_Correct=0; // 正确的多少个
        public int m_Total=0;   // 总共的多少个
    }


    /////===============    Another Class      ====================//////////

    /*
     * 类说明：本类用于对CONIL2017 越南语料库的测试，测试的内容：
     * （1）长句拆分成短句时 句子长度减少的幅度；
     * （2）本模型的分词准确率
     * （3）和vnTokenier 分词对比，包括准确率，二阶词、三阶词等的分词准确率 和 召回率
     * 
     */

    public class viWord
    {
        public viWord()
        {

        }

        /*
         * 函数功能：运算符等号重载
         * 参数说明：v1,运算数1
         *           v2,运算数2
         *           
         * 返回值：true or false
         * **/

        public static bool operator ==(viWord v1, viWord v2) // 这样重载运算符之后，无法调用 v==null,因为方法中的v1.m_sLst语句会出错（空无法引用成员）
        {

            if (v1.m_sLst.Count != v2.m_sLst.Count)
            {
                return false;
            }

            int i = 0;

            for (i = 0; i < v1.m_sLst.Count; ++i)
            {
                if (!v1.m_sLst[i].Equals(v2.m_sLst[i]))
                {
                    return false;
                }
            }

            return true;
        }

        public static bool operator !=(viWord v1, viWord v2)
        {
            return !(v1 == v2);
        }

        /*
         * 函数功能：判断该单词是否是纯数字
         * 参数说明:无，
         * 返回值:单词是数字，true,否则 false
         */

        public bool isNum()
        {
            int i = 0;
            int j = 0;

            for (i = 0; i < m_sLst.Count; ++i)
            {
                for (j = 0; j < m_sLst[i].Length; ++j)
                {
                    if (!isDigit(m_sLst[i][j]))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        /*
         * 函数功能：判断字符 c 不是数字
         * 参数说明：c,一个字符
         * 
         * 返回值：是0到9之间的数字，返回true，都在返回false
         * 
         */
        private bool isDigit( char c)
        {
            int i = 0;

            for (i = 0; i < m_cA.Length; ++i)
            {
                if (m_cA[i] == c)
                {
                    return true;
                }
            }

            return false;
        }

        /*
         * 函数功能：把该分词写入到文件中去
         * 参数说明：sw，文件流
         * 返回值：无
         * 
         */
        public void Write2File(StreamWriter sw)
        {
            if(m_sLst.Count == 0 )
            {
                return ;
            }

            int i = 0;
            string str = m_sLst[0];

            for (i = 1; i < m_sLst.Count; ++i)
            {
                str+=" "+m_sLst[i];
            }

            sw.WriteLine( str);
        }

        /*
         * 函数功能：把该分词 形成 标签 写入到文件中去
         * 参数说明：sw，文件流
         * 返回值：无
         * 
         */
        public void Write2File_Tagged(StreamWriter sw)
        {
            if (m_sLst.Count == 0)
            {
                return;
            }

            if (m_sLst.Count == 1)
            {
                sw.WriteLine(m_sLst[0] + " S");
                return;
            }


            int i = 0;
            string str = m_sLst[0]+" B";
            sw.WriteLine(str);
            str = "";

            for (i = 1; i < m_sLst.Count-1; ++i)
            {
                str = m_sLst[i]+" M";
                sw.WriteLine(str);

                str = "";
            }

            str = m_sLst[m_sLst.Count - 1] + " E";
            sw.WriteLine(str);

        }

        /*
        * 函数功能：把该分词 标签(BMES) 写入到文件中去
        * 参数说明：sw，文件流
        * 返回值：无
        * 
        */
        public void Write2File_Tagged_BMES(StreamWriter sw)
        {
            if ( m_sLst==null || m_sLst.Count == 0 )
            {
                return;
            }

            if (m_sLst.Count == 1)
            {
                sw.WriteLine(m_sLst[0] + " S");
            }
            else if (m_sLst.Count == 2)
            {
                sw.WriteLine(m_sLst[0] + " B");
                sw.WriteLine(m_sLst[1] + " E");

            }
            else if (m_sLst.Count >= 3)
            {
                int i = 0;
                sw.WriteLine(m_sLst[0] + " B");

                for (i = 1; i < m_sLst.Count - 1; ++i)
                {
                    sw.WriteLine(m_sLst[i] + " M");
                }

                sw.WriteLine(m_sLst[m_sLst.Count - 1] + " E");
            }

        }

        // 把 分隔符 写入到文件 
        public void Write2File_Seperator(StreamWriter sw)
        {
            if (m_sLst.Count == 0)
            {
                return;
            }
           
            string str = m_sLst[0] + " S";
            sw.WriteLine(str);
        }



        private char[] m_cA = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9','%',',' }; // 用","表示小数点
        public List<string> m_sLst = new List<string>(); // 该词 包含的 子串
        public bool m_bHasAccess = false;
    }


    /////===============    Another Class      ====================//////////


    /*
     * 类说明：用来表达人工标注语料库中的一个句子（这个句子有可能是一个长句，包含逗号之类的天然分隔符），
     *         还包括该句人工标注的标准分词结果
     *         还可以去掉标准结果中的数字，以便和我们的方法进行比较
     */
    public class ViSentsInCONIL2017
    {
        public ViSentsInCONIL2017(string str)
        {
            m_str = str;
        }

        /*
         * 函数功能：获取一个长句 的（被天然分隔符分隔的）子句，因为一个长句有可能被 逗号之类的分隔符分隔。
         * 参数说明：无
         * 返回值：子句列表
         */
        public List<string> GetSubSentences()
        {
            List<string> Lrt = new List<string>();

            if( m_str == null )
            {
                return Lrt;
            }

            string[] sents = m_str.Split(m_sentsSP, StringSplitOptions.RemoveEmptyEntries);

            int i = 0;
            for (i = 0; i < sents.Length; ++i)
            {
                Lrt.Add(sents[i]);
            }

            return Lrt;

        }

        /*
         * 函数功能：获取 语料库中人工标注的 标准分词结果
         * 参数说明：无
         * 返回值：人工标注的标注分词结果（一个list）
         * **/

        List<viWord> GetLStdWordSeg()
        {
            return m_LStdWordSeg;
        }

        /*
         * 函数功能：从人工标注的标注分词中 去除 数字 和 标点符号
         * 参数说明:无
         * 
         * 返回值：只包含字母的 越南语 词组
         * **/

        List<viWord> GetStdActualWords()
        {
            int i = 0;
            List<viWord> Lst = new List<viWord>();

            for (i = 0; i < m_LStdWordSeg.Count; ++i)
            {
                if (!m_LStdWordSeg[i].isNum())
                {
                    Lst.Add(m_LStdWordSeg[i]);
                }
            }

            return Lst;
        }

        /*
         * 函数功能：把人工标准分词结果 写到文件！
         * 参数说明：写文件流
         * 
         * 返回值：无
         * 
         */
        public void Write2File(StreamWriter sw)
        {
            sw.WriteLine("OriText:" + m_str);

            List<viWord> lvi = m_LStdWordSeg; // 在这里可以稍微改变一下，把去掉数字之后的人工分词结果写入到文件中
            int i = 0;

            for (i = 0; i < lvi.Count; ++i)
            {
                lvi[i].Write2File(sw);
            }

        }

        /*
         * 函数功能：把分词结果保存到文件中去 
         * 参数说明:Lvw，结果列表
         * 返回值：无
         * 
         */

        private void SaveSplitResult(List<viWord> Lvw)
        {
            int i = 0;

            StreamWriter sw = new StreamWriter("SplitResult.txt", false);

            for (i = 0; i < Lvw.Count; ++i)
            {
                Lvw[i].Write2File(sw);
            }

            sw.Close();
            sw.Dispose();
        }

        /*
         * 函数功能：把我们方法的分词结果同 标准分词 结果进行比较
         * 参数说明：无，（隐含参数包括了当前句子，和标准分词结果）
         * 
         * 返回值：比较结果
         * 
         */
        public CmpRes CMPOurApproach_StandardWdSeg(CalcProbCond cpc,StreamWriter sw)
        {
            CmpRes cr = new CmpRes();
            int i = 0;

            cpc.m_DicProHasCalc.Clear();

            // 第一步：先获取所有的子句

            PreSplit ps = new PreSplit(cpc);

            List<string> Lsts = ps.PreSplit4WordSeg(m_str);//GetSubSentences();

            // 第二步：再用我们的方法进行分词

            List<viWord> Lvw = new List<viWord>();

            for (i = 0; i < Lsts.Count; ++i)
            {
                string str = Lsts[i];

                SplitSents sps = new SplitSents(cpc, str);

                List<viWord> lt= sps.doSplit(str);

                Lvw=Lvw.Concat(lt).ToList<viWord>();

            }

            SaveSplitResult(Lvw);

              // 第三步：比较本方法分词结果和 去掉数字的标准分词结果

            List<viWord> Lstd = GetStdActualWords();
            int numofCorrect = 0;
           

            sw.WriteLine("========  "+m_cnt.ToString()+" ==========");
            m_cnt++;

            for (i = 0; i < Lvw.Count; ++i)
            {
                Lvw[i].Write2File(sw);

                if (isInLst(Lvw[i], Lstd))
                {
                    numofCorrect++;
                }
            }

            cr.m_Correct = numofCorrect;
            cr.m_Total = Lvw.Count;

            return cr;
        }


        private bool isInLst( viWord vw,List<viWord> LStd )
        {
            int i = 0;

            for (i = 0; i < LStd.Count; ++i)
            {
                if (vw == LStd[i])
                {
                    return true;
                }
            }

            return false;

        }


        public string m_str = null;
        private string[] m_sentsSP = {",","\"",".","!",":"}; // 越南语句子之间的分隔符
        public List<viWord> m_LStdWordSeg = new List<viWord>(); // 存储标准分词结果

        private static int m_cnt = 0;
    }


    /////===============    Another Class      ====================//////////

    /*
     *类说明：对 越南语 CONIL2017 语料库进行测试。
     * 
     */
    public class Test4Vi_CONIL2017
    {
        public Test4Vi_CONIL2017(string sFilePathName)
        {
            m_sFilePathName = sFilePathName;
            GetAllSentenceObj();
        }

        public Test4Vi_CONIL2017(string sFilePathName,bool isText)
        {

            List<string> lst = new List<string>();

            if (isText)
            {
                StreamReader sr = new StreamReader(sFilePathName);

                while (!sr.EndOfStream)
                {
                    string ss = sr.ReadLine();

                    ViSentsInCONIL2017 vic = new ViSentsInCONIL2017(ss);

                    m_Lvisents.Add(vic);
                }
            }

            ////////////////////////////////

            int i = 0;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            DBConn db = new DBConn();
            CalcProbCond cpc = new CalcProbCond(db, wco.m_WordDic2, wco.m_WordNums);

            CmpRes crFinal = new CmpRes();

            StreamWriter sw = new StreamWriter("vnexp_splitRes.txt", false);



            for (i = 0; i < m_Lvisents.Count; ++i)
            {
                //MessageBox.Show(i.ToString());

                StreamWriter sw1 = new StreamWriter(i.ToString() + ".txt", false);
                sw1.WriteLine(i.ToString());
                sw1.Close();
                sw1.Dispose();

                CmpRes cr = m_Lvisents[i].CMPOurApproach_StandardWdSeg(cpc, sw);

                crFinal.m_Correct += cr.m_Correct;
                crFinal.m_Total += cr.m_Total;

            }

            sw.Close();
            sw.Dispose();

            MessageBox.Show("正确率是：" + ((double)crFinal.m_Correct) / crFinal.m_Total);



        }

        /*
         * 函数功能：从文件中读取 所有的句子对象，包括原始的句子和人工标准分词分词结果 。
         * 参数说明：无
         * 返回值：无
         */
        private void GetAllSentenceObj()
        {
         
            StreamReader sr = new StreamReader(m_sFilePathName);
            string sLine = null;

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();

doagain:
                if (isSentsBegin(sLine))
                {
                    sLine = sr.ReadLine(); // 原始 句子行 
                    ViSentsInCONIL2017 vsc = new ViSentsInCONIL2017(GetOriginalSents(sLine));

                    while (!sr.EndOfStream)
                    {
                        sLine = sr.ReadLine();

                        if (isSentsBegin(sLine)) // 是句块的 开始 
                        {
                            m_Lvisents.Add(vsc);
                            goto doagain;               // goto 语句用起来还是比较方便的。
                        }
                        else
                        {
                            viWord vw = GetViWord(sLine);
                            vsc.m_LStdWordSeg.Add(vw);
                        }

                    }

                    m_Lvisents.Add(vsc);
                }


            }
        }

        /*
         * 函数功能：把从语料库文件中读取出来的原始句子 和 人工标准分词结果 写入到文件中去
         * 参数说明：sFileName，文件名
         * 返回值：无
         * 
         */

        public void Write2File(string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);

            int i = 0;

            for (i = 0; i < m_Lvisents.Count; ++i)
            {
                m_Lvisents[i].Write2File(sw);
            }

            sw.Close();
            sw.Dispose();
        }

        /*
         * 函数功能：判断一个字符串是不是 一个句子块的开始
         * 参数说明：sLine，从文件中读取出来的一行（一个字符串）
         * 
         * 返回值：true，是句子块的开始
         *         false,不是
         */
        private bool isSentsBegin(string sLine)
        {
            if (sLine.IndexOf("#") >= 0 && sLine.IndexOf("sent_id") > 0 && sLine.IndexOf("=") > 0)
            {
                return true;
            }

            return false;
        }

        /*
         * 函数功能：从一行字符串中提取 原始 句子
         * 参数说明：sLine一行字符串
         * 返回值：一个字符串
         * 
         */
        private string GetOriginalSents( string sLine )
        {
            int sentST = sLine.IndexOf("=");

            string str = sLine.Substring(sentST + 1);

            return str;
        }

        /*
         * 函数功能：从一行字符串中提取出一个越南语 词组（可能包括多个越南语单词）
         * 参数说明：sLine，一个字符串
         * 
         * 返回值：一个越南语词组（可能包括多个越南单词）
         */


        private viWord GetViWord(string sLine)
        {
            string[] sp = { "	", "	"," ","	" };
            viWord vw = new viWord();

            if (sLine.IndexOf("PUNCT") > 0 && sLine.IndexOf("punct") > 0) // 标点符号
            {
                return vw;
            }

            string[] strs = sLine.Split(sp,StringSplitOptions.RemoveEmptyEntries);

            int num = strs.Length - 8;

            if (num % 2 != 0) // 格式出现了问题 
            {
                return vw;
            }

            int i = 0;
            

            for (i = 0; i < num / 2; ++i)
            {
                vw.m_sLst.Add(strs[1+i].Trim());
            }

            return vw;

        }


        /*
         * 函数功能：使用空格把一个字符串 进行拆分
         * 参数说明：str，一个字符串
         * 
         * 返回值：字符串数组
         * 
         */
        private string[] SplitstringBySpace(string str)
        {
            string[] sp = { " "};

            string[] arr = str.Split(sp,StringSplitOptions.RemoveEmptyEntries);

            return arr;
        }


        /*
         * 函数功能：把所有原始句子都写入到文件中
         * 参数说明：sTrainSentsFile，文件名
         * 
         * 返回值：无
         */


        public void GetTrainSentence(string sTrainSentsFile)
        {
            StreamWriter sw = new StreamWriter(sTrainSentsFile,false);
            int i = 0;

            for (i = 0; i < m_Lvisents.Count; ++i)
            {
                sw.WriteLine(m_Lvisents[i].m_str);
            }

            sw.Close();
            sw.Dispose();
        }


        /*
         * 函数功能：获取原始句子中的 “子句”平均句子长度，用于比较 算法 句子拆分 前后 句子长度的对比
         * 参数说明：
         * 返回值：子句平均句子长度
         * **/

        public double GetOriAvgLength()
        {

            if (m_Lvisents.Count == 0)
            {
                return 0;
            }

            int i = 0;
            double numofWords = 0;
            double numofSents = 0;
            int maxLen = -100;

            for (i = 0; i < m_Lvisents.Count; ++i)
            {
                List<string> lsub = m_Lvisents[i].GetSubSentences();
                numofSents += lsub.Count;

                int j = 0;

                for (j = 0; j < lsub.Count; ++j)
                {
                    string[] arr = SplitstringBySpace(lsub[j]);

                    numofWords += arr.Length;

                    if (arr.Length > maxLen)
                    {
                        maxLen = arr.Length;
                    }
                }
            }

            MessageBox.Show("句子的最大长度是："+maxLen.ToString());
            return numofWords / numofSents;
        }


        public void DoCompareWithStandard()
        {
            int i = 0;

            WCE_FromFile_DB wco = new WCE_FromFile_DB();
            DBConn db = new DBConn();
            CalcProbCond cpc = new CalcProbCond(db, wco.m_WordDic2, wco.m_WordNums);

            CmpRes crFinal = new CmpRes();

            StreamWriter sw = new StreamWriter("禁毒_vnexp_Our_splitRes.txt", false);

            

            for (i = 0; i < m_Lvisents.Count; ++i)
            {
                //MessageBox.Show(i.ToString());

                StreamWriter sw1 = new StreamWriter(i.ToString()+".txt",false);
                sw1.WriteLine(i.ToString());
                sw1.Close();
                sw1.Dispose();

                CmpRes cr = m_Lvisents[i].CMPOurApproach_StandardWdSeg(cpc,sw);

                crFinal.m_Correct += cr.m_Correct;
                crFinal.m_Total += cr.m_Total;

            }

            sw.Close();
            sw.Dispose();

            MessageBox.Show("正确率是："+((double)crFinal.m_Correct)/crFinal.m_Total);

        }

        private string m_sFilePathName = null;
        public List<ViSentsInCONIL2017> m_Lvisents = new List<ViSentsInCONIL2017>();

    }
}
