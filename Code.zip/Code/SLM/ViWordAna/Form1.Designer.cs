﻿namespace ViWordAna
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.m_btnLoadViFile = new System.Windows.Forms.Button();
            this.m_btnTest = new System.Windows.Forms.Button();
            this.m_timer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.m_lbStatus = new System.Windows.Forms.Label();
            this.m_btnGenCoArr = new System.Windows.Forms.Button();
            this.m_btnWSeg = new System.Windows.Forms.Button();
            this.m_btnProbWatch = new System.Windows.Forms.Button();
            this.m_btnMk3Order = new System.Windows.Forms.Button();
            this.m_btnSSplit3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.m_btnMk1Order = new System.Windows.Forms.Button();
            this.m_btnUniF1_8_2DB = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.m_btnMk8Order = new System.Windows.Forms.Button();
            this.m_btnMk7Order = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.m_btnMk6Order = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.m_btnMk5Order = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.m_btnMk4Order = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.m_btnViTest_jaist = new System.Windows.Forms.Button();
            this.m_btnViTest = new System.Windows.Forms.Button();
            this.m_btnSplit_6 = new System.Windows.Forms.Button();
            this.m_btnSpWholeFile = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.m_lbCurrprocPos = new System.Windows.Forms.Label();
            this.m_tbCurrProcContent = new System.Windows.Forms.TextBox();
            this.m_btnProcCONLL2017 = new System.Windows.Forms.Button();
            this.m_btn_proc_jaist = new System.Windows.Forms.Button();
            this.m_btnGensin = new System.Windows.Forms.Button();
            this.m_btnMakeVocabulary = new System.Windows.Forms.Button();
            this.m_btn_count_length = new System.Windows.Forms.Button();
            this.m_btn_statViword_3th = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_btnLoadViFile
            // 
            this.m_btnLoadViFile.Location = new System.Drawing.Point(25, 21);
            this.m_btnLoadViFile.Name = "m_btnLoadViFile";
            this.m_btnLoadViFile.Size = new System.Drawing.Size(83, 24);
            this.m_btnLoadViFile.TabIndex = 0;
            this.m_btnLoadViFile.Text = "统计单字";
            this.m_btnLoadViFile.UseVisualStyleBackColor = true;
            this.m_btnLoadViFile.Click += new System.EventHandler(this.m_btnLoadViFile_Click);
            // 
            // m_btnTest
            // 
            this.m_btnTest.Location = new System.Drawing.Point(642, 22);
            this.m_btnTest.Name = "m_btnTest";
            this.m_btnTest.Size = new System.Drawing.Size(75, 23);
            this.m_btnTest.TabIndex = 1;
            this.m_btnTest.Text = "test";
            this.m_btnTest.UseVisualStyleBackColor = true;
            this.m_btnTest.Click += new System.EventHandler(this.m_btnTest_Click);
            // 
            // m_timer
            // 
            this.m_timer.Enabled = true;
            this.m_timer.Interval = 1000;
            this.m_timer.Tick += new System.EventHandler(this.OnTimer);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "当前处理的文件：";
            // 
            // m_lbStatus
            // 
            this.m_lbStatus.AutoSize = true;
            this.m_lbStatus.Location = new System.Drawing.Point(96, 272);
            this.m_lbStatus.Name = "m_lbStatus";
            this.m_lbStatus.Size = new System.Drawing.Size(29, 12);
            this.m_lbStatus.TabIndex = 3;
            this.m_lbStatus.Text = "文件";
            // 
            // m_btnGenCoArr
            // 
            this.m_btnGenCoArr.Location = new System.Drawing.Point(15, 47);
            this.m_btnGenCoArr.Name = "m_btnGenCoArr";
            this.m_btnGenCoArr.Size = new System.Drawing.Size(84, 23);
            this.m_btnGenCoArr.TabIndex = 4;
            this.m_btnGenCoArr.Text = "生成2阶关联";
            this.m_btnGenCoArr.UseVisualStyleBackColor = true;
            this.m_btnGenCoArr.Click += new System.EventHandler(this.m_btnGenCoArr_Click);
            // 
            // m_btnWSeg
            // 
            this.m_btnWSeg.Location = new System.Drawing.Point(31, 27);
            this.m_btnWSeg.Name = "m_btnWSeg";
            this.m_btnWSeg.Size = new System.Drawing.Size(75, 23);
            this.m_btnWSeg.TabIndex = 5;
            this.m_btnWSeg.Text = "2阶分词";
            this.m_btnWSeg.UseVisualStyleBackColor = true;
            this.m_btnWSeg.Click += new System.EventHandler(this.m_btnWSeg_Click);
            // 
            // m_btnProbWatch
            // 
            this.m_btnProbWatch.Location = new System.Drawing.Point(25, 238);
            this.m_btnProbWatch.Name = "m_btnProbWatch";
            this.m_btnProbWatch.Size = new System.Drawing.Size(75, 23);
            this.m_btnProbWatch.TabIndex = 6;
            this.m_btnProbWatch.Text = "概率观察";
            this.m_btnProbWatch.UseVisualStyleBackColor = true;
            this.m_btnProbWatch.Click += new System.EventHandler(this.m_btnProbWatch_Click);
            // 
            // m_btnMk3Order
            // 
            this.m_btnMk3Order.Location = new System.Drawing.Point(15, 74);
            this.m_btnMk3Order.Name = "m_btnMk3Order";
            this.m_btnMk3Order.Size = new System.Drawing.Size(84, 23);
            this.m_btnMk3Order.TabIndex = 7;
            this.m_btnMk3Order.Text = "生成3阶关联";
            this.m_btnMk3Order.UseVisualStyleBackColor = true;
            this.m_btnMk3Order.Click += new System.EventHandler(this.m_btnMk3Order_Click);
            // 
            // m_btnSSplit3
            // 
            this.m_btnSSplit3.Location = new System.Drawing.Point(31, 56);
            this.m_btnSSplit3.Name = "m_btnSSplit3";
            this.m_btnSSplit3.Size = new System.Drawing.Size(75, 23);
            this.m_btnSSplit3.TabIndex = 8;
            this.m_btnSSplit3.Text = "3阶分词";
            this.m_btnSSplit3.UseVisualStyleBackColor = true;
            this.m_btnSSplit3.Click += new System.EventHandler(this.m_btnSSplit3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.m_btnMk1Order);
            this.groupBox1.Controls.Add(this.m_btnUniF1_8_2DB);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.m_btnMk8Order);
            this.groupBox1.Controls.Add(this.m_btnMk7Order);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.m_btnMk6Order);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.m_btnMk5Order);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.m_btnMk4Order);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.m_btnGenCoArr);
            this.groupBox1.Controls.Add(this.m_btnMk3Order);
            this.groupBox1.Location = new System.Drawing.Point(310, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 237);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "n阶词关联";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(107, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 12);
            this.label10.TabIndex = 22;
            this.label10.Text = "（写到数据库）";
            // 
            // m_btnMk1Order
            // 
            this.m_btnMk1Order.Location = new System.Drawing.Point(15, 20);
            this.m_btnMk1Order.Name = "m_btnMk1Order";
            this.m_btnMk1Order.Size = new System.Drawing.Size(84, 23);
            this.m_btnMk1Order.TabIndex = 21;
            this.m_btnMk1Order.Text = "生成1阶关联";
            this.m_btnMk1Order.UseVisualStyleBackColor = true;
            this.m_btnMk1Order.Click += new System.EventHandler(this.m_btnMk1Order_Click);
            // 
            // m_btnUniF1_8_2DB
            // 
            this.m_btnUniF1_8_2DB.Location = new System.Drawing.Point(202, 158);
            this.m_btnUniF1_8_2DB.Name = "m_btnUniF1_8_2DB";
            this.m_btnUniF1_8_2DB.Size = new System.Drawing.Size(108, 54);
            this.m_btnUniF1_8_2DB.TabIndex = 20;
            this.m_btnUniF1_8_2DB.Text = "统一句子空间1-8阶写到数据库";
            this.m_btnUniF1_8_2DB.UseVisualStyleBackColor = true;
            this.m_btnUniF1_8_2DB.Click += new System.EventHandler(this.m_btnUniF1_8_2DB_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(105, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 12);
            this.label8.TabIndex = 19;
            this.label8.Text = "（写到数据库）";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(107, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 12);
            this.label7.TabIndex = 18;
            this.label7.Text = "（写到数据库）";
            // 
            // m_btnMk8Order
            // 
            this.m_btnMk8Order.Location = new System.Drawing.Point(15, 208);
            this.m_btnMk8Order.Name = "m_btnMk8Order";
            this.m_btnMk8Order.Size = new System.Drawing.Size(84, 23);
            this.m_btnMk8Order.TabIndex = 17;
            this.m_btnMk8Order.Text = "生成8阶关联";
            this.m_btnMk8Order.UseVisualStyleBackColor = true;
            this.m_btnMk8Order.Click += new System.EventHandler(this.m_btnMk8Order_Click);
            // 
            // m_btnMk7Order
            // 
            this.m_btnMk7Order.Location = new System.Drawing.Point(15, 182);
            this.m_btnMk7Order.Name = "m_btnMk7Order";
            this.m_btnMk7Order.Size = new System.Drawing.Size(84, 23);
            this.m_btnMk7Order.TabIndex = 16;
            this.m_btnMk7Order.Text = "生成7阶关联";
            this.m_btnMk7Order.UseVisualStyleBackColor = true;
            this.m_btnMk7Order.Click += new System.EventHandler(this.m_btnMk7Order_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(105, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "（写到数据库）";
            // 
            // m_btnMk6Order
            // 
            this.m_btnMk6Order.Location = new System.Drawing.Point(15, 154);
            this.m_btnMk6Order.Name = "m_btnMk6Order";
            this.m_btnMk6Order.Size = new System.Drawing.Size(84, 25);
            this.m_btnMk6Order.TabIndex = 14;
            this.m_btnMk6Order.Text = "生成6阶关联";
            this.m_btnMk6Order.UseVisualStyleBackColor = true;
            this.m_btnMk6Order.Click += new System.EventHandler(this.m_btnMk6Order_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(105, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "（写到数据库）";
            // 
            // m_btnMk5Order
            // 
            this.m_btnMk5Order.Location = new System.Drawing.Point(15, 128);
            this.m_btnMk5Order.Name = "m_btnMk5Order";
            this.m_btnMk5Order.Size = new System.Drawing.Size(84, 23);
            this.m_btnMk5Order.TabIndex = 12;
            this.m_btnMk5Order.Text = "生成5阶关联";
            this.m_btnMk5Order.UseVisualStyleBackColor = true;
            this.m_btnMk5Order.Click += new System.EventHandler(this.m_btnMk5Order_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(105, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "（写到数据库）";
            // 
            // m_btnMk4Order
            // 
            this.m_btnMk4Order.Location = new System.Drawing.Point(15, 101);
            this.m_btnMk4Order.Name = "m_btnMk4Order";
            this.m_btnMk4Order.Size = new System.Drawing.Size(84, 23);
            this.m_btnMk4Order.TabIndex = 10;
            this.m_btnMk4Order.Text = "生成4阶关联";
            this.m_btnMk4Order.UseVisualStyleBackColor = true;
            this.m_btnMk4Order.Click += new System.EventHandler(this.m_btnMk4Order_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(105, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "（写到数据库）";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(107, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "（写到数据库）";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.m_btnViTest_jaist);
            this.groupBox2.Controls.Add(this.m_btnViTest);
            this.groupBox2.Controls.Add(this.m_btnSplit_6);
            this.groupBox2.Controls.Add(this.m_btnWSeg);
            this.groupBox2.Controls.Add(this.m_btnSSplit3);
            this.groupBox2.Location = new System.Drawing.Point(114, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(190, 220);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "分词测试";
            // 
            // m_btnViTest_jaist
            // 
            this.m_btnViTest_jaist.Location = new System.Drawing.Point(31, 188);
            this.m_btnViTest_jaist.Name = "m_btnViTest_jaist";
            this.m_btnViTest_jaist.Size = new System.Drawing.Size(121, 23);
            this.m_btnViTest_jaist.TabIndex = 11;
            this.m_btnViTest_jaist.Text = "ViTest(Jaist)";
            this.m_btnViTest_jaist.UseVisualStyleBackColor = true;
            this.m_btnViTest_jaist.Click += new System.EventHandler(this.m_btnViTest_jaist_Click);
            // 
            // m_btnViTest
            // 
            this.m_btnViTest.Location = new System.Drawing.Point(31, 159);
            this.m_btnViTest.Name = "m_btnViTest";
            this.m_btnViTest.Size = new System.Drawing.Size(121, 23);
            this.m_btnViTest.TabIndex = 10;
            this.m_btnViTest.Text = "ViTest(Manual)";
            this.m_btnViTest.UseVisualStyleBackColor = true;
            this.m_btnViTest.Click += new System.EventHandler(this.m_btnViTest_Click);
            // 
            // m_btnSplit_6
            // 
            this.m_btnSplit_6.Location = new System.Drawing.Point(31, 132);
            this.m_btnSplit_6.Name = "m_btnSplit_6";
            this.m_btnSplit_6.Size = new System.Drawing.Size(75, 23);
            this.m_btnSplit_6.TabIndex = 9;
            this.m_btnSplit_6.Text = "6阶分词";
            this.m_btnSplit_6.UseVisualStyleBackColor = true;
            this.m_btnSplit_6.Click += new System.EventHandler(this.m_btnSplit_6_Click);
            // 
            // m_btnSpWholeFile
            // 
            this.m_btnSpWholeFile.Location = new System.Drawing.Point(161, 238);
            this.m_btnSpWholeFile.Name = "m_btnSpWholeFile";
            this.m_btnSpWholeFile.Size = new System.Drawing.Size(90, 23);
            this.m_btnSpWholeFile.TabIndex = 11;
            this.m_btnSpWholeFile.Text = "整个文件分词";
            this.m_btnSpWholeFile.UseVisualStyleBackColor = true;
            this.m_btnSpWholeFile.Click += new System.EventHandler(this.m_btnSpWholeFile_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(579, 266);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 12;
            this.label9.Text = "当前：";
            // 
            // m_lbCurrprocPos
            // 
            this.m_lbCurrprocPos.AutoSize = true;
            this.m_lbCurrprocPos.Location = new System.Drawing.Point(625, 266);
            this.m_lbCurrprocPos.Name = "m_lbCurrprocPos";
            this.m_lbCurrprocPos.Size = new System.Drawing.Size(11, 12);
            this.m_lbCurrprocPos.TabIndex = 13;
            this.m_lbCurrprocPos.Text = "0";
            // 
            // m_tbCurrProcContent
            // 
            this.m_tbCurrProcContent.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.m_tbCurrProcContent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.m_tbCurrProcContent.ForeColor = System.Drawing.Color.Red;
            this.m_tbCurrProcContent.Location = new System.Drawing.Point(642, 50);
            this.m_tbCurrProcContent.Multiline = true;
            this.m_tbCurrProcContent.Name = "m_tbCurrProcContent";
            this.m_tbCurrProcContent.ReadOnly = true;
            this.m_tbCurrProcContent.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.m_tbCurrProcContent.Size = new System.Drawing.Size(75, 191);
            this.m_tbCurrProcContent.TabIndex = 15;
            // 
            // m_btnProcCONLL2017
            // 
            this.m_btnProcCONLL2017.Cursor = System.Windows.Forms.Cursors.Default;
            this.m_btnProcCONLL2017.Location = new System.Drawing.Point(25, 50);
            this.m_btnProcCONLL2017.Name = "m_btnProcCONLL2017";
            this.m_btnProcCONLL2017.Size = new System.Drawing.Size(75, 41);
            this.m_btnProcCONLL2017.TabIndex = 16;
            this.m_btnProcCONLL2017.Text = "preProcCONLL2017";
            this.m_btnProcCONLL2017.UseVisualStyleBackColor = true;
            this.m_btnProcCONLL2017.Click += new System.EventHandler(this.m_btnProcCONLL2017_Click);
            // 
            // m_btn_proc_jaist
            // 
            this.m_btn_proc_jaist.Location = new System.Drawing.Point(25, 98);
            this.m_btn_proc_jaist.Name = "m_btn_proc_jaist";
            this.m_btn_proc_jaist.Size = new System.Drawing.Size(75, 36);
            this.m_btn_proc_jaist.TabIndex = 17;
            this.m_btn_proc_jaist.Text = "preProc_jaist";
            this.m_btn_proc_jaist.UseVisualStyleBackColor = true;
            this.m_btn_proc_jaist.Click += new System.EventHandler(this.m_btn_proc_jaist_Click);
            // 
            // m_btnGensin
            // 
            this.m_btnGensin.Location = new System.Drawing.Point(25, 143);
            this.m_btnGensin.Name = "m_btnGensin";
            this.m_btnGensin.Size = new System.Drawing.Size(75, 33);
            this.m_btnGensin.TabIndex = 18;
            this.m_btnGensin.Text = "getviText4Gensin";
            this.m_btnGensin.UseVisualStyleBackColor = true;
            this.m_btnGensin.Click += new System.EventHandler(this.m_btnGensin_Click);
            // 
            // m_btnMakeVocabulary
            // 
            this.m_btnMakeVocabulary.Location = new System.Drawing.Point(25, 179);
            this.m_btnMakeVocabulary.Name = "m_btnMakeVocabulary";
            this.m_btnMakeVocabulary.Size = new System.Drawing.Size(75, 37);
            this.m_btnMakeVocabulary.TabIndex = 19;
            this.m_btnMakeVocabulary.Text = "make vocabulary";
            this.m_btnMakeVocabulary.UseVisualStyleBackColor = true;
            this.m_btnMakeVocabulary.Click += new System.EventHandler(this.m_btnMakeVocabulary_Click);
            // 
            // m_btn_count_length
            // 
            this.m_btn_count_length.Location = new System.Drawing.Point(642, 68);
            this.m_btn_count_length.Name = "m_btn_count_length";
            this.m_btn_count_length.Size = new System.Drawing.Size(75, 44);
            this.m_btn_count_length.TabIndex = 20;
            this.m_btn_count_length.Text = "统计分词的长度";
            this.m_btn_count_length.UseVisualStyleBackColor = true;
            this.m_btn_count_length.Click += new System.EventHandler(this.m_btn_count_length_Click);
            // 
            // m_btn_statViword_3th
            // 
            this.m_btn_statViword_3th.Location = new System.Drawing.Point(748, 22);
            this.m_btn_statViword_3th.Name = "m_btn_statViword_3th";
            this.m_btn_statViword_3th.Size = new System.Drawing.Size(116, 40);
            this.m_btn_statViword_3th.TabIndex = 21;
            this.m_btn_statViword_3th.Text = "统计越南语单词（3th）";
            this.m_btn_statViword_3th.UseVisualStyleBackColor = true;
            this.m_btn_statViword_3th.Click += new System.EventHandler(this.m_btn_statViword_3th_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(891, 287);
            this.Controls.Add(this.m_btn_statViword_3th);
            this.Controls.Add(this.m_btn_count_length);
            this.Controls.Add(this.m_btnMakeVocabulary);
            this.Controls.Add(this.m_btnGensin);
            this.Controls.Add(this.m_btn_proc_jaist);
            this.Controls.Add(this.m_btnProcCONLL2017);
            this.Controls.Add(this.m_tbCurrProcContent);
            this.Controls.Add(this.m_lbCurrprocPos);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.m_btnSpWholeFile);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.m_btnProbWatch);
            this.Controls.Add(this.m_lbStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.m_btnTest);
            this.Controls.Add(this.m_btnLoadViFile);
            this.Name = "MainForm";
            this.Text = "ViWordAnalysis";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnLoadViFile;
        private System.Windows.Forms.Button m_btnTest;
        private System.Windows.Forms.Timer m_timer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label m_lbStatus;
        private System.Windows.Forms.Button m_btnGenCoArr;
        private System.Windows.Forms.Button m_btnWSeg;
        private System.Windows.Forms.Button m_btnProbWatch;
        private System.Windows.Forms.Button m_btnMk3Order;
        private System.Windows.Forms.Button m_btnSSplit3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button m_btnMk4Order;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button m_btnMk5Order;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button m_btnMk6Order;
        private System.Windows.Forms.Button m_btnSplit_6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button m_btnMk8Order;
        private System.Windows.Forms.Button m_btnMk7Order;
        private System.Windows.Forms.Button m_btnViTest;
        private System.Windows.Forms.Button m_btnSpWholeFile;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label m_lbCurrprocPos;
        private System.Windows.Forms.TextBox m_tbCurrProcContent;
        private System.Windows.Forms.Button m_btnViTest_jaist;
        private System.Windows.Forms.Button m_btnUniF1_8_2DB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button m_btnMk1Order;
        private System.Windows.Forms.Button m_btnProcCONLL2017;
        private System.Windows.Forms.Button m_btn_proc_jaist;
        private System.Windows.Forms.Button m_btnGensin;
        private System.Windows.Forms.Button m_btnMakeVocabulary;
        private System.Windows.Forms.Button m_btn_count_length;
        private System.Windows.Forms.Button m_btn_statViword_3th;
    }
}

