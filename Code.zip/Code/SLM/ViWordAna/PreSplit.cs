﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViWordAna
{

    /*
     * 类说明：条件概率校验类，用于校验P(B|A)是否大于P(B)
     *         该类用于存储两个 相邻 的可行 分词：（word1，word2）, m_Wd1存的是word1,
     *                          m_Wd2存的是word2.
     *                          
     * 校验时： A|B，C|D，A、B由word1产生，C、D由word2产生。
     * 
     */

    public class WordIndexPair4CondProb
    {
        public WordIndexPair4CondProb()
        {
        }

        /*
         * 函数功能：给词组 A 的范围赋值；
         * 参数说明：st, 在原始数组 words中的起始下标
         *           ed, 在原始数组 words中的终止下标 的 下一个位置
         *           
         * 返回值：无
         * 
         */
        public void Val2Wd1( int st,int ed )
        {
            m_Wd1 = new WordIndexPair(st,ed);
        }

        /*
         * 函数功能：给词组 B 的范围赋值；
         * 参数说明：st, 在原始数组 words中的起始下标
         *           ed, 在原始数组 words中的终止下标 的 下一个位置
         *           
         * 返回值：无
         * 
         */

        public void Val2Wd2( int st,int ed )
        {
            m_Wd2 = new WordIndexPair(st,ed);
        }

        /*
         * 函数功能： 获取词组 A
         * 参数说明：words，原始 字数组
         * 
         * 返回值：词组 A
         * 
         */

        public string[] GetWord_1( string[] words)
        {
            int Len = m_Wd1.m_ed - m_Wd1.m_st;

            if (Len <= 0)
            {
                return null;
            }

            string[] rtA = new string[Len];

            int i = 0;

            for (i = 0; i < Len; ++i)
            {
                rtA[i] = words[m_Wd1.m_st + i];
            }

            return rtA;

        }

        /*
         * 函数功能： 获取词组 B
         * 参数说明：words，原始 字数组
         * 
         * 返回值：词组 B
         * 
         */

        public string[] GetWord_2(string[] words)
        {
            int Len = m_Wd2.m_ed - m_Wd2.m_st;

            if (Len <= 0)
            {
                return null;
            }

            string[] rtA = new string[Len];

            int i = 0;

            for (i = 0; i < Len; ++i)
            {
                rtA[i] = words[m_Wd2.m_st + i];
            }

            return rtA;
        }

        /*
         * 函数功能：获取校验结合力使用的 A
         * 
         * 注意：只返回 前 n-1个 单词
         * 
         * **/

        public string[] Get_A_4H(string[] words)
        {
            int Len = m_Wd1.m_ed - m_Wd1.m_st;

            if (Len <= 1)
            {
                return null;
            }

            string[] A= new string[Len - 1];
            int i = 0;

            for (i = 0; i < Len - 1; ++i)
            {
                A[i] = words[m_Wd1.m_st+i];
            }

            return A;

        }

        /*
         * 函数功能：获取校验结合力使用的 B
         * 
         * 注意：只返回 最后一个单词
         * 
         * **/

        public string[] Get_B_4H(string[] words)
        {
            int Len = m_Wd1.m_ed - m_Wd1.m_st;

            if (Len <= 0)
            {
                return null;
            }

            string[] B= new string[1];

            B[0] = words[m_Wd1.m_ed-1];
        
            return B;

        }

        /*
         * 函数功能：获取校验结合力使用的 C
         * 
         * 注意：只返回 第1个 单词
         * 
         */

        public string[] Get_C_4H(string[] words)
        {
            int Len = m_Wd2.m_ed - m_Wd2.m_st;

            if (Len <= 0)
            {
                return null;
            }

            string[] C = new string[1];

            C[0] = words[m_Wd2.m_st];

            return C;
        }

        /*
         * 函数功能：获取校验结合力使用的 D
         * 
         * 注意：只返回 后面 n-1 个单词
         * 
         */
        public string[] Get_D_4H(string[] words)
        {
            int Len = m_Wd2.m_ed - m_Wd2.m_st;

            if (Len <= 1)
            {
                return null;
            }

            int i = 0;
            string[]D= new string[Len-1];

            for (i = 0; i < Len - 1; ++i)
            {
                D[i] = words[m_Wd2.m_st + 1 + i];
            }

            return D;
        }

        /*
         * 函数功能：获得 字1和字2的总长度
         * 
         * **/
        public int GetLenWd1andWd2()
        {
            return GetLenWd1() + GetLenWd2();
        }

        public int GetLenWd1()
        {
            return m_Wd1.m_ed - m_Wd1.m_st;
        }

        public int GetLenWd2()
        {
            return m_Wd2.m_ed - m_Wd2.m_st;
        }


        public WordIndexPair m_Wd1 = null;
        public WordIndexPair m_Wd2 = null;

    }



    /*
     * 类说明：在进行分词之前 ，利用 陌生单词 和 天然分隔符 把短句子提取出来 
     *         利用条件概率的关系进行粗略切分，降低搜索空间！
     */


    public class PreSplit
    {
        public PreSplit( CalcProbCond cpc)
        {
            //m_str = str;
            m_cpc = cpc;
        }

        /*
         * 函数功能：分词前的预处理。应用场景是这样的：把字符串（可以很长，如整个文本文件的内容当作一个 string） 传入该函数，该函数的第一次
         *           拆分操作是：天然分隔符（，。等等）和陌生单词。第二次拆分操作是：进行条件概率校验，满足条件则
         *           把长句拆分成短句，降低最终的搜索空间
         * 参数说明：str，一个很长很长的原始字符串 
         * 
         * 返回值：短串列表
         * 
         * **/

        public List<string> PreSplit4WordSeg( string str)
        {
            //List<string> Lfir = GetSentences(str); // 利用天然分隔符 和陌生单词 把长句拆分成短句，还有数字也被当成分隔符了 。

            List<string> Lfir = GetSentences_speratedBY_Space_and_Tab(str); // 利用天然分隔符 和陌生单词 把长句拆分成短句，还有数字也被当成分隔符了 。

            int i = 0;
            List<string> Lrt = new List<string>() ;

            for (i = 0; i < Lfir.Count; ++i)
            {
                List<string> Ltmp = FirstSplit(Lfir[i]);

                if (Ltmp.Count > 0)
                {
                    Lrt = Lrt.Concat(Ltmp).ToList<string>();
                }
                else
                {
                    Lrt.Add(Lfir[i]);
                }
            }

            Lrt = Split__Va___(Lrt);

            return Lrt;
        }

        /*
         * 函数功能：在连词 va 处分开
         * 参数说明：LLL string 列表
         * 
         * 返回值：拆分的 str
         * **/

        public List<string> Split__Va___(List<string> LLL)
        {
            List<string> lrt = new List<string>();
            int i = 0;

            for (i = 0; i < LLL.Count; ++i)
            {
                List<string> lll = Split__Va___(LLL[i]);

                lrt=lrt.Concat(lll).ToList<string>();
            }

            return lrt;

        }

        /*
         * 函数功能：在连词 va 处分开
         * 参数说明：str，字符串
         * 
         * 返回值：拆分的 str List
         * **/

        public List<string> Split__Va___( string str)
        {
            List<string> Lrt = new List<string>();

            if (str == null)
            {
                return Lrt;
            }

            int pos = str.IndexOf(" và ");
            string stmp = null;

            while (pos >= 0)
            {
                if (pos == 0)
                {
                    stmp = str.Substring(0, 4);
                    Lrt.Add(stmp);

                    str = str.Substring(4);
                    pos = str.IndexOf(" và ");
                }
                else if (pos > 0)
                {
                    stmp = str.Substring(0, pos);
                    Lrt.Add(stmp);

                    stmp = str.Substring(pos, 4);
                    Lrt.Add(stmp);

                    str = str.Substring(pos+4);
                    pos = str.IndexOf(" và ");
                }
            }

            if (!str.Trim().Equals(""))
            {
                Lrt.Add(str);
            }

            return Lrt;

        }

        /*
         * 函数功能：获取一个长字符串的所有子串，先用用空格和 \t 去拆分这个句子，再用陌生单词 去切分 获得 字串。
         *           注意：连着的几个陌生单词，统统拆成单个 单词，这样 单个陌生单词的 标签 都是 'B'.
         * 参数说明：str，字符串
         * 
         * 返回值：子串列表
         *
         */
        public List<string> GetSentences_speratedBY_Space_and_Tab(string str)
        {
            m_str = wordSeg.FiltPlaceHolder(str);

            Dictionary<string, int> wordDic = m_cpc.m_wordDic;

            List<string> Lst = new List<string>();

            wordSeg ws = new wordSeg();
            string[] words = ws.dowordSeg_Seperated_BY_Space_and_Tab(m_str); // 先过滤占位符，因为传入的是引用，m_str中的占位符已经被过滤。再获取所有的单词（小写）

            if (words == null || words.Length == 0)
            {
                //  MessageBox.Show("提取分句时，传进来的字符串为 null 或者 空！\n");
                return Lst;
            }

            if (words.Length == 1)
            {
                Lst.Add(words[0]);

                return Lst;
            }

            m_str = m_str.ToLower(); // 转换成和 words一样的小写，因为要做字符串查找操作

            int i = 0;
            string subSents = "";

            for (i = 0; i < words.Length; ++i)
            {
                if (wordDic.ContainsKey(words[i]))
                {
                    subSents += words[i] + " ";
                }
                else
                {
                    if (!subSents.Equals(""))
                    {
                        Lst.Add(subSents.Trim());
                        subSents = ""; // 清空，等着 装 下一个 字串。
                    }

                    Lst.Add(words[i]);
                }
            }  // for end!

            if (!subSents.Equals(""))
            {
                Lst.Add(subSents.Trim());// 注意是加上最后一个单词的长度
            }

            return Lst;
        }


        /*
         * 函数功能：获取一个长字符串的所有子串，这些子串在原始字符串中被陌生单词和天然分隔符分开
         * 参数说明：str，字符串
         * 
         * 返回值：子串列表
         *
         */
        public List<string> GetSentences(string str)
        {
            m_str = wordSeg.FiltPlaceHolder( str);

            Dictionary<string, int> wordDic = m_cpc.m_wordDic;

            List<string> Lst = new List<string>();

            wordSeg ws = new wordSeg();
            string[] words = ws.dowordSeg(m_str); // 先过滤占位符，因为传入的是引用，m_str中的占位符已经被过滤。再获取所有的单词（小写）

            if (words == null || words.Length == 0)
            {
              //  MessageBox.Show("提取分句时，传进来的字符串为 null 或者 空！\n");
                return Lst;
            }

            if (words.Length == 1)
            {
                Lst.Add(words[0]);

                return Lst;
            }

            m_str = m_str.ToLower(); // 转换成和 words一样的小写，因为要做字符串查找操作

            int FindPos_st = 0;      // 字符串查找的起始参考位置，因为可能有重复的单词，造成混乱。
            int i = 0;

            string w1 = null;
            string w2 = null;

            int st_pos = 0;
            int ed_pos = 0;

            int sentence_st = 0;

            for (i = 0; i < words.Length - 1 ; ++i)
            {
                w1 = words[i];
                w2 = words[i + 1];

                st_pos = m_str.IndexOf(w1,FindPos_st );
                ed_pos = m_str.IndexOf(w2,st_pos + w1.Length); // 要加上参考起始位置，因为w1可能和w2一样

                if (st_pos == -1 || ed_pos == -1)
                {
                    Lst.Clear(); // 清空，否则会出现奇怪的错误
                    return Lst;// 出现了奇怪现象，比如“ khmer: កម្ពុជា, "kampuchea", ipa: [kɑmpuˈciə]”，不搞了，直接返回
                }

                if (!wordDic.ContainsKey(w1) && !wordDic.ContainsKey(w2))
                {
                    //Lst.Add(m_str.Substring(sentence_st, FindPos_st + w1.Length)); // 获得一个句子
                    // 什么也不做

                    if (isViWordConjunction(m_str, FindPos_st, w1, w2))
                    {
                        // 是词内连接符，什么也不做，因为下一个单词有可能还是陌生单词
                    }
                    else
                    {
                        // 不是词内连接符，要断开了
                        Lst.Add(m_str.Substring(sentence_st, st_pos + w1.Length - sentence_st)); // 获得一个句子
                        sentence_st = st_pos + w1.Length;
                    }

                }
                else if (!wordDic.ContainsKey(w1) && wordDic.ContainsKey(w2))
                {
                    //Lst.Add(m_str.Substring(sentence_st, st_pos + w1.Length - sentence_st)); // 获得一个句子
                    //sentence_st = st_pos + w1.Length;

                    //w1 是陌生单词， w2不是陌生单词，可以获得1个句子

                    Lst.Add(m_str.Substring(sentence_st, st_pos + w1.Length - sentence_st) );

                    sentence_st = st_pos + w1.Length;

                }
                else if (wordDic.ContainsKey(w1) && !wordDic.ContainsKey(w2))
                {
                    Lst.Add(m_str.Substring(sentence_st, st_pos + w1.Length - sentence_st)); // 获得一个句子，w2的下一个单词还有可能是陌生单词
                    sentence_st = st_pos + w1.Length;
                }
                else // wordDic.ContainsKey(w1) && wordDic.ContainsKey(w2)
                {     
                    if (!WCE_FromFile_DB.isViWordConjunction(st_pos + w1.Length, ed_pos, m_str))
                    {
                        Lst.Add(m_str.Substring(sentence_st, st_pos + w1.Length - sentence_st)); // 获得一个句子
                        sentence_st = ed_pos;
                    }
                }

               FindPos_st = st_pos + w1.Length;

            }  // for end!

            Lst.Add(m_str.Substring(sentence_st, ed_pos + w2.Length - sentence_st));// 注意是加上最后一个单词的长度

            return Lst;
        }

        /*
         * 函数功能：利用条件概率的关系进行粗略切分，以降低搜索空间。
         * 参数说明：str ，被粗略切分的字符串
         * 
         * 返回值：切分的返回结果，可能包含多个 子串
         * 
         * 注意：该函数只能在 "预切分" 之后调用，否则 会有风险
         */

        private List<string> FirstSplit( string str)
        {
            List<string> Lrt = new List<string>();
            wordSeg ws = new wordSeg();
            string[] words = ws.dowordSeg(str); // 先过滤占位符，因为传入的是引用，str中的占位符已经被过滤。再获取所有的单词（小写）

            if (words.Length < 12)
            {
                Lrt.Add(str); // 数量太少了，得不偿失，直接返回
                return Lrt;
            }
            

            if (words != null && words.Length > 0)
            {
                if (!m_cpc.m_wordDic.ContainsKey(words[0])) // 如果第一个单词是陌生单词，按照预切分的结果，整个字符串都将是陌生的。
                {
                    Lrt.Add(str);
                    return Lrt; // 返回空列表 可能会出错
                }
            }
            else if (words == null || words.Length <= 1)
            {
                Lrt.Add(str);
                return Lrt;  // 原封不动 返回
            }

            str = str.ToLower(); // 把这个字符串 变成小写 

            int[] WordPosArr = getWordPosArr(str,words); // 获得每个单词在 字符串中的起始位置 数组
            int SplitST = 0;
            int refPos = 0;

            for (refPos = 1; refPos <= words.Length - 1; ++refPos) // refPos最大只能到最后一个单词和倒数第二个单词之间的位置，resPos = words.Length - 1.
            {
                List<WordIndexPair4CondProb>  Lallwip =  Get_ALL_WIP4CondProb(words, refPos);
                bool canbeSplit = CanBEsplit(Lallwip,words);
                bool canbeSplit_H = false;// 这个条件不起作用！！！ CanBEsplit_H_check(Lallwip, words); 

                if (canbeSplit == true || canbeSplit_H==true) // 表示可以拆分
                {
                    Lrt.Add(str.Substring(SplitST, WordPosArr[refPos - 1] + words[refPos - 1].Length - SplitST )); // 获得一个子串
                    SplitST = WordPosArr[refPos ]; // 子串新的起始位置
                }

            }

            Lrt.Add(str.Substring(SplitST)); // 把最后的子串添加进来

                
            return Lrt;
        }


        /*
         * 函数功能：获取单词子串在原始字符串中的 起始位置
         * 参数说明：str,原始字符串
         *           words，单词数组
         *           
         * 返回值：一个数组，数组的每个元素对应该单词 在 原始字符串中的起始位置
         * 
         **/

        private int[] getWordPosArr( string str, string[] words)
        {
            int Len = words.Length;

            if (Len == 0)
            {
                return null;
            }

            int[] rtA = new int[Len];
            int FindPos = 0;
            int i = 0;

            for (i = 0; i < Len; ++i)
            {
                rtA[i] = str.IndexOf(words[i], FindPos);
                FindPos = rtA[i] + words[i].Length;
            }

            return rtA;
        }


        /*
         * 函数功能：Lallwip表示的在 refPos处 是否可以切分
         * 参数说明：Lallwip，在refPos处所有的“A|B”的组合
         * 
         * 返回值：如果所有的条件概率都不成立，返回true，可以拆分
         *         只要有一个条件概率成立，返回false， 不可以拆分
         * 
         **/


        private bool CanBEsplit(List<WordIndexPair4CondProb> Lallwip, string[] words)
        {
            int i = 0;

            for (i = 0; i < Lallwip.Count; ++i)
            {
                if (m_cpc.CondPorb_is_Valid(Lallwip[i], words))
                {
                    return false;
                }
            }

            return true;
        }

        private bool CanBEsplit_H_check(List<WordIndexPair4CondProb> Lallwip, string[] words)
        {
            if (words.Length <= 2) // 缺了了这个条件后果很严重，导致一个结合很紧密的词也会被分开！！
            {
                return false;
            }

            if (GetMinMaxLenofLR(Lallwip) < 4) // 太短就不检查了 ！！！
            {
                return false;
            }


            int i = 0;

            for (i = 0; i < Lallwip.Count; ++i)
            {
                if (m_cpc.H_is_Valid(Lallwip[i], words)) //m_cpc.H_is_Valid(Lallwip[i], words)==true,表明该位置结合得好，不能拆分
                { 
                    return false; // 不能拆分，就返回false
                }
            }

            return true;
        }

        private int GetMinMaxLenofLR(List<WordIndexPair4CondProb> Lallwip)
        {
            int i = 0;
            int maxL = -100;
            int maxR = -100;


            for (i = 0; i < Lallwip.Count; ++i)
            {
                if (Lallwip[i].GetLenWd1() > maxL)
                {
                    maxL = Lallwip[i].GetLenWd1();
                }

                if (Lallwip[i].GetLenWd2() > maxR)
                {
                    maxR = Lallwip[i].GetLenWd2();
                }
            }

            return Math.Min(maxL,maxR); // 

        }


        /*
         * 函数功能：判断两个单词word1和word2之间是不是 词内 连接符
         * 参数说明：str,原始字符串
         *           refPos，查找word1的参考起始位置
         *           word1，前面一个单词
         *           word2，后面一个单词
         * 
         * 返回值：true，是词内连接符
         *         false,不是词内连接符
         */

        private bool isViWordConjunction(string str,int refPos, string word1,string word2)
        {
            int indx_w1 = str.IndexOf(word1, refPos);                // word1的起始位置
            int indx_w2 = str.IndexOf(word2, indx_w1+word1.Length);  // word2的起始位置

            if (WCE_FromFile_DB.isViWordConjunction(indx_w1 + word1.Length, indx_w2, str))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 函数功能：以refPos为参考位置（也就是词A和B的边界位置），获取每种组合长度下词A和词B的各种组合，组合长度从2，3...m_MaxLab
         * 参数说明：words,单词数组
         *           refPos，参考位置（词A和B的边界位置）,例如:W0 W1 | W2 W3 W4 ... Wn-1
         *                                                         refPos=2
         *                                                         
         * 返回值：所有的“A|B”的序列。也就是有很多“A|B”
         * **/

        public List<WordIndexPair4CondProb> Get_ALL_WIP4CondProb(string[] words, int refPos)
        {
            List<WordIndexPair4CondProb> Lrt = new List<WordIndexPair4CondProb>();

            int Lab = 0;

            for (Lab = 2; Lab <= m_MaxLab; ++Lab)
            {
                List<WordIndexPair4CondProb> tl = GetWIP4CondProb(words, refPos, Lab);

                Lrt = Lrt.Concat(tl).ToList<WordIndexPair4CondProb>(); 

            }

            return Lrt;
        }


        /*
         * 函数功能：以refPos为参考位置（也就是词A和B的边界位置），获取词A和词B的总长度为Lab的所有可能的情况
         * 参数说明：words,单词数组
         *           refPos，参考位置（词A和B的边界位置）,例如:W0 W1 | W2 W3 W4 ... Wn-1
         *                                                        refPos=2
         *           Lab，词A、词B的长度之和
         * 
         * 返回值：所有的“A|B”的序列。也就是有很多“A|B”
         * 
         */

        public List<WordIndexPair4CondProb> GetWIP4CondProb(string[]words,int refPos,int Lab)
        {
            List<WordIndexPair4CondProb> Lrt = new List<WordIndexPair4CondProb>();

            int iST = Math.Max(0, refPos - Lab + 1 ); // for 循环的 起始位置
            int iED = refPos - 1;

            if (refPos <= 0 || refPos >= words.Length)
            {
                return Lrt;
            }

            int i = 0;

            for (i = iST; i <= iED; ++i) // 参考位置左边 A 的所有可能位置
            {
                if (i + Lab <= words.Length) // 参考位置右边 合法
                {
                    WordIndexPair4CondProb wip4cp = new WordIndexPair4CondProb();
                    wip4cp.Val2Wd1(i,refPos);          // 参考位置左边 A的范围
                    wip4cp.Val2Wd2(refPos, i + Lab);   // 参考位置右边 B的范围，i + Lab最大等于words.Length

                    Lrt.Add(wip4cp);
                }
            }
            
            return Lrt;
        }



        // Attributes 

        private string m_str = null;
        private CalcProbCond m_cpc = null;
        private int m_MaxLab = 8;  // 条件概率校验 A|B中 A和B长度之和的最大值
    }
}
