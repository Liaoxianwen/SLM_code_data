﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViWordAna
{
    public class FeasibleResult :IComparable<FeasibleResult>
    {
        public FeasibleResult()
        {

        }

        public int CompareTo(FeasibleResult other)
        {
            if (this.m_Prob > other.m_Prob)
            {
                return -1;
            }

            return 1;
        }

        public double m_Prob;
        public UInt32[] m_BL;
    }
}
