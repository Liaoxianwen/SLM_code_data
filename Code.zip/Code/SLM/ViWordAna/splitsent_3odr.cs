﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ViWordAna
{
    public class splitsent_3odr
    {
        public splitsent_3odr(WCE_FromFile_DB wco,string str)
        {
            m_str = str;
            m_wco3 = new WCE_FromDB_3odr();
            m_wco2 = wco;
        }

        /*
          * 函数功能：对字符串进行分词
          * 参数说明：无
          * 返回值：分词结果，数组的最0位对应第0个字。
          * 1表示一个词的开始，紧接着的0表示和前面的字构成一个词
          *
          */
        public UInt32[] doSplit(string oriStr)
        {
            UInt32[] bL = null;

            wordSeg ws = new wordSeg();
            string[] words = ws.dowordSeg(m_str);

            UInt32 srchP = CommFuns.GenSearchSpace(words);

            if (words.Length > 32)
                return null;

            UInt32 i = 0;
            double dPro = 0D;

            double dPmax = -0x7FFFFFFFD;

            UInt32[] aMaxBL = null;

            UInt32 cnt = 0;

            for (i = 0; i < srchP; ++i)
            {
                i= 0x01;

                if (i % 2 == 0)
                {
                    continue;//最低位是0，跳过。因为第一个字要么它本身是一个词，要么是更长词的开头
                }

                bL = CommFuns.GenBinaryList(i, words.Length); // 二进制序列
                dPro = calcProbability(words, bL);

                if (dPro > dPmax)
                {
                    aMaxBL = bL;
                    dPmax = dPro;
                }

                cnt++;
            }

            // ======== 结果写入文件

            words = wordSeg.dowordSeg_Original(oriStr);

            StreamWriter sw = new StreamWriter("SplitResult_3odr.txt", false);
            string str2File = "";

            for (i = 0; i < words.Length - 1; ++i)
            {
                str2File += words[i].ToString() + "  ";

                if (aMaxBL[i + 1] == 1)
                {
                    sw.WriteLine(str2File);
                    str2File = "";
                }
            }

            str2File += words[i].ToString();
            sw.WriteLine(str2File);

            sw.Close();
            sw.Dispose();

            MessageBox.Show("一共搜索了：" + cnt.ToString() + "次!");

            return aMaxBL;
     
        }

        /*
         * 函数功能：计算整个句子的一个可行分词序列的 对数概率。
         * 参数说明：sWords，句子 字 序列
         *           bL，一个分词可行解
         *           
         * 返回值：概率的对数值。
         */
        private double calcProbability(string[] sWords, UInt32[] bL)
        {
            int i = 0;
            double pSum = 0D;
            int nextBeg = -1;

            if (bL[0] != 1)
            {
                return -100000D;// 一个充分小的数
            }

            i = 0;        // 刚刚开始第一个词的开始位置是 0
            nextBeg = 0;
            while (i < sWords.Length)
            {
                nextBeg = CommFuns.NextWordBeg(bL, i); // 下一个词的开始位置
                double pTmp = calcProbability_condition(sWords, i, nextBeg);
                pSum += pTmp;

                i = nextBeg; // 移动到下一个词的开始

                if (i == sWords.Length) // 已经没有词了，退出
                {
                    break;
                }

            }

            return pSum;
        }

        /*
         * 函数功能：计算字数组sWords中从stPos到edPos（不包括edPos）的字组成的词的概率 的对数值
         * 参数说明：sWords字数组，原始字符串包含的 字 序列
         *          stPos，起始位置；
         *          edPos，终止位置（不包含）
         * 返回值： 从stPos到edPos（不包括edPos）的字组成的词的 对数概率
         */

        private double calcProbability_condition(string[] sWords, int stPos, int edPos)
        {
            //double rd = 0D;
            int i = 0;

            if (stPos >= edPos)
            {
                return -100000D; // 充分小的数
            }

            if (edPos - stPos == 1)
            {
                //return Math.Log10((double)m_wco3.GetProWord(sWords[stPos])); // 返回单个字的概率

                double dtt = Math.Log10((double)m_wco3.GetProWord(sWords[stPos]));
                return Math.Log10((double)m_wco2.GetProWord_4Condition(sWords[stPos]));
            }
            else if (edPos - stPos == 2)
            {
                double prott = Math.Log10((double)m_wco3.GetProWord(sWords[stPos]));
                prott += Math.Log10((double)m_wco3.GetProWord(sWords[stPos], sWords[stPos + 1]));

                double pro = Math.Log10((double)m_wco2.GetProWord_4Condition(sWords[stPos]));
                pro += Math.Log10((double)m_wco2.GetWord2Pro_condition(sWords[stPos], sWords[stPos + 1]));

                return pro; 
            }

            //double numera = Math.Log10((double)m_wco3.GetProWord(sWords[stPos], sWords[stPos+1]));

            //double numera = Math.Log10((double)m_wco3.GetProWord(sWords[stPos]));
            //numera += Math.Log10((double)m_wco3.GetProWord(sWords[stPos], sWords[stPos + 1]));

            double numera = Math.Log10((double)m_wco2.GetProWord_4Condition(sWords[stPos]));
            numera += Math.Log10((double)m_wco2.GetWord2Pro_condition(sWords[stPos], sWords[stPos + 1]));

            // 对数使得 乘法 变 加法
            for (i = 0; i < edPos - stPos - 2; ++i)
            {
                numera += Math.Log10((double)m_wco3.GetProWord(sWords[stPos + i], sWords[stPos + i + 1], sWords[stPos + i + 2])); 
            }

            return numera;
        }


        private WCE_FromDB_3odr m_wco3;
        private WCE_FromFile_DB m_wco2;

        private string m_str;
    }
}
