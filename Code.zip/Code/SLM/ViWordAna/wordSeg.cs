﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ViWordAna
{
    public class wordSeg
    {
        public wordSeg() { }

        /*
         * 函数功能：把字符串sL 分解成单个字（词），并把单个词中的 "."号去掉，例如 washington D.C. 中的"."去掉（后来也已经把点号做分隔符了）
         *           并把分解后的单字 全部变成小写
         * 参数说明：sL，被分解的字符串
         * 返回值：无
         */
        public string[] dowordSeg(string sL)
        {
            // 过滤掉 哪些不可见的 占位 字符 
           sL= FiltPlaceHolder(sL);

           sL = sL.ToLower();

            // 字符串拆分
            m_WordArr = sL.Split(m_sp, StringSplitOptions.RemoveEmptyEntries);

            return m_WordArr;
        }

        /*
         * 函数功能：把字符串sL 分解成单个字（词），不过滤任何东西，只是用 空格 和 \t 把句子拆分成单词 序列，
         *           要是 过滤 标点、数字，再恢复起来，难啊。
         *           并把分解后的单字 全部变成小写
         * 参数说明：sL，被分解的字符串
         * 返回值：空格隔开 的 单词 数组
         */
        public string[] dowordSeg_Seperated_BY_Space_and_Tab(string sL)
        {
            // 过滤掉 哪些不可见的 占位 字符 
            sL = FiltPlaceHolder(sL);

            sL = sL.ToLower();

            string[] seperators = { " ","\t"};// 只需要 空格 和 \t 就可以了。

            // 字符串拆分
            m_WordArr = sL.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

            return m_WordArr;
        }

        // 保留 数字的 拆分
        /*
         * 函数功能：函数功能同 “string[] dowordSeg(string sL)”，但是保留数字，分词结果被转换成小写
         * 参数说明：sL，被分词的字符串
         * 
         * 返回值：单字 的 数组
         */
        public string[] dowordSeg_ResDigital(string sL)
        {
            // 过滤掉 哪些不可见的 占位 字符 
           sL= FiltPlaceHolder(sL);

            // 字符串拆分
            m_WordArr = sL.Split(m_sp_Digital, StringSplitOptions.RemoveEmptyEntries);

            int i = 0;

            if (m_WordArr == null)
            {
                return null;
            }

            // 都转换成小写
            for (i = 0; i < m_WordArr.Length; ++i)
            {
                m_WordArr[i] = m_WordArr[i].ToLower(); // 全部转换成小写
            }

            return m_WordArr;
        }

        /*
         * 函数功能： 用分隔符 把 句子分割成单词， 保留 大小写
         * **/
        public string[] dowordSeg_ResDigital_Cased(string sL)
        {
            // 过滤掉 哪些不可见的 占位 字符 
            sL = FiltPlaceHolder(sL);

            // 字符串拆分
            m_WordArr = sL.Split(m_sp_Digital, StringSplitOptions.RemoveEmptyEntries);

            int i = 0;

            if (m_WordArr == null)
            {
                return null;
            }

            // 都转换成小写
            for (i = 0; i < m_WordArr.Length; ++i)
            {
                m_WordArr[i] = m_WordArr[i].Trim(); // 全部转换成小写
            }

            return m_WordArr;
        }



        /*
         * 函数功能：对原始句子进行 单字 切分（数字也被过滤掉） ， 不转换成小写
         * 参数说明：sL，原始句子
         * 返回值：字数组
         * 
         */

        public static string[] dowordSeg_Original( string sL)
        {
            sL = FiltPlaceHolder(sL);
            string []WArr = sL.Split(m_sp, StringSplitOptions.RemoveEmptyEntries);

            return WArr;
        }

 
        public string[] GetWordArray()
        {
            return m_WordArr;
        }

        /*
         * 函数功能：过滤掉不可见的占位符。占位符是 不可见的 占字符串长度的 字符
         * 参数说明：str，被过滤的字符串
         * 
         * 返回值：已经被过滤的字符串
         * **/
        public static string FiltPlaceHolder(string str)
        {
            int i = 0;

            for (i = 0; i < m_sFilter.Length; ++i)
            {
                str = str.Replace(m_sFilter[i], "");
            }

            return str;
        }

        //字符的分隔
        static private string[] m_sp = { " ", ",", "(", ")", ":","ː", "\"", "•", "[", "]", @"\", @"/","·","（","）","『","「",
                                       "‘","’","!","'","-",";","?","0","1","2","3","4","5","6","7","　","ʻ","ˈ"," ","』","","」",
                                       "8","9","“","”","$","~","—","_","+","=","*","#","@","&","|","，","：","、"," ","%",
                                       "…"," ","","<",">","{","}","»","«",".","–","`","ʿ","¸","《","》",
                                       
                                       ((char)0x0300).ToString(),
                                       ((char)0x0301).ToString(),
                                       ((char)0x0303).ToString(),
                                       ((char)0x0323).ToString(),

                                       ((char)0xFEFF).ToString(),
                                       
                                       ((char)0x200B).ToString(),
                                       ((char)0x200C).ToString(),
                                       ((char)0x200E).ToString(),

                                       ((char)0x007F).ToString(),
                                       ((char)0x0091).ToString(),
                                       ((char)0x0096).ToString(),
                                       ((char)0x0097).ToString(),

                                       ((char)0x00AD).ToString(),
                                       "。","′","°","","−","±","´","„","″","÷","¬","≠","◆","†","","；","▪","‚","�","￼"}; // 加了点号
                                      //一个特殊字符，不指定是什么
                                      //0x200B 是零宽度字符−

        //字符的分隔，已经把数字去掉，即在分词结果中保留数字，点号“.”还保留有，“31.415”会被拆分成“31” 和 “415”，后面还要把他们拼接起来
        // 挺麻烦
        static private string[] m_sp_Digital = { " ", ",", "(", ")", ":","ː", "\"", "•", "[", "]", @"\", @"/","·","（","）","『","「",
                                       "‘","’","!","'","-",";","?","　","ʻ","ˈ"," ","』","","」",
                                       "“","”","$","~","—","_","+","=","*","#","@","&","|","，","：","、"," ","%",
                                       "…"," ","","<",">","{","}","»","«",".","–","`","ʿ","¸","《","》",
                                       
                                       ((char)0x0300).ToString(),
                                       ((char)0x0301).ToString(),
                                       ((char)0x0303).ToString(),
                                       ((char)0x0323).ToString(),

                                       ((char)0xFEFF).ToString(),
                                       
                                       ((char)0x200B).ToString(),
                                       ((char)0x200C).ToString(),
                                       ((char)0x200E).ToString(),

                                       ((char)0x007F).ToString(),
                                       ((char)0x0091).ToString(),
                                       ((char)0x0096).ToString(),
                                       ((char)0x0097).ToString(),

                                       ((char)0x00AD).ToString(),
                                       "。","′","°","","−","±","´","„","″","÷","¬","≠","◆","†","","；","▪","‚","�","￼"}; // 加了点号



        // 这些都是不可见的 占位字符
        static private string[] m_sFilter = {                                        
                    ((char)0x0300).ToString(),((char)0x0301).ToString(),((char)0x0303).ToString(),
                    ((char)0x0323).ToString(),((char)0xFEFF).ToString(),((char)0x200B).ToString(),
                    ((char)0x200C).ToString(),((char)0x200E).ToString(),((char)0x007F).ToString(),
                    ((char)0x0091).ToString(),((char)0x0096).ToString(),((char)0x0097).ToString(),
                    ((char)0x00AD).ToString()};

        private string[] m_WordArr = null;
    }
}

