﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ViWordAna
{
    public class OtherPreFunctions
    {
        public OtherPreFunctions()
        {
        }

        static public void GetViWordSeg()
        {
            string sfilename = @"viwords_filted.txt";

            StreamWriter sw = new StreamWriter("ViWord.txt", false);
            StreamReader sr = new StreamReader(sfilename);
            int cnt = 0;
            string[] sp = { ",", ":" };

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] rs = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);
                sw.WriteLine(rs[0]);
                cnt++;

                if (cnt == 10000)
                {
                    break;
                }

            }

            sw.Close();
            sw.Dispose();

            sr.Close();
            sr.Dispose();
        }

    }
}
