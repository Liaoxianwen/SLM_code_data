﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViWordAna
{
    public class emergeTimes
    {
        public emergeTimes()
        {
            m_Cnt = 0;
            m_Indx = 0;
        }


        public UInt32 m_Cnt;  // 出现的次数
        public UInt32 m_Indx; // 在单词数组中的 坐标
    }
}
