﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ViWordAna
{
    class WCE_FromDB_3odr
    {
        public WCE_FromDB_3odr()
        {
            m_db = new DBConn();

            m_DicProHasCalc = new Dictionary<string, Decimal>();

            m_WordDic3 = new Dictionary<string, int>();

            //m_WordNums = new UInt32[10000];
            //m_WordNumsCondition = new UInt32[10000];
            StreamReader sr = new StreamReader("ViWord最新.txt");
            string[] sp = { ":", "," };
            //int i = 0;

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] sA = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);

                //m_WordNums[i] = Convert.ToUInt32(sA[2]);
                //i++;

                string sWord = sA[0].Trim();

                m_WordDic3[sWord] = -1;  // 先放进去再说
                m_WordDic3[sWord] = m_WordDic3.Count - 1; // 数组的下标，方便再关联矩阵中进行索引

            }

            sr.Close();
            sr.Dispose();
        }


        /*
         * 函数功能：计算一个字 word 的概率
         * 参数说明：word，一个字
         * 返回值：该字 概率
         **/
        public Decimal GetProWord( string word)
        {
            Decimal DPro = 0M;

            // 如果字典中没有这个字，返回一个很小的概率的对数 
            if( !m_WordDic3.ContainsKey(word))
            {
                return m_dVerySmall/m_TotalWord1; // 一个很小的数 除以 单词总数。
            }

            int indx = m_WordDic3[word];
            if (m_DicProHasCalc.ContainsKey(indx.ToString())) // 如果之前已经算过了，则直接返回，没有必要再查数据库。
            {
                return m_DicProHasCalc[indx.ToString()];
            }

            // 不存在则再查数据库

            int[] i = { m_WordDic3[word] };             //构造索引向量

            int NumofWord = m_db.GetWordNumFromDB(i,-1);  //查询数据库获得该词的 出现次数

            // 如果查到一个 大于零 的 数，则用之来计算
            if (NumofWord > 0)
            {
                DPro = ((Decimal)NumofWord) / m_TotalWord1;
            }
            else
            {
                // 否则 用一个很小的值来计算
                DPro = m_dVerySmall / m_TotalWord1;
            }

            // 保存 映射表中，以备下次直接使用
            m_DicProHasCalc[indx.ToString()] = DPro;

            return DPro;
        }

        /*
         * 函数功能：计算二阶词（ word1，word2) 的条件概率：P(word2|word1)
         * 参数说明：（ word1，word2)是一个二阶词
         * 返回值：该二阶词 条件 概率
         **/
        public Decimal GetProWord(string word1, string word2)
        {
            Decimal DPro = 0M;

            // 如果字典中没有这个字，返回一个很小的概率的对数 
            if (!m_WordDic3.ContainsKey(word1) || !m_WordDic3.ContainsKey(word2))
            {
                return m_dVerySmall / m_TotalWord1;
            }

            int indx1 = m_WordDic3[word1];  // 字1的索引
            int indx2 = m_WordDic3[word2];  // 字2的索引

            string skd = indx1.ToString() + "_" + indx2.ToString(); // 概率映射表的key字符串

            // 如果已经存在，则直接返回 
            if (m_DicProHasCalc.ContainsKey(skd))
            {
                return m_DicProHasCalc[skd];
            }


            int[] i1 = { indx1 };        // 索引向量1
            int[] i2 = { indx1, indx2 }; // 索引向量2

            int NumofWord1  = m_db.GetWordNumFromDB(i1,-1); //第1个词出现的概率
            int NumofWord12 = m_db.GetWordNumFromDB(i2,-1); //第（1，2）个词出现的概率

            // 如果有其中一个是0， 则返回一个很小很小的概率值
            if (NumofWord1 == 0 || NumofWord12 == 0)
            {
                DPro = m_dVerySmall / m_TotalWord2;
            }
            else
            {
                // 否则用查询到的 数 计算条件 概率
                DPro = ((Decimal)NumofWord12) / NumofWord1;
            }

            // 把概率值存到映射表，以备下次使用
            m_DicProHasCalc[skd] = DPro;

            return DPro;
        }

        /*
         * 函数功能：计算三阶词(word1,word2,word3)的条件概率 P(word3|word1word2)
         * 参数说明：(word1,word2,word3)是一个三阶词
         * 返回值：该三阶词的 条件概率 P(word3|word1word2)
         **/
        public Decimal GetProWord(string word1, string word2,string word3)
        {
            Decimal DPro = 0M;

            // 如果字典中没有这个字，返回一个很小的概率的对数 
            if (!m_WordDic3.ContainsKey(word1) || !m_WordDic3.ContainsKey(word2) || !m_WordDic3.ContainsKey(word3))
            {
                return m_dVerySmall / m_TotalWord1;
            }

            int indx1 = m_WordDic3[word1];  // 索引1
            int indx2 = m_WordDic3[word2];  // 索引2
            int indx3 = m_WordDic3[word3];  // 索引3

            // 构造 概率映射表 key 字符串
            string skd = indx1.ToString() + "_" + indx2.ToString()+"_"+indx3.ToString();

            // 如果 存在 则直接返回
            if (m_DicProHasCalc.ContainsKey(skd))
            {
                return m_DicProHasCalc[skd];
            }

            int[] i2 = { m_WordDic3[word1], m_WordDic3[word2] };                  // 索引向量1
            int[] i3 = { m_WordDic3[word1], m_WordDic3[word2], m_WordDic3[word3] };// 索引向量2

            int NumofWord2 = m_db.GetWordNumFromDB(i2,-1);
            int NumofWord3 = m_db.GetWordNumFromDB(i3,-1);

            // 如果有其中一个是零，返回一个很小很小的概率
            if (NumofWord2 == 0 || NumofWord3 == 0)
            {
                DPro = m_dVerySmall / m_TotalWord1;
            }
            else
            {
                // 否则用查询到的 数 计算 条件概率
                DPro = ((Decimal)NumofWord3) / NumofWord2;
            }

            // 保存起来，以备 下次使用
            m_DicProHasCalc[skd] = DPro;

            return DPro;
        }


        private DBConn m_db;
        private Dictionary<string, int> m_WordDic3;

        private int m_TotalWord1 = 81363000;
        private int m_TotalWord2 = 81363000;
        //private int m_TotalWord3 = 81363000;
        private Decimal m_dVerySmall = 0.00000000000001M;

        private Dictionary<string, Decimal> m_DicProHasCalc;

        //private int m_ACTLW = 25857439;

    }
}
