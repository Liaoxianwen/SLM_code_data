﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ViWordAna
{
    public class splitsentence
    {
        /*
         * 函数功能：构造函数，
         * 参数说明：wco，字二阶关联矩阵
         *          str, 字序列字符串
         * 
         */
        public splitsentence(WCE_FromFile_DB wco, string str)
        {
            m_wco = wco;
            m_str = str; 
        }



        public void Test(WCE_FromFile_DB wco, string str)
        {
            wordSeg ws = new wordSeg();
            string[] words = ws.dowordSeg(m_str);

            double p0 = calcProbability_condition(words, 0, 1);
            double p1 = calcProbability_condition(words, 1, 2);

            double ppp = p0 + p1;

            UInt32 [] BL= {1,0};

            double pt = calcProbability_condition(words, 0, 2);

        }

        /*
         * 函数功能：对字符串进行分词
         * 参数说明：无
         * 返回值：分词结果，数组的最0位对应第0个字。
         * 1表示一个词的开始，紧接着的0表示和前面的字构成一个词
         *
         */
        public UInt32[] doSplit(string str)
        {
            UInt32[] bL = null;

            wordSeg ws = new wordSeg();
            string []words = ws.dowordSeg(m_str);

            UInt32 srchP = CommFuns.GenSearchSpace(words); // 生成枚举法 搜索的 空间 

            // 限制 句子的长度 最多 32 个单词
            if (words.Length > 32)
                return null;

            UInt32 i = 0;

            double dPro = 0D;

            double dPmax = -0x7FFFFFFFD;

           // double dPmin = 0x7FFFFFFFD;

            UInt32[] aMaxBL = null;

            for (i = 0; i < srchP; ++i)
            {
                if (i % 2 == 0)
                {
                    continue;//最低位是0，跳过。因为第一个字要么它本身是一个词，要么是更长词的开头
                }

                bL = CommFuns.GenBinaryList(i, words.Length); // 二进制序列
/*
                bL = new UInt32[22]{
                    1, 
                    1 , 0 , 
                    1, 1, 
                    1, 
                    1, 
                    1,0,
                    1,
                    1,0,
                    1,1,1,1,
                    1,0,
                    1,1,1,1};*/

                if (!CommFuns.isVaildBitSeq_2odr(bL))
                {
                    continue;
                }

                dPro = calcProbability(words, bL); // 计算该二进制序列所代表的 分词 的 序列 

                if (dPro > dPmax)
                {
                    aMaxBL = bL;
                    dPmax = dPro;
                }
            }

            // ======== 结果写入文件

            words = wordSeg.dowordSeg_Original(str);

            StreamWriter sw = new StreamWriter("SplitResult.txt", false);
            string str2File = "";

            for (i = 0; i < words.Length-1; ++i)
            {
                str2File += words[i].ToString()+"  ";

                if ( aMaxBL[i+1] == 1)
                {
                    sw.WriteLine(str2File);
                    str2File = "";
                }
            }

            str2File += words[i].ToString();
            sw.WriteLine(str2File);

            

            sw.Close();
            sw.Dispose();

            return aMaxBL;
        }

        /*
         * 函数功能：计算整个句子的一个可行分词序列的 对数概率。
         * 参数说明：sWords，句子 字 序列
         *           bL，一个分词可行解
         *           
         * 返回值：概率的对数值。
         */
        private double calcProbability(string[] sWords, UInt32[] bL)
        {
            int i = 0;
            double pSum = 0D;
            int nextBeg = -1;

            if (bL[0] != 1)
            {
                return -100000D;// 一个充分小的数
            }

            i = 0;        // 刚刚开始第一个词的开始位置是 0
            nextBeg = 0;
            while (i < sWords.Length)
            {
                nextBeg = CommFuns.NextWordBeg(bL, i);             // 下一个词的开始位置
                double pTmp = calcProbability(sWords, i, nextBeg); // 计算一个词[ i, nextBeg) 的 概率
                //double pTmp = MutlInfo(sWords, i, nextBeg);
                pSum+=pTmp;

                i = nextBeg; // 移动到下一个词的开始

                if (i == sWords.Length) // 已经没有词了，退出
                {
                    break;
                }

            }

            ///  对于（w1,w2）（w3,w4）,w2w3的结合力必须同时小于w1w2和w3w4

            i = 0;

            List<string> s1 = new List<string>();
            List<string> s2 = new List<string>();
 
            while (true)
            {
                i += GetWa1_Wa2(i, s1, s2, sWords, bL);

                // 退出条件
                if (s1.Count == 0 || s2.Count == 0)
                {
                    break;
                }

                if (!isValidDivide(s1, s2))
                {
                    pSum = -10000D;
                    break;          // 直接break，没有进行下去的必要了 
                }

            }

            return pSum;
        }

        private int GetWa1_Wa2(int i, List<string> s1,List<string> s2,string[]sWords,UInt32[] bL)
        {
            if (bL[i] != 1)
            {
                return 0;
            }
            int cnt = 0;

            // 清空里面的 元素
            s1.Clear();
            s2.Clear();

            if (i < bL.Length)
            {
                s1.Add(sWords[i]);
                cnt++;
                i++;
            }
            else
            {
                return 0;
            }

            if (i < bL.Length && bL[i] == 0)
            {
                s1.Add(sWords[i]);
                i++;
                cnt++;
            }

            if (i < bL.Length && bL[i] == 1)
            {
                s2.Add(sWords[i]);
                i++;
            }

            if (i < bL.Length && bL[i] == 0)
            {
                s2.Add(sWords[i]);
            }

            return cnt;
        }

        /*
         * 函数功能：判断两个词组v1和 v2是否被正确地切分
         *           判断前后相邻的两个词组的结合力 是否小于两边
         * 参数说明：s1,第一个词组
         *           s2,第二个词组
         *          
         * 返回值：词组的结合力 是否小于两边，返回true
         *                          大于两边，返回false
         */

        public bool isValidDivide( List<string> s1,List<string> s2)
        {
            if (s1.Count > 2 || s2.Count > 2)
            {
                return false;
            }

            // AB CD 的情形
            if (s1.Count == 2 && s2.Count == 2)
            {
                string w1 = s1[0]; // 第一个词组
                string w2 = s1[1];

                string w3 = s2[0]; // 第二个词组
                string w4 = s2[1];

                double P12 = Math.Log10((double) m_wco.GetWord2Pro_new(w1,w2));
                double P1 = Math.Log10((double)m_wco.GetProWord_new(w1));
                double P2 = Math.Log10((double)m_wco.GetProWord_new(w2));

                double H12 = P12 - P1 - P2;

                double P34 = Math.Log10((double)m_wco.GetWord2Pro_new(w3, w4));
                double P3 = Math.Log10((double)m_wco.GetProWord_new(w3));
                double P4 = Math.Log10((double)m_wco.GetProWord_new(w4));

                double H34 = P34 - P3 - P4;

                double P23 = Math.Log10((double)m_wco.GetWord2Pro_new(w2, w3));

                double H23 = P23 - P2 - P3;

                if ( H23 < Math.Max(H12, H34))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            } // AB C 的情形
            else if (s1.Count == 2 && s2.Count == 1)
            {
                string w1 = s1[0]; // 第一个词组
                string w2 = s1[1];

                string w3 = s2[0]; // 第二个词组

                double P12 = Math.Log10((double)m_wco.GetWord2Pro_new(w1, w2));
                double P1 = Math.Log10((double)m_wco.GetProWord_new(w1));
                double P2 = Math.Log10((double)m_wco.GetProWord_new(w2));

                double H12 = P12 - P1 - P2;

                double P3 = Math.Log10((double)m_wco.GetProWord_new(w3));
                double P23 = Math.Log10((double)m_wco.GetWord2Pro_new(w2, w3));

                double H23 = P23 - P2 - P3;

                if (H23 < H12)
                {
                    return true;
                }
                else
                {
                    return false;
                }


            }// A BC 的情形
            else if (s1.Count == 1 && s2.Count == 2)
            {
                string w1 = s1[0]; // 第一个词组

                string w2 = s2[0];
                string w3 = s2[1]; // 第二个词组

                double P23 = Math.Log10((double)m_wco.GetWord2Pro_new(w2, w3));
                double P2 = Math.Log10((double)m_wco.GetProWord_new(w2));
                double P3 = Math.Log10((double)m_wco.GetProWord_new(w3));

                double H23 = P23 - P2 - P3;

                double P1 = Math.Log10((double)m_wco.GetProWord_new(w1));
                double P12 = Math.Log10((double)m_wco.GetWord2Pro_new(w1, w2));

                double H12 = P12 - P1 - P2;

                if (H12 < H23)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            } // A  B 的情况
            else if (s1.Count == 1 && s2.Count == 1)
            {
                return true;
            }
            else // 未知状况 ，return false
            {
                return false;
            }
        }

        /*
         * 函数功能：计算字数组sWords中从stPos到edPos（ [stPos,edPos), 不包括edPos）的字组成的词的概率
         * 参数说明：sWords字数组；
         *           stPos，起始位置；
         *           edPos，终止位置（不包含）
         * 返回值： 从stPos到edPos（不包括edPos）的字组成的词的 对数概率
         */

        private double calcProbability(string[] sWords, int stPos, int edPos)
        {
            if (stPos >= edPos)
            {
                return -100000D; // 充分小的数
            }

            if (edPos - stPos == 1)
            {
                return Math.Log10((double)m_wco.GetProWord_new(sWords[stPos])); // 返回单个字的概率
            }
            else if (edPos - stPos == 2)
            {
                string w1 = sWords[stPos];
                string w2 = sWords[stPos + 1];

                double p2 = Math.Log10((double)m_wco.GetProWord_new(w2));            // w2的概率P(w2)
                double pc = Math.Log10((double)m_wco.GetWord2Pro_condition(w1, w2)); // 条件概率P(w2|w1)

                if (pc < p2) // P(w2|w1)<P(w2),不能构成一个词
                {
                    return -1000D;
                }

                return Math.Log10((double)m_wco.GetWord2Pro_new(w1, w2));
            }
            else
            {
                MessageBox.Show("二阶位串 出错！！");
                return -10000D;
            }
            //return rd;
        }

        /*
         * 函数功能：计算字数组sWords中从stPos到edPos（不包括edPos）的互信息（结合力）
         * 参数说明：sWords字数组；
         *          stPos，起始位置；
         *          edPos，终止位置（不包含）
         * 返回值： 互信息
         */
        public double MutlInfo(string[] sWords, int stPos, int edPos)
        {

            if (stPos >= edPos)
            {
                return 0; // 结合度为0
            }

            if (edPos - stPos == 1)
            {
                return 0; // 返回单个字的概率

                //string w1 = sWords[stPos];
                //Decimal pw1 = m_wco.GetProWord_new(w1);
                //return Math.Log10((double)(1.0M / pw1)); 

            }
            else if (edPos - stPos == 2)
            {
                string w1 = sWords[stPos];
                string w2 = sWords[stPos + 1];

                /////============ 首先满足条件概率和自身概率的关系
                double p2 = Math.Log10((double)m_wco.GetProWord_new(w2)); // w2的概率P(w2)
                double pc = Math.Log10((double)m_wco.GetWord2Pro_condition(w1, w2));//条件概率P(w2|w1)

                if (pc < p2) // P(w2|w1)<P(w2),不能构成一个词
                {
                    return -1000D; // 很小很小的结合力
                }

                Decimal pw12= m_wco.GetWord2Pro_new(w1, w2);
                Decimal pw1_pw2=m_wco.GetProWord_new(w1)*m_wco.GetProWord_new(w2);

                return Math.Log10((double)(pw12 / pw1_pw2)); // 互信息的计算公式log[p(w1w2)/(p(w1)p(w2))]
            }
            else
            {
                MessageBox.Show("二阶位串 出错！！");
                return 0;
            }
        }

//=========================================================

        /*
         * 函数功能：计算字数组sWords中从stPos到edPos（不包括edPos）的字组成的词的概率
         * 参数说明：sWords字数组；
         *          stPos，起始位置；
         *          edPos，终止位置（不包含）
         * 返回值： 从stPos到edPos（不包括edPos）的字组成的词的 对数概率
         */

        private double calcProbability_condition(string[] sWords,int stPos,int edPos)
        {
            //double rd = 0D;
            int i = 0;

            if (stPos >= edPos)
            {
                return -100000D; // 充分小的数
            }

            if (edPos - stPos == 1)
            {
                return Math.Log10((double)m_wco.GetProWord_4Condition(sWords[stPos])); // 返回单个字的概率
            }

            double numera = Math.Log10((double)m_wco.GetProWord_4Condition(sWords[stPos]));

            // 对数使得 乘法 变 加法
            for (i = 0; i < edPos - stPos - 1; ++i)
            {
                numera += Math.Log10((double)m_wco.GetWord2Pro_condition(sWords[stPos + i], sWords[stPos+i + 1])); // 先计算分子
            }

            return numera;
        }

        // // /////////////////
        private WCE_FromFile_DB m_wco = null;
        private string m_str = null;
    }
}
