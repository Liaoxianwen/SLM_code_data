﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

using System.IO;

namespace ViWordAna
{
    /*
     * 类说明：句子长度统计 ， 用于比较 条件概率检查切分的句子长度，（条件概率检查+结合力检查）切分的句子长度
     * 
     * **/

    public class SentsLenStatics
    {
        public SentsLenStatics( string sFilePathName)
        {
            m_sFilePathName = sFilePathName;
            GetMax_AvgSentsLen();
        }


        public void GetMax_AvgSentsLen()
        {
            StreamReader sr = new StreamReader(m_sFilePathName);
            string sLine = null;

            int MaxSents = -10;
            double sumLen = 0;
            int numofSents = 0;
            int val = 20;
            int numofSents20 = 0;
           

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();
                if (sLine.Length <= 0)
                {
                    continue;
                }

                int len = GetSentsLen(sLine);

                if (len > MaxSents)
                {
                    MaxSents=len;
                }

                if (len > val)
                {
                    numofSents20++;
                }


                sumLen += len;
                numofSents++;
            }

            double avgLen = sumLen / numofSents;

            MessageBox.Show("平均长度="+avgLen.ToString()+"  ,最大长度="+MaxSents.ToString()+"长度超过20的句子数量："+numofSents20.ToString()+
                "所占比例："+(((double)numofSents20)/numofSents).ToString());

        }

        private int GetSentsLen(string str)
        {
            int pos = str.IndexOf("（");
            string s = str.Substring(0,pos);

            string[] sp = { " " };

            string[] arr = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            return arr.Length;
        }



        private string m_sFilePathName = null;
    }
}
