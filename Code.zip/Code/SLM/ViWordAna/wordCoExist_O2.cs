﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ViWordAna
{
    class wordCoExist_O2
    {
        public wordCoExist_O2( string []filePname)
        {
            m_FilePathNames = filePname;
            m_DWordIndx = new Dictionary<string, emergeTimes>();
        }

        /*
         * 函数功能：只是数一数看看有多少单字，并建立一个单个字的索引（在共现数组中的行号、列号）
         * 参数说明：隐参数，corpus 文件列表
         * 返回值：  多少个字
         */
        public UInt32 ExtractWords(System.Windows.Forms.Label lb)
        {
            int i = 0;

            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;

            string s1 = ((char)0x200B).ToString(); // 特殊占位字符
            string s2 = ((char)0x00AD).ToString(); // 特殊占位字符

            for (i = 0; i < m_FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(m_FilePathNames[i]);
                lb.Text = m_FilePathNames[i];

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (isSegmentLine(str))
                    {
                        continue;
                    }

                    str = str.Replace(s1,""); // 过滤掉前面列出的特殊占位字符
                    str = str.Replace(s2,""); // 

                    // 用单个字的分隔符把 单字分开
                    words = ws.dowordSeg(str);

                    // 把分字的结果添加到 已 发现的 字典中去，字典包括已经发现的字的次序，字出现的次数
                    AddWordArr2WList(words);

                }

                sr.Close();
                sr.Dispose();
            }


            return (UInt32)m_DWordIndx.Count;
        }

        public UInt32 ExtractWords_cased(System.Windows.Forms.Label lb)
        {
            int i = 0;

            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;

            string s1 = ((char)0x200B).ToString(); // 特殊占位字符
            string s2 = ((char)0x00AD).ToString(); // 特殊占位字符

            for (i = 0; i < m_FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(m_FilePathNames[i]);
                lb.Text = m_FilePathNames[i];

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (isSegmentLine(str))
                    {
                        continue;
                    }

                    str = str.Replace(s1, ""); // 过滤掉前面列出的特殊占位字符
                    str = str.Replace(s2, ""); // 

                    // 用单个字的分隔符把 单字分开
                    //words = ws.dowordSeg(str);
                    words = ws.dowordSeg_ResDigital_Cased(str);

                    // 把分字的结果添加到 已 发现的 字典中去，字典包括已经发现的字的次序，字出现的次数
                    AddWordArr2WList(words);

                }

                sr.Close();
                sr.Dispose();
            }


            return (UInt32)m_DWordIndx.Count;
        }

        /*
         * 函数功能：一个词集 添加到已经发现的词集中去
         * 参数说明：words，一个字符串拆分之后所得的 字 集
         * 返回值：无。（子集成功添加到字典中去）
         *
         */

        private void AddWordArr2WList(string [] words)
        {
            int i = 0;

            if (words == null || words.Length == 0)
            {
                return;
            }

            for (i = 0; i < words.Length; ++i)
            {
                if (!isViWord(words[i])) // 不是越南语单词
                {
                    continue;
                }

                // 如果之前已经发现了 存在一个字 ,出现的次数 + 1
                if (m_DWordIndx.ContainsKey(words[i]))
                {
                    m_DWordIndx[words[i]].m_Cnt++;
                    continue;
                }

                emergeTimes et = new emergeTimes();
                et.m_Cnt = 1;  // 新出现的单词，出现1次
                et.m_Indx = (UInt32)m_DWordIndx.Count;  // 单词在出现序列的下标，第1次是0，第2次是1

                m_DWordIndx[words[i]] = et;

            }
        }

        /*
        * 函数功能：判断 str是否是分隔行
        * 参数说明：str，一行字符
        * 返回值：true，是分隔行
        *         false ，不是分隔行
        */

        public static  bool isSegmentLine(string str)
        {
            if (str.IndexOf("<doc") >= 0 && str.IndexOf("id") > 0 && str.IndexOf("url") > 0 && str.IndexOf("title") > 0)
            {
                return true;
            }
            else if (str.IndexOf(@"</doc>") >= 0)
            {
                return true;
            }

            return false;
        }

        public void SaveWords(StreamWriter sw)
        {
            int i = 0;

            Dictionary<string, emergeTimes> dic1_SortedByVal = m_DWordIndx.OrderByDescending(o => o.Value.m_Cnt).ToDictionary(p => p.Key, o => o.Value);

            for (i = 0; i < dic1_SortedByVal.Count; ++i)
            {
                KeyValuePair<string, emergeTimes> kp = dic1_SortedByVal.ElementAt(i);
                sw.WriteLine(kp.Key+":" +kp.Value.m_Indx.ToString()+","+kp.Value.m_Cnt.ToString());
            }
        }

        /*
          * 函数功能：判断单词 sWord 是不是一个越南语单词
          * 参数说明：sWord 单词字符串
          * 返回值：是越南语单词返回 true，否则 false
          */
        private bool isViWord(string sWord)
        {
            int i = 0;

            for (i = 0; i < sWord.Length; ++i)
            {
                if (sWord.Equals("")||!isViAlphabet(sWord[i])) // 有一个字符不是越南语字母，不是越南语单词
                {
                    return false;
                }
            }

            return true;
        }


        /*
         * 函数功能：判断字符 是不是一个越南语字符
         * 参数说明：c 字符
         * 返回值：是越南语字符返回 true，否则 false
         */
        private bool isViAlphabet(char c)
        {
            int i = 0;

            for (i = 0; i < m_NoVi.Length; ++i)
            {
                if (c == m_NoVi[i]) // 在字符集当中，false
                {
                    return false;
                }
            }

            return true;
        }


        static private char[] m_NoVi = { 'f','j','w','z'};// 不是越南语字母

        static private char[] m_Vichar = { 'a','ă','â','b','c','d','đ','e','ê','g', 
                                           'h','i','k','l','m','n','o','ô','ơ','p',
                                           'q','r','s','t','u','ư','v','x','y'};
        private Dictionary<string, emergeTimes> m_DWordIndx;
        private string[] m_FilePathNames;
    }
}
