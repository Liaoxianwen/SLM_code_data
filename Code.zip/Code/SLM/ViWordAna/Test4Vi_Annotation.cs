﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.IO;

namespace ViWordAna
{
    /*
     *  人工标注实验 结果的统计 
     *  
     *  三个越南留学生：HOANG THI MAI LINH
                        TRINH HOANG HA
     *                  LU THI THANH HIEN
     *                  
     *   对三篇 来自 vnExpress 上的 短文进行标注

     * 
     */


    /*
     * 类说明：用来表示一个句子，包括很多词
     * 
     * 
     * **/

    public class WordsOFSentence
    {
        public WordsOFSentence()
        {
        }

        /*
         * 函数功能：返回这句话种多少个 词（WSU）
         * 参数说明：无
         * 返回值：数量
         */
        public int NumOfWords()
        {
            return m_Lstwds.Count;
        }

        /*
        * 函数功能：返回这句话中 n阶 的WSU的个数
        * 参数说明：无
        * 返回值：数量
        */
        public int NumOfWords(int n)
        {
            int i = 0;
            int cnt = 0;

            for (i = 0; i < m_Lstwds.Count; ++i)
            {
                if (m_Lstwds[i].m_sLst.Count == n)
                {
                    cnt++;
                }
            }

            return cnt;
        }

        /*
         * 函数功能：该句子 是否包含 该越南语单词 
         * 参数说明：vw，一个指定的越南语单词
         * 
         * 返回值：true，包含
         *         false，不包含
         * 
         */
        public bool HasAword( viWord vw)
        {
            int i = 0;
            for (i = 0; i < m_Lstwds.Count; ++i)
            {
                if (vw == m_Lstwds[i] && m_Lstwds[i].m_bHasAccess == false )
                {
                    m_Lstwds[i].m_bHasAccess = true;
                    return true;
                }
            }

           return false;
        }

        /*
         * 函数功能：把带标签（BMES）的句子 写入到文件中去。
         * 参数说明：sw，写入流
         * 
         * 返回值：无
         * 
         */

        public void Write2File_Taged_BEMS( StreamWriter sw)
        {
            int i = 0;

            for (i = 0; i < m_Lstwds.Count; ++i)
            {
                m_Lstwds[i].Write2File_Tagged_BMES(sw);
            }

        }


        // 句子的属性：包含的 WSU 列表

        public List<viWord> m_Lstwds = new List<viWord>();
    }


    /*
     * 类说明：对人工标注的结果进行各种统计
     *  
     */


    public class Test4Vi_Annotation
    {
        public Test4Vi_Annotation()
        {
        }

        /*
         * 函数功能：加载一个文件，以句子为单位读取词
         *           只能对以 “///////”进行行 分隔的文本进行读取
         * 
         * 
         * 参数说明：sFileName，文件名
         * 返回值：句子列表
         * 
         */

        public List<WordsOFSentence> GetWordsFromFile( string sFileName )
        {
            List<WordsOFSentence> lst = new List<WordsOFSentence>();

            int i=0;
            string sLine = null;
            List<string> Lstr = new List<string>();

            StreamReader sr = new StreamReader(sFileName);
            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();
                Lstr.Add(sLine);
            }

            sr.Close();
            sr.Dispose();

            int SentsBeg = 0;
            int SentsEnd = 0;
            int j = 0;

            for (i = 0; i < Lstr.Count;)
            {
                if (Lstr[i].IndexOf("/////") >= 0)
                {
                    WordsOFSentence wofs = new WordsOFSentence();
                    SentsBeg = i + 1;
                    SentsEnd = GetNextSentsBeg(i,Lstr);

                    for (j = SentsBeg; j < SentsEnd; ++j)
                    {
                        viWord vw = GetWordFromString(Lstr[j]);

                        if (vw.m_sLst.Count > 0)
                        {
                            wofs.m_Lstwds.Add(vw);
                        }
                    }

                    i = SentsEnd;

                    lst.Add(wofs);

                }
            }

            return lst;
        }

        /*
         * 函数功能：找到下一个 句子开始的位置
         * 参数说明：currIndx，当前句子分隔符的位置
         *           L，列表L
         *           
         * 返回值：下一个句子分隔符开始的位置
         * 
         * **/

        private int GetNextSentsBeg(int currIndx, List<string> L)
        {
            int i = 0;

            for (i = currIndx + 1; i < L.Count; ++i)
            {
                if (L[i].IndexOf("/////") >= 0) // 找到了
                {
                    return i;
                }
            }

            return i;

        }

        /*
         * 函数功能：从一个字符串中提取 一个 词
         * 参数说明：str，一个字符串
         * 返回值：一个词
         * 
         */

        private viWord GetWordFromString( string str)
        {
            viWord vw = new viWord();

            string[] sp = { " ", ".", "(", ")", ",", "\"", " ","\t" };

            string[] A = str.Split(sp,StringSplitOptions.RemoveEmptyEntries);

            int i = 0;

            for (i = 0; i < A.Length; ++i)
            {
                vw.m_sLst.Add(A[i].ToLower());
            }
            
            return vw;
        }

        /*
         * 函数功能：获取该测试数据集 所有的 WSU的数量
         * 参数说明：lwofs ，该数据集的所有句子
         * 
         * 返回值：总的 WSU的数量
         * 
         * ***/

        public int GetNumOfWords(List<WordsOFSentence> lwofs)
        {
            int i = 0;
            int sum = 0;

            for (i = 0; i < lwofs.Count; ++i)
            {
                sum += lwofs[i].NumOfWords();
            }

            return sum;
        }

        /*
        * 函数功能：获取该测试数据集 所有的 >=N阶的 WSU的数量
        * 参数说明：lwofs ，该数据集的所有句子
        * 
        * 返回值：总的 >=N阶的 WSU的数量
        * 
        * ***/

        public int GetNumOfWords_N_odr(List<WordsOFSentence> lwofs,int N)
        {
            int i = 0;
            int sum = 0;

            for (i = 0; i < lwofs.Count; ++i)
            {
                sum += lwofs[i].NumOfWords(N);
            }

            return sum;
        }

        /*
         * 函数功能：根据 句首 句尾 单词 判断两个句子是否相等 
         * 参数说明：sa，句子a
         *           sb，句子b
         *           
         * 返回值：相等，true
         *         不相等，false
         * 
         */

        public bool isSameSentense(WordsOFSentence sa,WordsOFSentence sb)
        {
            if (sa.m_Lstwds.Count == 0 && sb.m_Lstwds.Count == 0)
            {
                return true;
            }

            int a0 = sa.m_Lstwds.Count - 1;
            int b0 = sb.m_Lstwds.Count - 1;
            int a1 = sa.m_Lstwds[a0].m_sLst.Count - 1;
            int b1 = sb.m_Lstwds[b0 ].m_sLst.Count - 1;

            if (!sa.m_Lstwds[0].m_sLst[0].Equals(sb.m_Lstwds[0].m_sLst[0]))
            {
                string strA = sa.m_Lstwds[0].m_sLst[0];
                string strB = sb.m_Lstwds[0].m_sLst[0];

                if (strA.IndexOf(strB) >= 0 || strB.IndexOf(strA) >= 0) // ipod 会被分成 i和pod ，很奇特 ，为了处理这种情况
                {
                    return true;
                }

                MessageBox.Show("句 首 单词 不等！句子不 对齐！");
                return false;
            }

            if (!sa.m_Lstwds[a0].m_sLst[a1].Equals(sb.m_Lstwds[b0].m_sLst[b1]))
            {
                string strA = sa.m_Lstwds[a0].m_sLst[a1];
                string strB = sb.m_Lstwds[b0].m_sLst[b1];

                if (strA.IndexOf(strB) >= 0 || strB.IndexOf(strA) >= 0) // ipod 会被分成 i和pod ，很奇特 ，为了处理这种情况
                {
                    return true;
                }


                MessageBox.Show("句 尾 单词 不等！句子不 对齐！");
                return false;
            }

            return true;
        }

        /*
         * 函数功能：计算两个分词方案 相同的词（WSU）的数量
         * 参数说明：La，第一种分词方案
         *           Lb，第二种分词方案
         * 
         * 返回值：相同的词的数量
         */

        public int NumOfCommonWords(List<WordsOFSentence> La, List<WordsOFSentence> Lb)
        {
            int sum = 0;
            int i = 0;
            int N = Math.Min(La.Count,Lb.Count);

            for (i = 0; i < N; ++i)
            {
                sum += NumOfCommonWords(La[i],Lb[i]);
            }
            
            return sum; 
        }

        /*
         * 函数功能：计算两个分词方案中 大于 等于 N阶词（WSU）的数量
         * 参数说明：La，分词方案 a
         *           Lb，分词方案 b
         *           N，N阶词
         * 
         * 返回值：大于等于N阶词（WSU）的数量
         */
        public int NumOfCommonWords_N_odr(List<WordsOFSentence> La, List<WordsOFSentence> Lb,int N)
        {
            int sum = 0;
            int i = 0;
            int mN = Math.Min(La.Count,Lb.Count);

            for (i = 0; i < mN; ++i)
            {
                sum += NumOfCommonWords_N_odr(La[i], Lb[i],N);
            }

            return sum;
        }

        /*
         * 函数功能：计算两个句子中 相同的 WSU的数量
         * 参数说明：sa,句子a
         *           sb，句子b
         *           
         * 返回值：两个句子相同wsu的数量
         * 
         */

        public int NumOfCommonWords(WordsOFSentence sa,WordsOFSentence sb )
        {
            int i = 0;
            int cnt=0;


            for (i = 0; i < sa.m_Lstwds.Count; ++i)
            {
                if (sb.HasAword(sa.m_Lstwds[i]))
                {
                    cnt++;
                }
            }
            
            return cnt;
        }

        /*
         * 函数功能：获取两句话中 N阶的 WSU的数量
         * 参数说明：sa，句子a
         *           sb，句子b
         *           N，N阶词
         *           
         * 返回值：大于 等于 N阶的 WSU的数量
         */

        public int NumOfCommonWords_N_odr(WordsOFSentence sa, WordsOFSentence sb,int N)
        {
            int i = 0;
            int cnt = 0;


            for (i = 0; i < sa.m_Lstwds.Count; ++i)
            {
                if (sb.HasAword(sa.m_Lstwds[i]) && sa.m_Lstwds[i].m_sLst.Count ==N)
                {
                    cnt++;
                }
            }

            return cnt;
        }

        /*
         * 函数功能：获得 两个分词 的相似度
         * 参数说明：sFileA，文件A存储的第一个分词方案
         *           sFileB，文件B存储的第二个分词方案
         *           
         * 返回值：分词的相似度
         * 
         * **/

        public double GetSimilarity(string sFileA, string sFileB)
        {
            List<WordsOFSentence> La = GetWordsFromFile(sFileA); // 获取第一个分词文件的 所有句子
            List<WordsOFSentence> Lb = GetWordsFromFile(sFileB); // 获取第二个分词文件的 所有句子

            double dsimi = GetSimilarity(La,Lb); // 获取这两种分词方案的 相似度

            return dsimi;
        }

        /*
         * 函数功能：获取两个分词 方案的 相似度 
         * 参数说明：La，第一种分词方案
         *           Lb，第二种分词方案
         * 
         * 返回值：相似度
         * 
         */

        public double GetSimilarity(List<WordsOFSentence> La, List<WordsOFSentence>  Lb)
        {
            if (La == null || Lb == null)
            {
                return 0;
            }

            /*
            if (La.Count != Lb.Count)
            {
                MessageBox.Show("句子数量  不  相  等 ！");
                return 0;
            }
             */

            int i = 0;
            int N = Math.Min(La.Count,Lb.Count);

            for (i = 0; i < N; ++i)
            {
                try
                {
                    if (!isSameSentense(La[i], Lb[i]))
                    {
                        return 0;
                    }
                }
                catch (System.Exception eee)
                {
                    int kkk = i;

                    WordsOFSentence wsLa = La[i];
                    WordsOFSentence wsLb = Lb[i];


                }
            }

            int totalWord =(int)( 0.5*(GetNumOfWords(La) + GetNumOfWords(Lb))); // 总共有多少词

            int M = NumOfCommonWords(La,Lb);// 相同的 WSU的数量

            double p = ((double)M) / totalWord;

            return p;

        }

        /*
         * 函数功能：指定某个阶数， 获得分词方案sFileB的召回率，以 sFilestd为参考标注
         * 参数说明：sFilestd，作为参考的 标准 分词方案
         *           sFileB，待评价分词方案
         *           odr，阶数
         *           
         * 返回值：大于等于 odr阶词的 召回率
         * **/
        public double GetReCall(string sFilestd, string sFileB,int odr)
        {
            List<WordsOFSentence> Lstd = GetWordsFromFile(sFilestd);
            List<WordsOFSentence> Lb = GetWordsFromFile(sFileB);

            double dsimi = GetReCall(Lstd, Lb, odr);

            return dsimi;
        }

        public double GetPricsi(string sFilestd, string sFileB, int odr)
        {
            List<WordsOFSentence> Lstd = GetWordsFromFile(sFilestd);
            List<WordsOFSentence> Lb = GetWordsFromFile(sFileB);

            double dsimi = GetPricision(Lstd, Lb, odr);

            return dsimi;
        }

        public double GetErrorR(string sFilestd, string sFileB, int odr)
        {
            List<WordsOFSentence> Lstd = GetWordsFromFile(sFilestd);
            List<WordsOFSentence> Lb = GetWordsFromFile(sFileB);

            double dsimi = GetErrorRate(Lstd, Lb, odr);

            return dsimi;
        }

        public void ResetAccessFlag(List<WordsOFSentence> L)
        {
            int i = 0;
            int j = 0;

            for (i = 0; i < L.Count; ++i)
            {
                for (j = 0; j < L[i].m_Lstwds.Count; ++j)
                {
                    L[i].m_Lstwds[j].m_bHasAccess = false;
                }
            }
        }

        


        /*
         * 函数功能：指定某个阶数， 获得分词方案sFileB的召回率，以 sFilestd为参考标注
         * 参数说明：sFilestd，作为参考的 标准 分词方案
         *           sFileB，待评价分词方案
         *           odr，阶数
         *           
         * 返回值：大于等于 odr阶词的 召回率
         * **/

        public double GetReCall(List<WordsOFSentence> LSTD, List<WordsOFSentence> Lb,int odr)
        {
            if (LSTD == null || Lb == null)
            {
                return 0;
            }

            int minN = Math.Min(LSTD.Count, Lb.Count);
            int i = 0;

            for (i = 0; i < minN; ++i)
            {
                if (!isSameSentense(LSTD[i], Lb[i]))
                {
                    return 0;
                }
            }

            int N = 0;

            if (odr == -1)
            {
                N = GetNumOfWords(LSTD);
            }
            else
            {
                N = GetNumOfWords_N_odr(LSTD,odr);
            }


            int M = 0;

            if (odr == -1)
            {
                M = NumOfCommonWords(Lb, LSTD);
            }
            else
            {
                M = NumOfCommonWords_N_odr(Lb, LSTD, odr);
            }


            double p = ((double)M) / N;

            return p;
        }

        /*
         * 函数功能：获得 分词的准确率（即在 Lb中，正确的词 比例 ）
         * 参数说明：LSTD，标准分词
         *           Lb，待评价分词
         *           odr，词的阶数
         *           
         * 返回值：分词的准确率
         * 
         * **/

        public double GetPricision(List<WordsOFSentence> LSTD, List<WordsOFSentence> Lb, int odr)
        {

            if (LSTD == null || Lb == null)
            {
                return 0;
            }

            int minN = Math.Min(LSTD.Count, Lb.Count);
            int i = 0;

            for (i = 0; i < minN; ++i)
            {
                if (!isSameSentense(LSTD[i], Lb[i]))
                {
                    return 0;
                }
            }

            int N = 0;

            if (odr == -1)
            {
                N = GetNumOfWords(Lb); // 自己所分词的总数
            }
            else
            {
                N = GetNumOfWords_N_odr(Lb, odr); // 自己所分词中 n阶词的个数
            }


            int M = 0;

            if (odr == -1)
            {
                M = NumOfCommonWords(Lb, LSTD); // 分对了多少个 
            }
            else
            {
                M = NumOfCommonWords_N_odr(Lb, LSTD, odr); // 分对了多少个 n阶词 
            }

            double p = ((double)M) / N; // 自己所分的那么多词中，有几个是对的 

            return p;

        }

        /*
         * 函数功能：计算 错误的分词率 
         * 参数说明：LSTD,标准分词
         *           Lb，待评价的分词
         *           odr,阶数
         *           
         * 返回值：错误率
         * 
         */

        public double GetErrorRate(List<WordsOFSentence> LSTD, List<WordsOFSentence> Lb, int odr)
        {
            if (LSTD == null || Lb == null)
            {
                return 0;
            }

            int minN = Math.Min(LSTD.Count, Lb.Count);
            int i = 0;

            for (i = 0; i < minN; ++i)
            {
                if (!isSameSentense(LSTD[i], Lb[i]))
                {
                    return 0;
                }
            }

            int N = 0;

            if (odr == -1)
            {
                N = GetNumOfWords(LSTD); // 标准的分词的个数
            }
            else
            {
                N = GetNumOfWords_N_odr(LSTD, odr); // 标准分词中 n阶词的个数
            }


            int M = 0;

            if (odr == -1)
            {
                M = NumOfCommonWords(Lb, LSTD);  // 分对了多少个 
            }
            else
            {
                M = NumOfCommonWords_N_odr(Lb, LSTD, odr); // n阶词 分对了多少个
            }

            int Nb = 0;
            if (odr == -1)
            {
                Nb = GetNumOfWords(Lb); // 自己所分词的总数
            }
            else
            {
                Nb = GetNumOfWords_N_odr(Lb, odr); // 自己的分词中，n阶词的个数
            }

            M = Nb - M; // 分错了多少个 


            double p = ((double)M) / N; // 自己所分的那么多词中，有几个是对的 

            return p;
        }


    }
}
