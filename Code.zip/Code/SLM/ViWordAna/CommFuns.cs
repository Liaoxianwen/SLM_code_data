﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViWordAna
{
    class CommFuns
    {
        /*
         * 函数功能：根据 数组sWord的长度生成搜索空间
         * 参数说明：sWord，字数组
         * 返回值：一个整数
         */
        public static UInt32 GenSearchSpace(string[] sWord)
        {

            // 没有必要那么复杂，直接这样计算：
            return (UInt32)Math.Pow(2.0D, (double)sWord.Length); 


            int i = 0;
            UInt32 uVal = 0;

            for (i = 0; i < sWord.Length; ++i)
            {
                uVal += (UInt32)Math.Pow(2.0D, (double)i);
            }

            return uVal + 1; // 
        }


        /*
         * 函数功能：找下一个词 开始 的位置（1表示词开始的位置，0 表示还是当前词的一部分）
         * 参数说明：bL，一种分词可行解
         *          currWordBeg，当前词的开始位置
         *          
         * 返回值：下一个词的开始位置
         * 
         * **/
        public static int NextWordBeg(UInt32[] bL, int currWordBeg)
        {
            int i = currWordBeg + 1;

            while (i < bL.Length)
            {
                if (bL[i] == 1)
                {
                    break;
                }

                ++i;
            }

            return i;
        }

        /*
         * 函数功能：把val变成二进制序列
         * 参数说明：val，一个数
         *          Len,指定的长度
         * 返回值：二进制序列，低位在前，高位在后
         * **/
        public static UInt32[] GenBinaryList(UInt32 val, int Len)
        {
            UInt32[] rt = new UInt32[Len];
            int i = 0;

            for (i = 0; i < Len; ++i)
            {
                rt[i] = val % 2;
                val = val / 2;

            }

            return rt;

        }

        /*
         * 函数功能：判断二进制串 是不是一个合法的 二阶bit串
         *          判断规则：不能有连续的 两个 0 
         * 参数说明：bL，位串
         *        
         * 返回值：true，合法
         *        false，不合法
         * **/
        public static bool isVaildBitSeq_2odr(UInt32[] bL)
        {
            int i = 0;
            int Len = bL.Length;

            if (Len <= 1)
            {
                return true;
            }

            for (i = 0; i < Len-1; ++i)
            {
                if (bL[i] == 0 && bL[i + 1] == 0) // 两个连续的 0 ，false
                {
                    return false;
                }
            }

            return true;
        }

        /*
         * 函数功能：判断二进制串 是不是一个合法的 n 阶bit串
         *          判断规则：不能有连续的 n 个 0 
         * 参数说明：bL，位串
         *        
         * 返回值：true，合法
         *        false，不合法
         * **/

        public static bool isVaildBitSeq_n_odr( UInt32[] bL, int n )
        {
            int i = 0;
            int Len = bL.Length;

            if ( bL.Length == 0 || n == 0 )
            {
                return false;
            }

            for (i = 0; i < Len - n + 1 ; ++i)
            {
                UInt32 tmpSum = 0;
                int j = 0;

                for (j = i; j < i + n; ++j)
                {
                    tmpSum += bL[j];
                }

                if (tmpSum == 0) // 连续 n 个零 ，只要出现 一次，就是 false
                {
                    return false;
                }

            }

            return true;
        }

        /*
         * 功能说明：判断位序列的某一位是否为1
         *          在设定某个字是一个词的开始时 用到
         * 
         * 参数说明：bL，位序列
         *          pos，位（单字）的位置，从0开始
         *          
         * 返回值: pos位为1，true
         *        否则为 false
         * 
         */

        public static bool isSPBit_Is_One(UInt32[] bL,int pos)
        {
            if (pos < 0 || pos >= bL.Length)
            {
                return false;
            }

            if (bL[pos] == 1)
            {
                return true;
            }

            return false;
        }

        /*
         * 函数功能：获取一个单词的各种 （切分）组合情况
         * 参数说明：originalWords，句子的原始单词序列
         *           st,单词的起始位置
         *           ed,单词结束位置的下一个位置，是一个半开半闭区区间：[st,ed)
         * 
         * 返回值：除了本身以外，该单词的各种可能切分
         * 
         * **/

        public static List<List<WordIndexPair>> GetAllCombination( int st,int ed )
        {
            if (ed - st <= 1) // ed <=st,非法； ed-st == 1,只有一个单词，则不能再切分，直接返回null
            {
                return null;
            }

            List<List<WordIndexPair>> Lall = new List<List<WordIndexPair>>();

            UInt32 i = 0;
            int wordLen = ed - st;

            int searchSpace = (int)Math.Pow(2, wordLen);

            for (i = 0; i < searchSpace; ++i)
            {
                if (i % 2 == 0) // 偶数的 换算成位序列的 第0位是零， 跳过
                {
                    continue;
                }
                if (i == 1) // 位序列第0位是1，其他都是0 ，跳过，因为这就是原始序列本身
                {
                    continue;
                }

                UInt32 []bL=GenBinaryList(i, wordLen);
                
                int curr_wBeg = 0;
                int next_wBeg = 0;

                List<WordIndexPair> Ltmp = new List<WordIndexPair>();

                while (next_wBeg < wordLen)
                {
                    next_wBeg = NextWordBeg(bL, curr_wBeg);
                    WordIndexPair widp = new WordIndexPair( st + curr_wBeg , st + next_wBeg ); // 需要加上一个偏移

                    Ltmp.Add(widp);

                    curr_wBeg = next_wBeg;
                }

                Lall.Add(Ltmp);
            }

            return Lall;
        }

        /*
         * 函数功能：判断数组 bL 表示的一个组合 ，是不是仅仅包含一个词，即它本身
         * 参数说明：bL，位序列
         *           bL[i] = 1,表示一个“切分”的开始，
         *           bL[i] = 0，表示之前开始的一个切分还没有结束
         *           
         * 返回值：true,仅仅是一个“词”，没有被切分
         *         false, 已经被切分了
         */

        public static bool IsSingleWord( UInt16 [] bL)
        {
            if (bL == null)
            {
                return false;
            }

            if (bL.Length == 1)
            {
                return true;
            }

            int sum = 0;
            int i = 0;

            if (!(bL[0] == 1)) // 第 0 位不是1 
            {
                return false; 
            }


            // i 从 1 开始，因为第0位肯定是零
            for (i = 1; i < bL.Length; ++i)
            {
                sum += bL[i];
            }

            if (sum == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
