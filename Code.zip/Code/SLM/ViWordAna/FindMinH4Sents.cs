﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ViWordAna
{
    public class String_Flag
    {
        public String_Flag() { }

        public string m_str="";
        public bool isVirtual = false;
    }

    public class FindMinH4Sents
    {
        public FindMinH4Sents(string str, CalcProbCond cpc)
        {
            m_str = str.ToLower();
            m_cpc = cpc;
            //PrintH4Sents();
        }

        public void PrintH4Sents()
        {
            string []sp = {" " };

            string[] arr = m_str.Split(sp,StringSplitOptions.RemoveEmptyEntries);

            int i = 0;
            string []sFirWd = new string[1];
            string []sSecWd = new string[1];
            double dH = 0;
            string sH = "";

            for (i = 0; i < arr.Length - 1; ++i)
            {
                sFirWd[0] = arr[i];
                sSecWd[0] = arr[i + 1];

                dH = (double)m_cpc.CalcH_AB(sFirWd,sSecWd);

                sH += Math.Round(dH,2).ToString() + ",";

            }

            StreamWriter sw = new StreamWriter("H4aSents.txt");
            sw.WriteLine(m_str);
            sw.WriteLine(sH);

            sw.Close();
            sw.Dispose();
        }

        /*
         * 函数功能：用最低的结合力将 str 拆开，注意 str中不能含有陌生单词
         * 
         *           str中可以保证没有纯的数字
         * 
         * 返回值：被拆分的 字符串
         * 
         * **/

        public List<string> SplitBy_H( string str)
        {
            List<string> lst = new List<string>();
            m_str = str.ToLower();

            int i = 0;

            wordSeg ws = new wordSeg();
            string[] arr =ws.dowordSeg(str);
            string[] arr_ori = ws.dowordSeg_ResDigital(str) ;
            
            if( arr.Length < 5) // 太短了，没必要，直接返回
            {
                lst.Add(str);
                return lst;
            }

            string[] sFirWd = new string[1];
            string[] sSecWd = new string[1];

            double[] dArr = new double[arr.Length-1];

            for (i = 0; i < arr.Length - 1; ++i)
            {
                sFirWd[0] = arr[i];
                sSecWd[0] = arr[i + 1];
                dArr[i] = (double)m_cpc.CalcH_AB(sFirWd, sSecWd);
            }


            int NewStrStart = 0;
            int j = 0;
            string stmp = "";

            double dMinH = GetMin_H_in_Arr(dArr);
            double dVal = 0; // 最低结合力 拆分 阈值

            if (dMinH > 0 && arr.Length > 15 )
            {
                dVal = dMinH + 0.01; // 如果这个序列很长，即使最低结合力大于0，也要拆分，否则计算量很大
            }

            for (i = 0; i < dArr.Length; ++i)
            {
                if (dArr[i] < dVal)
                {
                    stmp = "";
                    for (j = NewStrStart; j <= i; ++j)
                    {
                        stmp += " " + arr_ori[j];// 不要使用 arr,因为里面的数字会被过滤
                    }

                    lst.Add(stmp);

                    NewStrStart = i + 1;
                }

            }

            stmp = "";

            for (j = NewStrStart; j <= dArr.Length; ++j)
            {
                stmp += " " + arr_ori[j];// 不要使用 arr,因为里面的数字会被过滤
            }

            lst.Add(stmp);

            return lst;

        }

        /*
         * 函数功能：获取数组 dArr中的最小值。
         * 参数说明：dArr，数组
         * 
         * 返回值：dArr中的最小值。
         * 
         */
        private double GetMin_H_in_Arr(double[] dArr)
        {
            int i = 0;
            double mVal = 100000d;

            for (i = 0; i < dArr.Length; ++i)
            {
                if (dArr[i] < mVal)
                {
                    mVal = dArr[i];
                }
            }

            return mVal;
        }


        /*
         * 函数功能：恢复 那些 被 过滤掉的数字
         * 
         * **/
        public static void ResStoreWord(List<viWord> lvi, string str)
        {
            wordSeg ws = new wordSeg();
            string[] Arr = ws.dowordSeg_ResDigital(str);

            if (Arr.Length == 0)
            {
                return;
            }

            // 合并数字
            string[] M_Arr = MergeNum(Arr, str);

            // 可能需要多个数字需要合并，例如“6000.000.999”，已经被拆成了：6000，000，999
           /* while (!isTheSame(Arr, M_Arr))
            {
                M_Arr = Arr;
                Arr = MergeNum(M_Arr, str);
            }*/

            Arr = M_Arr;

            // 处理 “A5520SA的情况”
            List<String_Flag> lsf = GenerateDoubleString(Arr);

            int i = 0;
            int j = 0;
            int ArrIndx = 0;

            int sz = lvi.Count;

            for (i = 0; i < sz; ++i)
            {
                for (j = 0; j < lvi[i].m_sLst.Count; ++j)
                {
                    if (lvi[i].m_sLst[j].Equals(lsf[ArrIndx].m_str))
                    {
                        ArrIndx++;
                    }
                    else if (containss(lsf[ArrIndx].m_str, lvi[i].m_sLst[j]))
                    {
                        if (lsf[ArrIndx].isVirtual == false)
                        {
                            lvi[i].m_sLst[j] = lsf[ArrIndx].m_str;
                        }
                        else
                        {
                            lvi.RemoveAt(i);
                            sz=lvi.Count;
                            i--;
                        }
                        ArrIndx++;
                    }
                    else if (isNum(lsf[ArrIndx].m_str))
                    {
                        viWord vw = new viWord();
                        vw.m_sLst.Add(lsf[ArrIndx].m_str);
                        lvi.Insert(i, vw); // 插在当前位置的下一个位置

                        ArrIndx++;
                    }

                }
            }

            while (ArrIndx < lsf.Count-1)
            {
                viWord vw = new viWord();
                vw.m_sLst.Add(lsf[ArrIndx].m_str);
                lvi.Add(vw);
                ArrIndx++;
            }

        }

        public static List<String_Flag> GenerateDoubleString(string [] Arr)
        {
            int i = 0;
            wordSeg ws = new wordSeg();
            string []sT = null;

            List<String_Flag> ls = new List<String_Flag>();

            for (i = 0; i < Arr.Length; ++i)
            {
                sT = ws.dowordSeg(Arr[i]);
                if (sT == null || sT.Length <= 1) // 不会返回null，只会返回 Length==0的数组
                {
                    String_Flag sf = new String_Flag();
                    sf.m_str = Arr[i];
                    ls.Add(sf);
                }
                else
                {
                    int j = 0;
                    for (j = 0; j < sT.Length; ++j)
                    {
                        String_Flag sf = new String_Flag();
                        sf.m_str = Arr[i];

                        if (j > 0)
                        {
                            sf.isVirtual = true;
                        }
                        ls.Add(sf);
                    }
                }

            }

            return ls;
        }


        /*
        * 函数功能：判断两个数组的内容 是否完全 一致
        * 参数说明：A1，第一个数组
        *           A2，第二个数组
        * 返回值：true，两个数组一致
        *         false.不一致
        * **/

        public static bool isTheSame(string[] A1, string[] A2)
        {
            if ((A1==null ||A2==null )||(A1.Length != A2.Length))
            {
                return false;
            }

            int i = 0;

            for (i = 0; i < A1.Length; ++i)
            {
                if (!A1[i].Equals(A2[i]))
                {
                    return false;
                }
            }

            return true;
        }

        /*
         * 函数功能：合并数字。对于 “6000.000”的数字，会被拆分成 “6000”和“000”，
         *           现在需要合并成 “6000.000”
         *           
         * 参数说明：Arr,被拆分的数组，
         *           str，原字符串
         * 
         * **/

        public static string[] MergeNum(string[] Arr, string str)
        {
            if (Arr == null|| Arr.Length <=0)
            {
                return null;
            }

            int i = 0;
            List<string> lst = new List<string>();

            str = str.ToLower();

            int FindStartIndx = 0;
            int num_Beg = 0;

            for (i = 0; i < Arr.Length - 1; )
            {
                if (!isNum(Arr[i]))
                {
                    lst.Add(Arr[i]); // 直接把当前 字符串 保存起来

                    if (i < Arr.Length - 1)
                    {
                        num_Beg =       str.IndexOf(Arr[i+1], FindStartIndx); // 下一个单词的起始位置
                        FindStartIndx = str.IndexOf(Arr[i + 1], FindStartIndx) + Arr[i + 1].Length;
                    }
                    else
                    {
                        num_Beg = str.IndexOf(Arr[i], num_Beg);
                        num_Beg += Arr[i].Length;

                        FindStartIndx = str.IndexOf(Arr[i], FindStartIndx);
                        FindStartIndx += Arr[i].Length;
                    }

                    ++i;

                }
                else if (isNum(Arr[i]) && isNum(Arr[i + 1]))
                {
                    //int st1 = str.IndexOf(Arr[i], FindStartIndx);

                     //FindStartIndx = st1 + Arr[i].Length;

                    if (num_Beg == 0 && FindStartIndx == 0)
                    {
                        num_Beg = str.IndexOf(Arr[i], FindStartIndx); // 下一个单词的起始位置
                        FindStartIndx = str.IndexOf(Arr[i], FindStartIndx) + Arr[i].Length;
                    }
                   
                    int st2 = str.IndexOf(Arr[i + 1], FindStartIndx);

                    if (FindStartIndx + 1 == st2 && (str[FindStartIndx] == '.' || str[FindStartIndx] == ',' || str[FindStartIndx] == ':' || str[FindStartIndx] == '-'|| str[FindStartIndx] == '/'))
                    {
                        /*
                        lst.Add(Arr[i] + str[FindStartIndx].ToString() + Arr[i + 1]);
                        FindStartIndx = st2 + Arr[i + 1].Length;
                        i++; 不要立即保存，因为后面 还有可能是 数字
                         */

                        FindStartIndx = st2 + Arr[i + 1].Length;

                        i++;

                        if (i == Arr.Length - 1)
                        {
                            string stmp = str.Substring(num_Beg, FindStartIndx - num_Beg);
                            lst.Add(stmp.Trim());

                            num_Beg = FindStartIndx;
                        }
                    }
                    else
                    {      // 断开 了 
                        string stmp = str.Substring(num_Beg,FindStartIndx - num_Beg);

                        lst.Add(stmp.Trim());

                        num_Beg = st2;
                        FindStartIndx = st2 + Arr[i + 1].Length;
                        ++i;
                    }
                }
                else if (isNum(Arr[i]) && !isNum(Arr[i + 1]))
                {
                    //lst.Add(Arr[i]);

                    if (FindStartIndx == 0 && num_Beg == 0)
                    {
                        FindStartIndx = str.IndexOf(Arr[i], FindStartIndx)+ Arr[i].Length;
                    }

                    string stmp = str.Substring(num_Beg, FindStartIndx - num_Beg);
                    lst.Add(stmp.Trim());
                    //num_Beg = FindStartIndx;
                    num_Beg = str.IndexOf(Arr[i+1],FindStartIndx);
                    FindStartIndx = str.IndexOf(Arr[i + 1], FindStartIndx);

                    ++i;
                }
            }

            //string ttttt = str.Substring(num_Beg, str.Length - FindStartIndx);
            string ttttt = str.Substring(num_Beg, str.Length - num_Beg);

            if (!ttttt.Equals(""))
            {

                wordSeg ws = new wordSeg();
                string[] res = ws.dowordSeg_ResDigital(ttttt);

                if (res != null)
                {
                    for (i = 0; i < res.Length; ++i)
                    {
                        lst.Add(res[i]);
                    }
                }
            }

            string[] Art = new string[lst.Count];

            for (i = 0; i < lst.Count; ++i)
            {
                Art[i] = lst[i];
            }

            return Art;
        }

        public static bool containss(string wholeWord, string partial)
        {
            // 处理 A5520SA这种情况，比较复杂，只能简便处理
            if (wholeWord.IndexOf(partial) >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 函数功能：判断 partial 是不是 wholeWord 去掉 所有数字后剩下的
         * 参数说明：wholeWord，整个词，
         *           partial，wholeWord去掉数字后剩下的部分
         *           
         * 返回值：true，是，
         *         false,否
         * 
         * **/

        public static bool isNum_partial(string wholeWord, string partial)
        {

            string stmp = wholeWord.Replace(partial, "");

            if (isNum(stmp) && wholeWord.IndexOf(partial) >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        /*
         * 函数功能：判断 str 是不是 全是 数字
         * 参数说明：str，数字串
         * 
         * 返回值：true，全是数字，
         *         false，不全是数字
         */

        public static bool isNum(string str)
        {
            int i = 0;

            for (i = 0; i < str.Length; ++i)
            {
                if (str[i] != '0' &&
                    str[i] != '1' &&
                    str[i] != '2' &&
                    str[i] != '3' &&
                    str[i] != '4' &&
                    str[i] != '5' &&
                    str[i] != '6' &&
                    str[i] != '7' &&
                    str[i] != '8' &&
                    str[i] != '9' &&
                    str[i] != '.'&&
                    str[i] != ','&&
                    str[i] != '-'&&
                    str[i] != '/' &&
                    str[i] != ':')   // 点号 也算是数字 
                    return false;
            }

            return true;

        }

        private string m_str = null;
        private CalcProbCond m_cpc=null;
    }
}
