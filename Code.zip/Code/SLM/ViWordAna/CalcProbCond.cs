﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViWordAna
{
    /*
     * 类说明：负责从数据库中 查询数据，计算条件概率。
     *         使用缓存机制，不重复计算条件概率，提升效率
     * 
     * **/
    public class CalcProbCond
    {
        public CalcProbCond(DBConn db, Dictionary<string, int> wordDic, UInt32[] WordNums)
        {
            m_db = db;

            m_wordDic = wordDic;

            m_WordNums = WordNums;

            m_db.m_WordNums = WordNums;
            
            m_DicProHasCalc = new Dictionary<string, Decimal>();

            int k = 0;

            for (k = 0; k < 8; ++k)
            {
                int multi = 2*k;
                m_WordNum[k] = (int)((m_stastics[k, 1] + multi * m_stastics[k, 0]) / (multi + 1));
            }
        }

        /*
         * 函数功能：计算条件概率 P(B|A)的对数值 ,通常计算的条件概率是：P(w4,w5,w6,w7|w1,w2,w3)
         * 参数说明：A，字数组，A={w1,w2,w3...}
         *           B, 字数组, B={w5,w6,w7...}
         * 返回值：P(B|A),（已经过对数变换）
         * **/
        public Decimal CalcProb( string []A, string []B)
        {
            if (A == null || B == null || A.Length == 0 || B.Length == 0)
            {
                MessageBox.Show("计算条件概率的 字数组为null 或者 没有元素 ~！\n");
                return 0M;
            }

            if (A.Length + B.Length >= 9)
            {
                MessageBox.Show("阶数太高,超过8阶，计算不了\n A的阶数="+A.Length.ToString() + "\nB的阶数="+ B.ToString() );
                return 0M;

            }

            int odr = A.Length + B.Length;
            string[] T = new string[ odr];
            

            A.CopyTo(T, 0);
            B.CopyTo(T, A.Length);

            Decimal p_A = CalcProb(A, odr);
            Decimal p_AB = CalcProb(T, odr);

            Decimal p = p_AB-p_A;
            return p;
        }

        /*
         * 函数功能：计算 AB 的聚合度。 
         *                             P(AB)
         *              h(A,B) =  Log ————
         *                            P(A)P(B)
         * 参数说明：A，单字序列
         *           B, 单字序列
         *           
         * 返回值：AB的聚合度
         *
         */

        public Decimal CalcH_AB(string[]A, string[] B)
        {
            Decimal h = 0M;

            if (A == null || B == null)
            {
                MessageBox.Show("计算 AB 的聚合度时 A==null 或者 B==null\n");
                return -10000M;
            }

            Decimal LogpAB = CalcProb_AandB(A, B);
            Decimal LogpA  = CalcProb(A, A.Length);
            Decimal LogpB  = CalcProb(B, B.Length);

            if (LogpAB < -9000) // AB组成的词不存在，等于 A和B没有组合，结合力无穷小。 极端情况下！！！
            {
                return -3000;
            }

            h = LogpAB - (LogpA + LogpB);

            return h;
        }

        /*
         * 函数功能：计算概率 P(AB) 的对数值 ,通常计算的概率是：P(w1,w2,w3 &&w4,w5) 等
         * 参数说明：A，字数组，A={w1,w2,w3...}
         *           B, 字数组，B={w4,w5}
         *          
         * 返回值：P(AB)的对数值
         * **/

        public Decimal CalcProb_AandB(string[] A,string []B)
        {
            if (A == null || B == null)
            {
                MessageBox.Show("计算P（AB）的时候，A B中有一个为空！" );
                return -10000M;
            }

            string []T = new string[A.Length + B.Length];
            A.CopyTo(T,0);
            B.CopyTo(T, A.Length);

            return CalcProb(T,T.Length);
        }

        /*
         * 函数功能：查询 一个关联词的 出现 次数
         * 参数说明：
         * 
         * 返回值：出现次数
         * 
         */

        public int Get_Co_Word_Num(string[] A, int odr)
        {
            Decimal p = 0;

            if (A == null || A.Length == 0)
            {
                MessageBox.Show("计算概率出错！\n A=" + A.ToString());

                return 0;
            }

            if (A.Length > 8 || odr > 8) // 太长了，计算不了
            {
                return 0;
            }

            int[] ia = new int[A.Length];
            int i = 0;

            for (i = 0; i < A.Length; ++i)
            {
                if (!m_wordDic.ContainsKey(A[i]))
                {
                    MessageBox.Show("发现陌生的单词，关联词出现次数 无法查询！\n" + A.ToString());
                    return 0;
                }

                ia[i] = m_wordDic[A[i]];
            }

            int wdNum = m_db.GetWordNumFromDB(ia, odr);

            return wdNum;
        }

        /*
         * 函数功能：计算概率 P(A) 的对数值 ,通常计算的概率是：P(w1,w2,w3)
         * 参数说明：A，字数组，A={w1,w2,w3...}
         *           odr, 阶数
         * 返回值：P(A)的对数值
         * **/
        public Decimal CalcProb(string[] A,int odr)
        {
            Decimal p = 0;

            if (A == null || A.Length == 0)
            {
                MessageBox.Show("计算概率出错！\n A="+ A.ToString());

                return -10000M;
            }

            if (A.Length > 8 || odr > 8) // 太长了，计算不了
            {
                return -10000M;
            }

            int []ia = new int[A.Length];
            int i = 0;

            for (i = 0; i < A.Length; ++i)
            {
                if (!m_wordDic.ContainsKey(A[i]))
                {
                    MessageBox.Show("发现陌生的单词，概率无法计算！\n" + A.ToString());
                    return -10000M;
                }

                ia[i] = m_wordDic[A[i]];
            }

            string sIndx = ia[0].ToString(); // 索引字符串 

            for (i = 1; i < ia.Length; ++i)
            {
                sIndx += "_" + ia[i].ToString();
            }

            sIndx += "_odr" + odr.ToString();

            if (m_DicProHasCalc.ContainsKey(sIndx))
            {
                return m_DicProHasCalc[sIndx];
            }

            if (m_DicProHasCalc.Count > 1000000)
            {
                m_DicProHasCalc.Clear();
                MessageBox.Show("dic clear!");
            }

            int wdNum = m_db.GetWordNumFromDB(ia, odr);

            if (wdNum == 0)
            {
                p = -10000M; // 很小很小的概率值
            }
            else
            {
                p = (Decimal)Math.Log10((double)(wdNum / m_WordNum[odr - 1]));
            }

            m_DicProHasCalc[sIndx] = p; // 存起来，后面再用

            return p;
        }


        /*
         * 函数功能：把所有序列拼接成字符串 ，用于概率计算结果的索引
         * 参数说明：iArr，索引数组
         * 返回值：拼接的字符串
         * **/

        private string ConnIndexStr(int [] iArr )
        {
            if (iArr == null || iArr.Length == 0)
            {
                return "";
            }

            string sRt = iArr[0].ToString();
            int j = 0;

            for (j = 1; j < iArr.Length; ++j)
            {
                sRt += "_" + iArr[j].ToString();
            }

            return sRt;
        }

        /*
         * 函数功能：对 wip所表示的 A|B 进行条件概率检查
         * 参数说明：wip，代表 A|B
         *           words，原始 字 数组
         *           
         * 返回值：P(B|A) > P(B) ,返回true, 否则 返回 false
         * 
         **/
        public bool CondPorb_is_Valid(WordIndexPair4CondProb wip,string[] words)
        {
            string[] wA = wip.GetWord_1(words);
            string[] wB = wip.GetWord_2(words);

            Decimal pAB_cp = CalcProb(wA,wB);     // P(B|A)
            Decimal pB = CalcProb(wB, wB.Length); // P(B)

            if (pB < -9000)
            {
                //MessageBox.Show("wB 不存在！");
            }

            if (pAB_cp > pB && !(pAB_cp == 0 && (CalcProb(wA, wA.Length) == -10000 || CalcProb(wB, wB.Length) == -10000)))
            {
                if (pB < -9000 && pAB_cp < -9000)
                {
                    return false;
                }

                return true;
            }

            return false;
        }

        public bool H_is_Valid(WordIndexPair4CondProb wip, string[] words)
        {
            string[] A = wip.Get_A_4H(words);
            string[] B = wip.Get_B_4H(words);
            string[] C = wip.Get_C_4H(words);
            string[] D = wip.Get_D_4H(words);

            if (B == null || C == null)
            {
                return false;
            }

            // B 或 C 不可能为空

            if( A == null && D == null)
            {
                return false;// 这种情况无法检查，要返回false，如果是true，表示结合得好，不能拆分（将导致每个refPos都为真）
            }
            else if (A == null && D != null)  // B|CD
            {
                if (CalcH_AB(B, C) > CalcH_AB(C, D))
                {
                    return true;
                }
            }
            else if (A != null && D == null) // AB|C
            {
                if (CalcH_AB(B, C) > CalcH_AB(A, B))
                {
                    return true;
                }
            }
            else if (A != null && D != null) // AB|CD
            {
                if (CalcH_AB(B, C) > Math.Min(CalcH_AB(A, B), CalcH_AB(C, D)))
                {
                    return true;
                }
            }

            /*
            string[] wA = wip.GetWord_1(words);
            string[] wB = wip.GetWord_2(words);

            if (CalcH_AB(wA, wB) > 0)
            {
                return true; // 表明这很有可能是一个词，不能分开。例如 ABC是一个词，会因为 H(A,B) < H(B,C)导致在A、B之间被分开
                             // 返回true，表明这是一个合法的位置
            }*/



            return false;
        }


        private DBConn m_db = null;
        public Dictionary<string, int> m_wordDic;
        public Dictionary<string, Decimal> m_DicProHasCalc;

        public UInt32[] m_WordNums = null;

        Decimal[] m_WordNum = {  0, // 一阶词的计算值
                                 0,  // 二阶词的估算值
                                 0,  // 三阶词的估算值
                                 0,  // 四阶词的估算值
                                 0,  // 五阶词的估算值
                                 0,  // 六阶词的估算值
                                 0,   // 七阶词的估算值
                                 0 }; // 八阶词的估算值，
             
        // 存储 句子数，关联词数      
        //                         wiki       conll2017+ jaist + ner
        int[,] m_stastics = {   {1+1,114051625 + 258430},
                                 {14169993 + 27021 + 5641, 95534193 + 220802},
                                 {11980799 + 22047 + 4732, 81364200 + 188140},
                                 {10311927 + 19097 + 4122, 69383401 + 161361},
                                 {9005608 + 16453 + 3509, 59071474 + 138142},
                                 {7841471 + 14194 + 3053, 50065866 + 118180},
                                 {6827199 + 12293 + 2649, 42224395 + 100933},
                                 {5660224 + 10499 + 2316, 35396000 + 85991} 
                                 // 说明：8阶，10499为conll2017 + jaist的行数，2316为ner的行数，85991为 conll2017 jaist ner的行数
                             };


        // 在 不要在 统一 8阶的句子长度 下（这样做会有很大的问题），对各阶词 进行 的 估算（只有1阶是最准确的）
        
        /*
        public Decimal[] m_WordNum = {  75017451, // 一阶词的计算值
                                 26892549,  // 二阶词的估算值  ,用除以2的方法：19229525
                                 17267569,  // 三阶词的估算值  ,用除以3的方法：13905084
                                 13142577,  // 四阶词的估算值  ,用除以4的方法：11256833
                                 10850915,  // 五阶词的估算值  ,用除以5的方法：9704990
                                 9392585,  // 六阶词的估算值   ,用除以6的方法：8724315
                                 8382972,   // 七阶词的估算值  ,用除以7的方法：8045712
                                 7642589 }; // 八阶词的估算值，,用除以8的方法：7553068
         * */

        
    }
}
