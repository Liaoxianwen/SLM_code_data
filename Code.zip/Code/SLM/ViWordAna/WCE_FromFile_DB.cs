﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ViWordAna
{
    /*
     *  类说明：用于记录一个"连续"句子 在 一个 单字 序列中的 起始，终止 位置
     *          起始位置有效，终止位置是序列结束的下一个位置。
     *          也就是该区间是一个半开闭区间[st,ed)
     * 
     * **/
    public class SentsIndex
    {
        public SentsIndex( int st,int ed)
        {
            m_st = st;
            m_ed = ed;
        }
        public int m_st = 0; // 起始位置，包含
        public int m_ed = 0; // 终止位置，不包含
    }


    /*
     * 类的说明：保存 句子 和 词 的数量， 相当于结构体，当返回值用
     * 
     */
    public class WordSentenceNumPair
    {
        public WordSentenceNumPair() { }

        public int m_SentenceNum = 0;   // 句子的数量
        public int m_NGramWordNum = 0;  // 词的数量（与邻接词的计算不同），例如   w1 w2 w3| w4 w5 w6|w7 w8 w9 ,这样的分词法词的个数
    }

    public class WCE_FromFile_DB
    {
        /*
         * 函数功能：构造函数，初始化2阶关联矩阵，加载越南语词典列表
         * 
         * **/

        public WCE_FromFile_DB()
        {

            m_WordDic2 = new Dictionary<string, int>();

            m_WordNums          = new UInt32[10000];
            m_WordNumsCondition = new UInt32[10000];

            StreamReader sr = new StreamReader("ViWord最新.txt");
            string[] sp = { ":", "," };
            int i = 0;

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();

                string[] sA = s.Split(sp,StringSplitOptions.RemoveEmptyEntries);

                m_WordNums[i] = Convert.ToUInt32(sA[2]);

                i++;

                string sWord = sA[0].Trim();

                m_WordDic2[sWord] = -1;  // 相当于把这个字添加到字典中去，但是字的下标还没添加

                m_WordDic2[sWord] = m_WordDic2.Count - 1; // 数组的下标，方便再关联矩阵中进行索引

            }

            sr.Close();
            sr.Dispose();

            int j = 0;

            //m_A = new UInt32[m_WordDic2.Count, m_WordDic2.Count]; 已经不用了 
            m_A = new UInt32[123, 321]; // 定义一下，要不然出错


        }

        /*
         * 函数功能：从之前保存的 字 2 阶关联矩阵中读取关联数据 
         * 参数说明：ViWordCoExist.txt，二阶关联矩阵 文件
         * 返回值：无
         */

        public void ReadWordCoExistArr()
        {
            StreamReader sr = new StreamReader("ViWordCoExist.txt",Encoding.ASCII);
            int i = 0;
            int j = 0;
            string []sp={","};

            try
            {
                for (i = 0; i < m_WordDic2.Count; ++i)
                {
                    string str = sr.ReadLine();
                    string[] snum = str.Split(sp, StringSplitOptions.RemoveEmptyEntries);

                    for (j = 0; j < m_WordDic2.Count; ++j)
                    {
                        m_A[i, j] = Convert.ToUInt32(snum[j].Trim());
                    }
                }
            }
            catch
            {
                MessageBox.Show("读取 字 一阶关联矩阵时 出错！！");
            }

            UInt32 cnt = 0;

            for (i = 0; i < m_WordDic2.Count;++i )
            {
                for (j = 0; j < m_WordDic2.Count; ++j)
                {
                    m_totalWord_2          += m_A[i, j]; // 2阶关联词出现的次数
                    m_WordNumsCondition[i] += m_A[i, j];

                    if (m_A[i, j] > 0) cnt++;
                }
            }

            for (i = 0; i < m_WordDic2.Count; ++i)
            {
                m_totalWord          += m_WordNums[i];
                m_totalWordCondition += m_WordNumsCondition[i];
            }

            sr.Close();
            sr.Dispose();
        }

        /*
         * 函数功能：构建1阶关联矩阵，把矩阵 写到数据库中去，不再保存成文件
         * 参数说明：FilePathNames，文件数组名
         * 返回值:无
         */

        public void Make_1_CoExist(string[] FilePathNames)
        {
            int i = 0;
            DBConn dbc = new DBConn();               // 数据库连接
            List<string> LSql = new List<string>();  // 批量执行的 sql 语句
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;

            WordSentenceNumPair wsn = new WordSentenceNumPair();

            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t = Add_1_CoWords_2DB(words, str, dbc, LSql); // 添加到前后关联矩阵当中去

                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            // 把 单词的前后 关联 矩阵 保存起来 

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

            StreamWriter sw = new StreamWriter("sentence_1_.txt", false);
            sw.WriteLine("分句的数量：" + wsn.m_SentenceNum.ToString());
            sw.WriteLine("1元词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            return;
        }


        /*
         * 函数功能：构建二阶关联矩阵，把矩阵 写到数据库中去，不再保存成文件
         * 参数说明：FilePathNames，文件数组名
         * 返回值:无
         */

        public void Make_2_CoExist(string[] FilePathNames)
        {
            int i = 0;
            DBConn dbc = new DBConn();               // 数据库连接
            List<string> LSql = new List<string>();  // 批量执行的 sql 语句
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;

            WordSentenceNumPair wsn = new WordSentenceNumPair();

            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t= Add_2_CoWords_2DB(words, str, dbc, LSql); // 添加到前后关联矩阵当中去

                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            // 把 单词的前后 关联 矩阵 保存起来 

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

            StreamWriter sw = new StreamWriter("sentence_2_.txt", false);
            sw.WriteLine("分句的数量："+wsn.m_SentenceNum.ToString());
            sw.WriteLine("2元词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            return;
        }

        /*
         * 函数功能：对输入的文件序列生成3阶关联词
         * 参数说明：FilePathNames，文件名列表
         * 
         * 返回值：无 
         */
        public void Make_3_CoExist(string[] FilePathNames)
        {
            int i = 0;

            DBConn dbc = new DBConn();
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;
            List<string> LSql = new List<string>();

            WordSentenceNumPair wsn = new WordSentenceNumPair();

            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t= Add_3_CoWords_2DB(words, str, dbc,LSql); // 写到数据库
                    
                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

            StreamWriter sw = new StreamWriter("sentence_3_.txt", false);

            sw.WriteLine("分句的数量 ："+ wsn.m_SentenceNum.ToString() );
            sw.WriteLine("3阶词的数量："+ wsn.m_NGramWordNum.ToString());

            sw.Close();
            sw.Dispose();

            return;
        }

        /*
         * 函数功能：对输入的文件序列生成4阶关联词
         * 参数说明：FilePathNames，文件名列表
         * 
         * 返回值：无 
         */
        public void Make_4_CoExist(string[] FilePathNames)
        {
            int i = 0;

            DBConn dbc = new DBConn();
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;
            List<string> LSql = new List<string>();

            WordSentenceNumPair wsn = new WordSentenceNumPair();


            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t= Add_4_CoWords_2DB(words, str, dbc, LSql); // 写到数据库
                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

            StreamWriter sw = new StreamWriter("sentence_4_.txt", false);
            sw.WriteLine("分句的数量 ：" + wsn.m_SentenceNum.ToString());
            sw.WriteLine("4阶词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            MessageBox.Show("4阶词写入数据库完成！");

            return;
        }

        /*
         * 函数功能：对输入的文件序列生成5阶关联词
         * 参数说明：FilePathNames，文件名列表
         * 
         * 返回值：无 
         */
        public void Make_5_CoExist(string[] FilePathNames)
        {
            int i = 0;

            DBConn dbc = new DBConn();
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;
            List<string> LSql = new List<string>();

            WordSentenceNumPair wsn = new WordSentenceNumPair();


            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t = Add_5_CoWords_2DB(words, str, dbc, LSql,i); // 写到数据库
                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            try
            {

                dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库
            }
            catch (SystemException e1)
            {
                MessageBox.Show("最后写入剩余 sql 的时候出错\n" + e1.ToString());
            }

            StreamWriter sw = new StreamWriter("sentence_5_.txt", false);
            sw.WriteLine("分句的数量：" + wsn.m_SentenceNum.ToString());
            sw.WriteLine("5阶词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            MessageBox.Show("5阶词写入数据库完成！");

            return;
        }

        /*
         * 函数功能：对输入的文件序列生成5阶关联词
         * 参数说明：FilePathNames，文件名列表
         * 
         * 返回值：无 
         */
        public void Make_6_CoExist(string[] FilePathNames)
        {
            int i = 0;

            DBConn dbc = new DBConn();
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;
            List<string> LSql = new List<string>();

            WordSentenceNumPair wsn = new WordSentenceNumPair();


            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t = Add_6_CoWords_2DB(words, str, dbc, LSql); // 写到数据库
                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

            StreamWriter sw = new StreamWriter("sentence_6_.txt", false);
            sw.WriteLine("分句的数量：" + wsn.m_SentenceNum.ToString());
            sw.WriteLine("6阶词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            MessageBox.Show("6阶词写入数据库完成！");

            return;
        }

        /*
         * 函数功能：对输入的文件序列生成5阶关联词
         * 参数说明：FilePathNames，文件名列表
         * 
         * 返回值：无 
         */
        public void Make_7_CoExist(string[] FilePathNames)
        {
            int i = 0;

            DBConn dbc = new DBConn();
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;
            List<string> LSql = new List<string>();

            WordSentenceNumPair wsn = new WordSentenceNumPair();


            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t = Add_7_CoWords_2DB(words, str, dbc, LSql); // 写到数据库
                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

            StreamWriter sw = new StreamWriter("sentence_7_.txt", false);
            sw.WriteLine("分句的数量：" + wsn.m_SentenceNum.ToString());
            sw.WriteLine("7阶词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            MessageBox.Show("7阶词写入数据库完成！");

            return;
        }

        /*
         * 函数功能：可以 把 1 到 8 阶 关联词写入到数据库中
         * 参数说明：FilePathNames，文件名列表
         * 
         * 返回值：无 
         */
        public void Make_8_CoExist(string[] FilePathNames)
        {
            int i = 0;

            DBConn dbc = new DBConn();
            string[] words = null;
            wordSeg ws = new wordSeg();
            string str = null;
            List<string> LSql = new List<string>();

            WordSentenceNumPair wsn = new WordSentenceNumPair();


            for (i = 0; i < FilePathNames.Length; ++i)
            {
                StreamReader sr = new StreamReader(FilePathNames[i]);

                while (!sr.EndOfStream)
                {
                    str = sr.ReadLine();

                    if (wordCoExist_O2.isSegmentLine(str))
                    {
                        continue;
                    }

                    words = ws.dowordSeg(str); // 分词

                    WordSentenceNumPair t = Add_8_CoWords_2DB(words, str, dbc, LSql); // 把 str 变成 小写，再处理写到数据库
                    wsn.m_SentenceNum += t.m_SentenceNum;
                    wsn.m_NGramWordNum += t.m_NGramWordNum;
                }

                sr.Close();
                sr.Dispose();
            }

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库

           // dbc.WriteWCO2DB(m_LSqlCommUse);

            StreamWriter sw = new StreamWriter("sentence_8_.txt", false);
            sw.WriteLine("分句的数量：" + wsn.m_SentenceNum.ToString());
            sw.WriteLine("8阶词的数量：" + wsn.m_NGramWordNum.ToString());
            sw.Close();
            sw.Dispose();

            MessageBox.Show("8阶词写入数据库完成！");

            return;
        }

        /*
         * 函数功能：把单词前后 一阶关联 写到文件中去
         * 参数说明：无
         * 返回值：无 
         */

        private void SaveCoExistArr()
        {
            StreamWriter sw = new StreamWriter("ViWordCoExist.txt",false,Encoding.ASCII);
            int i = 0;
            int j = 0;
            string sline = "";

            for (i = 0; i < m_WordDic2.Count; ++i)
            {
                sline = "";
                for (j = 0; j < m_WordDic2.Count; ++j)
                {
                    // 按 行 来 写
                    //sw.WriteLine(m_A[i,j].ToString());
                    sline += m_A[i, j].ToString() + ",";
                }

                sw.WriteLine( sline );
            }

            sw.Close();
            sw.Dispose();
        }

        /*
        * 函数功能：把越南语文本中单个单词 写到 1 阶关联矩阵中去 
        * 参数说明：Words,一行文本拆分所得的 字 数组
        *          sL，被拆分的字符串，判断两个单字之间是否有分隔符隔开时用到，在这个函数中它将被转换为小写；
        *          dbc，数据库连接
        *          LSql，sql 语句容器。
        *          
        * 返回值： 无
        */

        public WordSentenceNumPair Add_1_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 1)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            int NumOfSentences = 0;
            int TotalWords = 0;
            int id1 = 0;

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写


            for (i = 0; i < Words.Length; ++i)
            {
                word1 = Words[i];    // 第一个单词

                if (m_WordDic2.ContainsKey(word1))
                {
                    id1 = m_WordDic2[word1];
                    AddSqlStatement_1(LSql, id1, "tb_coll2017_jaist_ner_all_1");

                    if (LSql.Count == 3000)
                    {
                        dbc.WriteWCO2DB(LSql);
                        LSql.Clear();
                    }

                }
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;
        }


        /*
         * 函数功能：把越南语文本中两个相连的单词 写到二阶关联矩阵中去 
         * 参数说明：Words,一行文本拆分所得的 字 数组
         *          sL，被拆分的字符串，判断两个单字之间是否有分隔符隔开时用到，在这个函数中它将被转换为小写；
         *          dbc，数据库连接
         *          LSql，sql 语句容器。
         *          
         * 返回值： 无
         */

        public WordSentenceNumPair Add_2_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 2)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;

            int NumOfSentences = 0; 
            int TotalWords = 0;    
            int tmpNum = 0;

            int indx0 = 0; // 字数组中 字的下标，起始下标
            int indx1 = 0; // 字数组中 字的下标，终止下标

            int i_1th = 0;
            int i_2th = 0;

            int id1 = 0;
            int id2 = 0;

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            indx0 = 0; // 句子片段从0开始

            for (i = 0; i < Words.Length - 1; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词

                indx1 = i + 1;       // 后一个单词的下标

                i_1th = sL.IndexOf(word1, i_1th);                 // 第一个单词在原始串中的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);  // 第二个单词在原始串中的起始位置

                // 是相邻的两个单词之间 是否有句子边界 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                {   // 无句子分界
                    if (m_WordDic2.ContainsKey(word1) && // 字典中又同时存在两个单词，则两个单词的关联 +1
                        m_WordDic2.ContainsKey(word2))
                    {
                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];

                        AddSqlStatement_2(LSql, id1, id2, "tb_coll2017_jaist_ner_all_2");
                        tmpNum++;// n元邻接词+1

                        if (LSql.Count == 5000)
                        {
                            dbc.WriteWCO2DB(LSql);
                            LSql.Clear();
                        }
                    }
                    else
                    {
                        if (!m_WordDic2.ContainsKey(word2))
                        {
                                                     // 在字典中不存在的单字，也算是 句子的边界
                            if (indx1 - indx0 >= 2)  //为什么是2，考虑一个分句只有2个单字，其中一个为陌生字，则要忽略这个句子
                            {
                                NumOfSentences++;    // 句子片段 + 1
                                TotalWords += (tmpNum + 1) / 2; // 把当前句中词的数量加到 总数中。
                                tmpNum = 0; // 清零
                            }
                            indx0 = indx1 + 1;       // 最后一个字的下一个
                        }
                        else if (!m_WordDic2.ContainsKey(word1)) // 这个判断是必要的，因为句子的第一个单词 就是 陌生单词。
                        {
                            indx0 = i + 1;           // 当前字的下一个
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句
                {
                    if (indx1 - indx0 >= 2)
                    {
                        NumOfSentences++; // 句子片段 + 1
                        TotalWords += (tmpNum + 1) / 2; // 把当前句中词的数量加到 总数中。
                        tmpNum = 0; // 清零
                    }
                    indx0 = indx1;
                }

                i_1th += word1.Length; // 起始 往前移动第一个单词的长度
            }

            if (indx1 - indx0 >= 1) // 最后一个条件和前面的条件不一样，>= 1 即可
            {
                NumOfSentences++; // 句子片段 + 1
                TotalWords += (tmpNum + 1) / 2; // 把当前句中词的数量加到 总数中。
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;

        }

        /*
         * 函数功能：把 3阶关联词 写到数据库中
         * 参数说明：Words，字序列
         *          sL，原字符串
         *          dbc,数据库连接
         *     
         * 返回值：无
         */

        public WordSentenceNumPair Add_3_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 3)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;
            string word3 = null;

            int NumOfSentences = 0;
            int TotalWords = 0;
            int tmpNum = 0;

            int i_1th  = 0; 
            int i_2th  = 0;
            int i_3th  = 0;

            int id1 = 0;
            int id2 = 0;
            int id3 = 0;

            int index0 = 0;
            int index2 = 0;

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            index0 = 0;
            for (i = 0; i < Words.Length - 2; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词
                word3 = Words[i + 2];// 第三个单词

                index2 = i + 2;

                i_1th = sL.IndexOf(word1, i_1th);               // 第一个单词的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);// 第二个单词的起始位置
                i_3th = sL.IndexOf(word3, i_2th + word2.Length);// 第三个单词的起始位置

                // 是相邻的两个 单词 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL) && 
                    isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                {
                    if (m_WordDic2.ContainsKey(word1) && 
                        m_WordDic2.ContainsKey(word2) && 
                        m_WordDic2.ContainsKey(word3))
                    {// 字典中同时存在3个单词

                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];
                        id3 = m_WordDic2[word3];
                        AddSqlStatement_3(LSql, id1, id2, id3, "tb_coll2017_jaist_ner_all_3");
                        tmpNum++;

                        if (LSql.Count == 5000)
                        {
                            dbc.WriteWCO2DB(LSql);
                            LSql.Clear();
                        }
                    }
                    else
                    {
                        if (!m_WordDic2.ContainsKey(word3))
                        {
                            if (index2 - index0 >= 3)
                            {
                                NumOfSentences++;
                                TotalWords += (tmpNum + 2) / 3; // 把当前句中词的数量加到 总数中。
                                tmpNum = 0; // 清零
                            }
                            index0 = index2 + 1;
                        }
                        else if (!m_WordDic2.ContainsKey(word2))
                        {
                            index0 = i + 2;
                        }
                        else if (!m_WordDic2.ContainsKey(word1))
                        {
                            index0 = i + 1;
                        }
                        else
                        {
                            // 不可能到这
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句
                {
                    if (!isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                    {// 2-3单词之间存在句子边界
                        if (index2 - index0 >= 3)
                        {
                            NumOfSentences++;
                            TotalWords += (tmpNum + 2) / 3; // 把当前句中词的数量加到 总数中。
                            tmpNum = 0; // 清零
                        }
                        
                        index0 = index2;
                    }
                    else if (!isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                    {// 1-2单词之间存在句子边界
                        index0 = i + 1;
                    }
                    else
                    {
                        // 不可能到这
                    }

                }

                i_1th += word1.Length; // 往前移动第一个单词的长度
            }

            if (index2 - index0 >= 2)
            {
                NumOfSentences++;
                TotalWords += (tmpNum + 2) / 3; // 把当前句中词的数量加到 总数中。
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;
        }

        /*
         * 函数功能：把 4阶关联词 写到数据库中
         * 参数说明：Words，字序列
         *          sL，原字符串
         *          dbc,数据库连接
         *     
         * 返回值：无
         */

        public WordSentenceNumPair Add_4_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 4)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;
            string word3 = null;
            string word4 = null;

            int NumOfSentences = 0;
            int TotalWords = 0;
            int tmpNum = 0;

            int i_1th = 0;
            int i_2th = 0;
            int i_3th = 0;
            int i_4th = 0;

            int id1 = 0;
            int id2 = 0;
            int id3 = 0;
            int id4 = 0;

            int index0 = 0;//单词0的下标
            int index3 = 0;//单词3的下标

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            index0 = 0;
            for (i = 0; i < Words.Length - 3; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词
                word3 = Words[i + 2];// 第三个单词
                word4 = Words[i + 3];// 第三个单词

                index3 = i + 3;

                i_1th = sL.IndexOf(word1, i_1th);               // 第一个单词的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);// 第二个单词的起始位置
                i_3th = sL.IndexOf(word3, i_2th + word2.Length);// 第三个单词的起始位置
                i_4th = sL.IndexOf(word4, i_3th + word3.Length);// 第四个单词的起始位置

                // 是相邻的两个 单词 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL) && 
                    isViWordConjunction(i_2th + word2.Length, i_3th, sL) &&
                    isViWordConjunction(i_3th + word3.Length, i_4th, sL) )
                {
                    if (m_WordDic2.ContainsKey(word1) && 
                        m_WordDic2.ContainsKey(word2) && 
                        m_WordDic2.ContainsKey(word3) &&
                        m_WordDic2.ContainsKey(word4))
                    {// 字典中同时存在4个单词
                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];
                        id3 = m_WordDic2[word3];
                        id4 = m_WordDic2[word4];

                        AddSqlStatement_4(LSql, id1, id2, id3, id4, "tb_coll2017_jaist_ner_all_4");
                        tmpNum++;

                        if (LSql.Count == 1000)
                        {
                            dbc.WriteWCO2DB(LSql);// 公共的写入功能，无所谓几阶
                            LSql.Clear();
                        }
                    }
                    else
                    {
                        if (!m_WordDic2.ContainsKey(word4))
                        {//不包含第四个单字
                            if (index3 - index0 >= 4)
                            {
                                NumOfSentences++;
                                TotalWords += (tmpNum + 3) / 4; // 把当前句中词的数量加到 总数中。
                                tmpNum = 0; // 清零
                            }
                            index0 = index3 + 1; // 从不被包含的下一个字开始
                        }
                        else if (!m_WordDic2.ContainsKey(word3))
                        {
                            index0 = i + 3;
                        }
                        else if (!m_WordDic2.ContainsKey(word2))
                        {
                            index0 = i + 2;
                        }
                        else if (!m_WordDic2.ContainsKey(word1))
                        {
                            index0 = i + 1;
                        }
                        else
                        {
                            // 不可能到这
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句
                {
                    if (!isViWordConjunction(i_3th + word3.Length, i_4th, sL))
                    {// 3-4单词之间存在句子边界
                        if (index3 - index0 >= 4)
                        {
                            NumOfSentences++;
                            TotalWords += (tmpNum + 3) / 4; // 把当前句中词的数量加到 总数中。
                            tmpNum = 0; // 清零
                        }

                        index0 = index3;//单词4作为起始
                    }
                    else if (!isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                    {// 2-3单词之间存在句子边界
                        index0 = i + 2;
                    }
                    else if (!isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                    {// 1-2单词之间存在句子边界
                        index0 = i + 1;
                    }
                    else
                    {
                        // 不可能到这
                    }

                }

                i_1th += word1.Length; // 往前移动第一个单词的长度
            }

            if (index3 - index0 >= 3)
            {
                NumOfSentences++;
                TotalWords += (tmpNum + 3) / 4; // 把当前句中词的数量加到 总数中。
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;
        }

        /*
         * 函数功能：把 5阶关联词 写到数据库中
         * 参数说明：Words，字序列
         *          sL，原字符串
         *          dbc,数据库连接
         *     
         * 返回值：无
         */

        public WordSentenceNumPair Add_5_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql,int iFils)
        {
            int i = 0;

            if (Words.Length < 5)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;
            string word3 = null;
            string word4 = null;
            string word5 = null;

            int NumOfSentences = 0;
            int TotalWords = 0;
            int tmpNum = 0;

            int i_1th = 0;
            int i_2th = 0;
            int i_3th = 0;
            int i_4th = 0;
            int i_5th = 0;

            int id1 = 0;
            int id2 = 0;
            int id3 = 0;
            int id4 = 0;
            int id5 = 0;

            int index0 = 0;//单词0的下标
            int index4 = 0;//单词4的下标

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            index0 = 0;
            for (i = 0; i < Words.Length - 4; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词
                word3 = Words[i + 2];// 第三个单词
                word4 = Words[i + 3];// 第四个单词
                word5 = Words[i + 4];// 第四个单词

                index4 = i + 4;

                i_1th = sL.IndexOf(word1, i_1th);               // 第一个单词的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);// 第二个单词的起始位置
                i_3th = sL.IndexOf(word3, i_2th + word2.Length);// 第三个单词的起始位置
                i_4th = sL.IndexOf(word4, i_3th + word3.Length);// 第四个单词的起始位置
                i_5th = sL.IndexOf(word5, i_4th + word4.Length);// 第五个单词的起始位置

                // 是相邻的两个 单词 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL) &&
                    isViWordConjunction(i_2th + word2.Length, i_3th, sL) &&
                    isViWordConjunction(i_3th + word3.Length, i_4th, sL) &&
                    isViWordConjunction(i_4th + word4.Length, i_5th, sL)
                    )
                {
                    if (m_WordDic2.ContainsKey(word1) &&
                        m_WordDic2.ContainsKey(word2) &&
                        m_WordDic2.ContainsKey(word3) &&
                        m_WordDic2.ContainsKey(word4) &&
                        m_WordDic2.ContainsKey(word5))
                    {// 字典中同时存在4个单词
                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];
                        id3 = m_WordDic2[word3];
                        id4 = m_WordDic2[word4];
                        id5 = m_WordDic2[word5];

                        AddSqlStatement_5(LSql, id1, id2, id3, id4, id5, "tb_coll2017_jaist_ner_all_5");
                        tmpNum++;

                        if (LSql.Count == 5000)
                        {
                            //if (iFils > 8) // 测试用
                            
                            dbc.WriteWCO2DB(LSql);// 公共的写入功能，无所谓几阶
                            
                            LSql.Clear();
                        }
                    }
                    else
                    {
                        if (!m_WordDic2.ContainsKey(word5))
                        {//不包含第四个单字
                            if (index4 - index0 >= 5)
                            {
                                NumOfSentences++;
                                TotalWords += (tmpNum + 4) / 5; // 把当前句中词的数量加到 总数中。
                                tmpNum = 0; // 清零
                            }
                            index0 = index4 + 1; // 从不被包含的下一个字开始
                        }
                        else if (!m_WordDic2.ContainsKey(word4))
                        {
                            index0 = i + 4;
                        }
                        else if (!m_WordDic2.ContainsKey(word3))
                        {
                            index0 = i + 3;
                        }
                        else if (!m_WordDic2.ContainsKey(word2))
                        {
                            index0 = i + 2;
                        }
                        else if (!m_WordDic2.ContainsKey(word1))
                        {
                            index0 = i + 1;
                        }
                        else
                        {
                            // 不可能到这
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句
                {
                    if (!isViWordConjunction(i_4th + word4.Length, i_5th, sL))
                    {// 3-4单词之间存在句子边界
                        if (index4 - index0 >= 5)
                        {
                            NumOfSentences++;
                            TotalWords += (tmpNum + 4) / 5; // 把当前句中词的数量加到 总数中。
                            tmpNum = 0; // 清零
                        }

                        index0 = index4;//单词4作为起始
                    }
                    else if (!isViWordConjunction(i_3th + word3.Length, i_4th, sL))
                    {
                        index0 = i + 3;
                    }
                    else if (!isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                    {// 2-3单词之间存在句子边界
                        index0 = i + 2;
                    }
                    else if (!isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                    {// 1-2单词之间存在句子边界
                        index0 = i + 1;
                    }
                    else
                    {
                        // 不可能到这
                    }

                }

                i_1th += word1.Length; // 往前移动第一个单词的长度
            }

            if (index4 - index0 >= 4)
            {
                NumOfSentences++;
                TotalWords += (tmpNum + 4) / 5; // 把当前句中词的数量加到 总数中。
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;
        }

        /*
         * 函数功能：把 6阶关联词 写到数据库中
         * 参数说明：Words，字序列
         *          sL，原字符串
         *          dbc,数据库连接
         *     
         * 返回值：无
         */

        public WordSentenceNumPair Add_6_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 6)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;
            string word3 = null;
            string word4 = null;
            string word5 = null;
            string word6 = null;

            int NumOfSentences = 0;
            int TotalWords = 0;
            int tmpNum = 0;

            int i_1th = 0;
            int i_2th = 0;
            int i_3th = 0;
            int i_4th = 0;
            int i_5th = 0;
            int i_6th = 0;

            int id1 = 0;
            int id2 = 0;
            int id3 = 0;
            int id4 = 0;
            int id5 = 0;
            int id6 = 0;

            int index0 = 0;//单词0的下标
            int index5 = 0;//单词5的下标

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            index0 = 0;
            for (i = 0; i < Words.Length - 5; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词
                word3 = Words[i + 2];// 第三个单词
                word4 = Words[i + 3];// 第四个单词
                word5 = Words[i + 4];// 第五个单词
                word6 = Words[i + 5];// 第六个单词

                index5 = i + 5;

                i_1th = sL.IndexOf(word1, i_1th);               // 第一个单词的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);// 第二个单词的起始位置
                i_3th = sL.IndexOf(word3, i_2th + word2.Length);// 第三个单词的起始位置
                i_4th = sL.IndexOf(word4, i_3th + word3.Length);// 第四个单词的起始位置
                i_5th = sL.IndexOf(word5, i_4th + word4.Length);// 第五个单词的起始位置
                i_6th = sL.IndexOf(word6, i_5th + word5.Length);// 第六个单词的起始位置

                // 是相邻的两个 单词 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL) &&
                    isViWordConjunction(i_2th + word2.Length, i_3th, sL) &&
                    isViWordConjunction(i_3th + word3.Length, i_4th, sL) &&
                    isViWordConjunction(i_4th + word4.Length, i_5th, sL) &&
                    isViWordConjunction(i_5th + word5.Length, i_6th, sL))
                {
                    if (m_WordDic2.ContainsKey(word1) &&
                        m_WordDic2.ContainsKey(word2) &&
                        m_WordDic2.ContainsKey(word3) &&
                        m_WordDic2.ContainsKey(word4) &&
                        m_WordDic2.ContainsKey(word5) &&
                        m_WordDic2.ContainsKey(word6))
                    {// 字典中同时存在4个单词
                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];
                        id3 = m_WordDic2[word3];
                        id4 = m_WordDic2[word4];
                        id5 = m_WordDic2[word5];
                        id6 = m_WordDic2[word6];

                        AddSqlStatement_6(LSql, id1, id2, id3, id4, id5, id6, "tb_coll2017_jaist_ner_all_6");
                        tmpNum++;

                        if (LSql.Count == 5000)
                        {
                            dbc.WriteWCO2DB(LSql);// 公共的写入功能，无所谓几阶
                            LSql.Clear();
                        }
                    }
                    else
                    {
                        if (!m_WordDic2.ContainsKey(word6))
                        {//不包含第四个单字
                            if (index5 - index0 >= 6)
                            {
                                NumOfSentences++;
                                TotalWords += (tmpNum + 5) / 6; // 把当前句中词的数量加到 总数中。
                                tmpNum = 0; // 清零
                            }
                            index0 = index5 + 1; // 从不被包含的下一个字开始
                        }
                        else if (!m_WordDic2.ContainsKey(word5))
                        {
                            index0 = i + 5;
                        }
                        else if (!m_WordDic2.ContainsKey(word4))
                        {
                            index0 = i + 4;
                        }
                        else if (!m_WordDic2.ContainsKey(word3))
                        {
                            index0 = i + 3;
                        }
                        else if (!m_WordDic2.ContainsKey(word2))
                        {
                            index0 = i + 2;
                        }
                        else if (!m_WordDic2.ContainsKey(word1))
                        {
                            index0 = i + 1;
                        }
                        else
                        {
                            // 不可能到这
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句
                {
                    if (!isViWordConjunction(i_5th + word5.Length, i_6th, sL))
                    {// 3-4单词之间存在句子边界
                        if (index5 - index0 >= 6)
                        {
                            NumOfSentences++;
                            TotalWords += (tmpNum + 5) / 6; // 把当前句中词的数量加到 总数中。
                            tmpNum = 0; // 清零
                        }

                        index0 = index5;//单词4作为起始
                    }
                    else if (!isViWordConjunction(i_4th + word4.Length, i_5th, sL))
                    {
                        index0 = i + 4;
                    }
                    else if (!isViWordConjunction(i_3th + word3.Length, i_4th, sL))
                    {
                        index0 = i + 3;
                    }
                    else if (!isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                    {// 2-3单词之间存在句子边界
                        index0 = i + 2;
                    }
                    else if (!isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                    {// 1-2单词之间存在句子边界
                        index0 = i + 1;
                    }
                    else
                    {
                        // 不可能到这
                    }

                }

                i_1th += word1.Length; // 往前移动第一个单词的长度
            }

            if (index5 - index0 >= 5)
            {
                NumOfSentences++;
                TotalWords += (tmpNum + 5) / 6; // 把当前句中词的数量加到 总数中。
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;
        }


        /*
         * 函数功能：把 7阶关联词 写到数据库中
         * 参数说明：Words，字序列
         *          sL，原字符串
         *          dbc,数据库连接
         *     
         * 返回值：无
         */

        public WordSentenceNumPair Add_7_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 7)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;
            string word3 = null;
            string word4 = null;
            string word5 = null;
            string word6 = null;
            string word7 = null;

            int NumOfSentences = 0;
            int TotalWords = 0;
            int tmpNum = 0;

            int i_1th = 0;
            int i_2th = 0;
            int i_3th = 0;
            int i_4th = 0;
            int i_5th = 0;
            int i_6th = 0;
            int i_7th = 0;

            int id1 = 0;
            int id2 = 0;
            int id3 = 0;
            int id4 = 0;
            int id5 = 0;
            int id6 = 0;
            int id7 = 0;

            int index0 = 0;//单词0的下标
            int index6 = 0;//单词5的下标

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            index0 = 0;
            for (i = 0; i < Words.Length - 6; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词
                word3 = Words[i + 2];// 第三个单词
                word4 = Words[i + 3];// 第四个单词
                word5 = Words[i + 4];// 第五个单词
                word6 = Words[i + 5];// 第六个单词
                word7 = Words[i + 6];// 第七个单词

                index6 = i + 6;

                i_1th = sL.IndexOf(word1, i_1th);               // 第一个单词的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);// 第二个单词的起始位置
                i_3th = sL.IndexOf(word3, i_2th + word2.Length);// 第三个单词的起始位置
                i_4th = sL.IndexOf(word4, i_3th + word3.Length);// 第四个单词的起始位置
                i_5th = sL.IndexOf(word5, i_4th + word4.Length);// 第五个单词的起始位置
                i_6th = sL.IndexOf(word6, i_5th + word5.Length);// 第六个单词的起始位置
                i_7th = sL.IndexOf(word7, i_6th + word6.Length);// 第七个单词的起始位置

                // 是相邻的两个 单词 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL) &&
                    isViWordConjunction(i_2th + word2.Length, i_3th, sL) &&
                    isViWordConjunction(i_3th + word3.Length, i_4th, sL) &&
                    isViWordConjunction(i_4th + word4.Length, i_5th, sL) &&
                    isViWordConjunction(i_5th + word5.Length, i_6th, sL) &&
                    isViWordConjunction(i_6th + word6.Length, i_7th, sL))
                {
                    if (m_WordDic2.ContainsKey(word1) &&
                        m_WordDic2.ContainsKey(word2) &&
                        m_WordDic2.ContainsKey(word3) &&
                        m_WordDic2.ContainsKey(word4) &&
                        m_WordDic2.ContainsKey(word5) &&
                        m_WordDic2.ContainsKey(word6) &&
                        m_WordDic2.ContainsKey(word7))
                    {// 字典中同时存在4个单词
                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];
                        id3 = m_WordDic2[word3];
                        id4 = m_WordDic2[word4];
                        id5 = m_WordDic2[word5];
                        id6 = m_WordDic2[word6];
                        id7 = m_WordDic2[word7];


                        AddSqlStatement_7(LSql, id1, id2, id3, id4, id5, id6, id7, "tb_coll2017_jaist_ner_all_7");
                        tmpNum++;

                        if (LSql.Count == 5000)
                        {
                            dbc.WriteWCO2DB(LSql);// 公共的写入功能，无所谓几阶
                            LSql.Clear();
                        }
                    }
                    else
                    {
                        if (!m_WordDic2.ContainsKey(word7))
                        {//不包含第7个单字
                            if (index6 - index0 >= 7)
                            {
                                NumOfSentences++;
                                TotalWords += (tmpNum + 6) / 7; // 把当前句中词的数量加到 总数中。
                                tmpNum = 0; // 清零
                            }
                            index0 = index6 + 1; // 从不被包含的下一个字开始
                        }
                        else if (!m_WordDic2.ContainsKey(word6))
                        {
                            index0 = i + 6;
                        }
                        else if (!m_WordDic2.ContainsKey(word5))
                        {
                            index0 = i + 5;
                        }
                        else if (!m_WordDic2.ContainsKey(word4))
                        {
                            index0 = i + 4;
                        }
                        else if (!m_WordDic2.ContainsKey(word3))
                        {
                            index0 = i + 3;
                        }
                        else if (!m_WordDic2.ContainsKey(word2))
                        {
                            index0 = i + 2;
                        }
                        else if (!m_WordDic2.ContainsKey(word1))
                        {
                            index0 = i + 1;
                        }
                        else
                        {
                            // 不可能到这
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句
                {
                    if (!isViWordConjunction(i_6th + word6.Length, i_7th, sL))
                    {// 3-4单词之间存在句子边界
                        if (index6 - index0 >= 7)
                        {
                            NumOfSentences++;
                            TotalWords += (tmpNum + 6) / 7; // 把当前句中词的数量加到 总数中。
                            tmpNum = 0; // 清零
                        }

                        index0 = index6;//单词4作为起始
                    }
                    else if (!isViWordConjunction(i_5th + word5.Length, i_6th, sL))
                    {
                        index0 = i + 5;
                    }
                    else if (!isViWordConjunction(i_4th + word4.Length, i_5th, sL))
                    {
                        index0 = i + 4;
                    }
                    else if (!isViWordConjunction(i_3th + word3.Length, i_4th, sL))
                    {
                        index0 = i + 3;
                    }
                    else if (!isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                    {// 2-3单词之间存在句子边界
                        index0 = i + 2;
                    }
                    else if (!isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                    {// 1-2单词之间存在句子边界
                        index0 = i + 1;
                    }
                    else
                    {
                        // 不可能到这
                    }

                }

                i_1th += word1.Length; // 往前移动第一个单词的长度
            }

            if (index6 - index0 >= 6)
            {
                NumOfSentences++;
                TotalWords += (tmpNum + 6) / 7; // 把当前句中词的数量加到 总数中。
            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences;
            wsn.m_NGramWordNum = TotalWords;

            return wsn;
        }


        /*
         * 函数功能：把 1 - 8 阶关联词 写到数据库中
         * 参数说明：Words，字序列
         *          sL，原字符串
         *          dbc,数据库连接
         *     
         * 返回值：无
         */

        public WordSentenceNumPair Add_8_CoWords_2DB(string[] Words, string sL, DBConn dbc, List<string> LSql)
        {
            int i = 0;

            if (Words.Length < 8)
            {
                return new WordSentenceNumPair();
            }

            string word1 = null;
            string word2 = null;
            string word3 = null;
            string word4 = null;
            string word5 = null;
            string word6 = null;
            string word7 = null;
            string word8 = null;

            int NumOfSentences = 0;
            int TotalWords = 0;
            int tmpNum = 0;

            int i_1th = 0;
            int i_2th = 0;
            int i_3th = 0;
            int i_4th = 0;
            int i_5th = 0;
            int i_6th = 0;
            int i_7th = 0;
            int i_8th = 0;

            int id1 = 0;
            int id2 = 0;
            int id3 = 0;
            int id4 = 0;
            int id5 = 0;
            int id6 = 0;
            int id7 = 0;
            int id8 = 0;

            int index0 = 0;//单词0的下标
            int index7 = 0;//单词7的下标

            int order = 7; // 想起来了，用句子里面的单词数 除以 阶数，用于计算该阶数的关联词的数量

            List<SentsIndex> Lsents = new List<SentsIndex>();

            sL = wordSeg.FiltPlaceHolder(sL); // 过滤掉 哪些特殊的占位符（占有字符串长度但不显示）
            sL = sL.ToLower();                // 转换为小写

            index0 = 0;
            for (i = 0; i < Words.Length - 7; ++i)
            {
                word1 = Words[i];    // 第一个单词
                word2 = Words[i + 1];// 第二个单词
                word3 = Words[i + 2];// 第三个单词
                word4 = Words[i + 3];// 第四个单词
                word5 = Words[i + 4];// 第五个单词
                word6 = Words[i + 5];// 第六个单词
                word7 = Words[i + 6];// 第七个单词
                word8 = Words[i + 7];// 第八个单词

                index7 = i + 7;

                i_1th = sL.IndexOf(word1, i_1th);               // 第一个单词的起始位置
                i_2th = sL.IndexOf(word2, i_1th + word1.Length);// 第二个单词的起始位置
                i_3th = sL.IndexOf(word3, i_2th + word2.Length);// 第三个单词的起始位置
                i_4th = sL.IndexOf(word4, i_3th + word3.Length);// 第四个单词的起始位置
                i_5th = sL.IndexOf(word5, i_4th + word4.Length);// 第五个单词的起始位置
                i_6th = sL.IndexOf(word6, i_5th + word5.Length);// 第六个单词的起始位置
                i_7th = sL.IndexOf(word7, i_6th + word6.Length);// 第七个单词的起始位置
                i_8th = sL.IndexOf(word8, i_7th + word7.Length);// 第八个单词的起始位置

                // 是相邻的两个 单词 
                if (isViWordConjunction(i_1th + word1.Length, i_2th, sL) &&
                    isViWordConjunction(i_2th + word2.Length, i_3th, sL) &&
                    isViWordConjunction(i_3th + word3.Length, i_4th, sL) &&
                    isViWordConjunction(i_4th + word4.Length, i_5th, sL) &&
                    isViWordConjunction(i_5th + word5.Length, i_6th, sL) &&
                    isViWordConjunction(i_6th + word6.Length, i_7th, sL) &&
                    isViWordConjunction(i_7th + word7.Length, i_8th, sL))
                {
                    if (m_WordDic2.ContainsKey(word1) &&
                        m_WordDic2.ContainsKey(word2) &&
                        m_WordDic2.ContainsKey(word3) &&
                        m_WordDic2.ContainsKey(word4) &&
                        m_WordDic2.ContainsKey(word5) &&
                        m_WordDic2.ContainsKey(word6) &&
                        m_WordDic2.ContainsKey(word7) &&
                        m_WordDic2.ContainsKey(word8))
                    {// 字典中同时存在4个单词
                        id1 = m_WordDic2[word1];
                        id2 = m_WordDic2[word2];
                        id3 = m_WordDic2[word3];
                        id4 = m_WordDic2[word4];
                        id5 = m_WordDic2[word5];
                        id6 = m_WordDic2[word6];
                        id7 = m_WordDic2[word7];
                        id8 = m_WordDic2[word8];

                        AddSqlStatement_8(LSql, id1, id2, id3, id4, id5, id6, id7, id8, "tb_coll2017_jaist_ner_all_8");
                        tmpNum++;

                        if (LSql.Count == 4000)
                        {
                            dbc.WriteWCO2DB(LSql);// 公共的写入功能，无所谓几阶 
                            LSql.Clear();
                        }
                    }
                    else // 发现了 陌生单词
                    {
                        if (!m_WordDic2.ContainsKey(word8))
                        {//不包含第8个单字
                            if (index7 - index0 >= 8)
                            {
                                NumOfSentences++;
                                TotalWords += (tmpNum + order-1) / order; // 把当前句中词的数量加到 总数中。已经没什么用了，忽略
                                tmpNum = 0; // 清零

                                SentsIndex sid = new SentsIndex(index0,index7); // 发现一个句子，把它存起来
                                Lsents.Add(sid);
                                
                            }
                            index0 = index7 + 1; // 从不被包含的下一个字开始
                        }
                        else if (!m_WordDic2.ContainsKey(word7))
                        {
                            index0 = i + 7;   // 为什么会这样？如果往前推进，在第八个位置会首先遇到陌生单词。
                                              // 如果不是第八个位置是陌生单词，那么一定i=0，则0到7个单词就不能构成一个句子，略过。
                        }
                        else if (!m_WordDic2.ContainsKey(word6))
                        {
                            index0 = i + 6;
                        }
                        else if (!m_WordDic2.ContainsKey(word5))
                        {
                            index0 = i + 5;
                        }
                        else if (!m_WordDic2.ContainsKey(word4))
                        {
                            index0 = i + 4;
                        }
                        else if (!m_WordDic2.ContainsKey(word3))
                        {
                            index0 = i + 3;
                        }
                        else if (!m_WordDic2.ContainsKey(word2))
                        {
                            index0 = i + 2;
                        }
                        else if (!m_WordDic2.ContainsKey(word1))
                        {
                            index0 = i + 1;
                        }
                        else
                        {
                            // 不可能到这
                        }
                    }
                }
                else // 两个单词之间 不连续，存在句子边界，意味着断句（但是不知道在哪里断句，还要判断）
                {
                    if (!isViWordConjunction(i_7th + word7.Length, i_8th, sL))
                    {// 3-4单词之间存在句子边界
                        if (index7 - index0 >= 8)
                        {
                            NumOfSentences++;
                            TotalWords += (tmpNum + order-1) / order; // 把当前句中词的数量加到 总数中。，没什么用了，忽略
                            tmpNum = 0; // 清零

                            SentsIndex sid = new SentsIndex(index0, index7); // 发现一个句子，存起来
                            Lsents.Add(sid);
                        }

                        index0 = index7;//单词4作为起始
                    }
                    else if (!isViWordConjunction(i_6th + word6.Length, i_7th, sL))
                    {
                        index0 = i + 6; // 在往前推进的过程中，非连接字符只会发生在 7 和 8 之间，
                                        // 能到这里 只能 是 i = 0 的情况
                    }
                    else if (!isViWordConjunction(i_5th + word5.Length, i_6th, sL))
                    {
                        index0 = i + 5; // 
                    }
                    else if (!isViWordConjunction(i_4th + word4.Length, i_5th, sL))
                    {
                        index0 = i + 4;
                    }
                    else if (!isViWordConjunction(i_3th + word3.Length, i_4th, sL))
                    {
                        index0 = i + 3;
                    }
                    else if (!isViWordConjunction(i_2th + word2.Length, i_3th, sL))
                    {// 2-3单词之间存在句子边界
                        index0 = i + 2;
                    }
                    else if (!isViWordConjunction(i_1th + word1.Length, i_2th, sL))
                    {// 1-2单词之间存在句子边界
                        index0 = i + 1;
                    }
                    else
                    {
                        // 不可能到这
                    }

                }

                i_1th += word1.Length; // 往前移动第一个单词的长度
            }

            if (index7 - index0 >= 7)
            {
                NumOfSentences++;
                TotalWords += (tmpNum + order -1) / order; // 把当前句中词的数量加到 总数中。

                SentsIndex sid = new SentsIndex(index0, index7 + 1);// index7还是有效的，index +1 才是 下一个位置
                Lsents.Add(sid);

            }

            WordSentenceNumPair wsn = new WordSentenceNumPair();
            wsn.m_SentenceNum = NumOfSentences; // 句子的数量是很重要的参数 ！！！！！！！！
            wsn.m_NGramWordNum = TotalWords; // 这个参数应该没什么用

            //Add2AllTbls(Words, Lsents, dbc);  // 写数据库；

            return wsn;
        }

        /*
         * 函数功能：在满足 8 阶的标准下，重新构造关联矩阵，用一把尺子去量 
         * 参数说明：Words，原始单词序列
         *           Lst，再满足8阶的前提下，截取出来的句子
         *           dbc,数据库连接
         *           
         * 返回值：无
         * 
         * **/


        public void Add2AllTbls(string[] Words, List<SentsIndex> Lst, DBConn dbc)
        {
            int i = 0;
            int indx1 = 0;
            int indx2 = 0;
            int indx3 = 0;
            int indx4 = 0;
            int indx5 = 0;
            int indx6 = 0;
            int indx7 = 0;


            for (i = 0; i < Lst.Count; ++i)
            {
                int k = 0;
                /*
                for (k = Lst[i].m_st; k < Lst[i].m_ed; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    AddSqlStatement_1(m_LSqlCommUse,indx1,"TBL1");
                }
                
                for (k = Lst[i].m_st; k < Lst[i].m_ed-1; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    indx2 = m_WordDic2[Words[k+1]];

                    AddSqlStatement_2(m_LSqlCommUse, indx1,indx2, "TBL2");
                }

                for (k = Lst[i].m_st; k < Lst[i].m_ed - 2; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    indx2 = m_WordDic2[Words[k + 1]];
                    indx3 = m_WordDic2[Words[k + 2]];

                    AddSqlStatement_3(m_LSqlCommUse, indx1, indx2,indx3, "TBL3");
                }

                for (k = Lst[i].m_st; k < Lst[i].m_ed - 3; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    indx2 = m_WordDic2[Words[k + 1]];
                    indx3 = m_WordDic2[Words[k + 2]];
                    indx4 = m_WordDic2[Words[k + 3]];

                    AddSqlStatement_4(m_LSqlCommUse, indx1, indx2, indx3,indx4, "TBL4");
                }
               
                for (k = Lst[i].m_st; k < Lst[i].m_ed - 4; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    indx2 = m_WordDic2[Words[k + 1]];
                    indx3 = m_WordDic2[Words[k + 2]];
                    indx4 = m_WordDic2[Words[k + 3]];
                    indx5 = m_WordDic2[Words[k + 4]];

                    AddSqlStatement_5(m_LSqlCommUse, indx1, indx2, indx3, indx4,indx5, "TBL5");
                } */
                
                for (k = Lst[i].m_st; k < Lst[i].m_ed - 5; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    indx2 = m_WordDic2[Words[k + 1]];
                    indx3 = m_WordDic2[Words[k + 2]];
                    indx4 = m_WordDic2[Words[k + 3]];
                    indx5 = m_WordDic2[Words[k + 4]];
                    indx6 = m_WordDic2[Words[k + 5]];

                    AddSqlStatement_6(m_LSqlCommUse, indx1, indx2, indx3, indx4, indx5, indx6,"TBL6");
                }
                /*
               
                for (k = Lst[i].m_st; k < Lst[i].m_ed - 6; ++k)
                {
                    indx1 = m_WordDic2[Words[k]];
                    indx2 = m_WordDic2[Words[k + 1]];
                    indx3 = m_WordDic2[Words[k + 2]];
                    indx4 = m_WordDic2[Words[k + 3]];
                    indx5 = m_WordDic2[Words[k + 4]];
                    indx6 = m_WordDic2[Words[k + 5]];
                    indx7 = m_WordDic2[Words[k + 6]];

                    AddSqlStatement_7(m_LSqlCommUse, indx1, indx2, indx3, indx4, indx5, indx6,indx7, "TBL7");
                }
                */
                if (m_LSqlCommUse.Count > 800)
                {
                    dbc.WriteWCO2DB(m_LSqlCommUse);
                    m_LSqlCommUse.Clear();
                }

            }
        }

        /*
         * 函数功能：生成 sql 语句
         * 参数说明：L，sql列表
         *          i，第一个词的 下标
         *          sTblName,表名
         *          
         * 返回值：无 
         */

        private void AddSqlStatement_1(List<string> L, int i, string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }
       

        private void AddSqlStatement_2(List<string> L, int i, int j, string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }

        /*
         * 函数功能：生成 sql 语句
         * 参数说明：L，sql列表
         *          i，第一个词的 下标
         *          j，第二个词的 下标
         *          k，第三个词的 下标
         *          sTblName,表名
         *          
         * 返回值：无 
         */
        private void AddSqlStatement_3(List<string> L, int i,int j,int k,string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + "," + k.ToString() + ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }

        /*
         * 函数功能：生成 sql 语句
         * 参数说明：L，sql列表
         *          i，第一个词的 下标
         *          j，第二个词的 下标
         *          k，第三个词的 下标
         *          m，第四个词的 下标
         *          
         *          sTblName,表名
         *          
         * 返回值：无 
         */
        private void AddSqlStatement_4(List<string> L, int i, int j, int k,int m, string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + "," + k.ToString()+","+m.ToString() + ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }

        private void AddSqlStatement_5(List<string> L, int i, int j, int k, int m, int n,string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + "," + k.ToString() + "," + m.ToString() +","+n.ToString()+ ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }

        private void AddSqlStatement_6(List<string> L, int i, int j, int k, int m, int n,int p, string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + "," + k.ToString() + "," + m.ToString() + "," + n.ToString() +","+p.ToString()+ ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }

        private void AddSqlStatement_7(List<string> L, int i, int j, int k, int m, int n, int p,int r, string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + "," + k.ToString() + "," + m.ToString() + "," + n.ToString() + "," + p.ToString() + "," + r.ToString()+",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }

        private void AddSqlStatement_8(List<string> L, int i, int j, int k, int m, int n, int p, int r,int s, string sTblName)
        {
            string sql = "insert into " + sTblName + " values(" + i.ToString() + "," + j.ToString() + "," + k.ToString() + "," + m.ToString() + "," + n.ToString() + "," + p.ToString() + "," + r.ToString() + "," + s.ToString() + ",1) on duplicate key update coe=coe+1; ";
            L.Add(sql);
        }



        /*
         * 函数功能：判断 一个字符串两个位置之间 是不是 都是 越南语单词连接字符（词内连接符）
         * 参数说明：stPos,起始位置（包含）
         *           edPos,终止位置（不包含）
         *           sL，字符串
         *           
         * 返回值：  true，是
         *          false，否
         * 
         */

        public static bool isViWordConjunction( int stPos,int edPos,string sL )
        {
            //int i = 0;
            int j = 0;

            for (j = stPos; j < edPos; ++j)
            { 
                char c = sL[j];

                if (!c_IsAWordConj(c)) // 只要有一个不是连接字符，返回false
                {
                    return false;
                }
            }

            // 都是连接字符，返回true
            return true;
        }

        /*
         * 函数功能：判断字符C是不是 两个字之间的连接字符
         * 参数说明：c，被判断字符
         * 返回值：true，是连接字符
         *        false，不是连接字符
         */
        private static bool c_IsAWordConj( char c )
        {
            int i = 0;

            for (i = 0; i < m_ViWordCj.Length; ++i)
            {
                if (m_ViWordCj[i] == c) // 只要有一个相等，就返回true
                {
                    return true;
                }
            }

            // 都不等，返回false
            return false;
        }

        /*
         * 函数功能：获得单个字 sword 的概率
         * 参数说明：sword，字字符串。
         * 返回值：sword的概率
         */
        public decimal GetProWord( string sword )
        {
            decimal rd = 0.0M;

            if (!m_WordDic2.ContainsKey(sword))
            {
                return (0.00000000000001M) / m_totalWord; // 新词，给它一个很小很小的概率
            }

            int indx = m_WordDic2[sword];

            UInt32 numofword = m_WordNums[indx];

            rd = ((decimal)numofword)/m_totalWord;

            return rd;

        }

        // new + new +new + new +new + new +new + new +new + new +new + new +
        /*
         * 函数功能：获得单个字 sword 的概率
         *          同 GetProWord 的区别：（1）调整未登录字的概率，以出现1次计算概率
         *       
         * 参数说明：sword，字字符串。
         * 返回值：sword的概率
         */
        public decimal GetProWord_new(string sword)
        {
            decimal rd = 0.0M;

            if (!m_WordDic2.ContainsKey(sword))
            {
                return (1.0M) / m_totalWord; // 新词，给它一个很小很小的概率
            }

            int indx = m_WordDic2[sword];

            UInt32 numofword = m_WordNums[indx];

            rd = ((decimal)numofword) / m_totalWord;

            return rd;

        }

        /*
         * 函数功能：获得二阶关联词（sWord1，sWord2）的联合概率P(sWord1sWord2)
         * 参数说明：sWord1，字1
         *           sWord2，字2
         * 返回值：二阶关联词的概率
         * 
         */

        public decimal GetWord2Pro_new(string sWord1, string sWord2)
        {
            ///// sWord1和sWord2 有一个是新词
            if (!m_WordDic2.ContainsKey(sWord1) || !m_WordDic2.ContainsKey(sWord2))
            {
                long tmp =((long)m_ACTTW_2)*((long)m_ACTTW_2);
                return (1.0M) / (tmp); // 这个很有讲究
            }

            int indx1 = m_WordDic2[sWord1];
            int indx2 = m_WordDic2[sWord2];

            UInt32 Occrs = m_A[indx1, indx2];

            if (Occrs <= 0)
            {
                long tmp = ((long)m_ACTTW_2) * ((long)m_ACTTW_2);
                return (1.0M) / (tmp); // 这个很有讲究
            }

            decimal d = ((decimal)Occrs) / m_ACTTW_2;

            return d;

        }

        // new + new +new + new +new + new +new + new +new + new +new + new +
        // new + new +new + new +new + new +new + new +new + new +new + new +

        /*
         * 函数功能：获得单个字 sword 的概率
         * 参数说明：sword，字字符串。
         * 返回值：sword的概率
         */
        public decimal GetProWord_4Condition(string sword)
        {
            decimal rd = 0.0M;

            if (!m_WordDic2.ContainsKey(sword))
            {
                return (0.00000000000001M) / m_totalWord; // 新词，给它一个很小很小的概率
            }

            int indx = m_WordDic2[sword];

            UInt32 numofword = m_WordNumsCondition[indx];

            rd = ((decimal)numofword) / m_totalWordCondition;

            return rd;

        }


        /*
         * 函数功能：获得二阶关联词（sWord1，sWord2）的概率P(sWord1sWord2)
         * 参数说明：sWord1，字1
         *           sWord2，字2
         * 返回值：二阶关联词的概率
         * 
         */

        public decimal GetWord2Pro( string sWord1,string sWord2)
        {
            ///// sWord1和sWord2 有一个是新词
            if (!m_WordDic2.ContainsKey(sWord1) || !m_WordDic2.ContainsKey(sWord2))
            {
                return (0.00000000000000001M) / m_totalWord_2;
            }

            int indx1 = m_WordDic2[sWord1];
            int indx2 = m_WordDic2[sWord2];

            UInt32 Occrs = m_A[indx1,indx2];

            if (Occrs <= 0)
            {
                return (0.00000000000000001M) / m_totalWord_2;
            }

            decimal d = ((decimal)Occrs)/m_totalWord_2;

            return d;

        }

///============================
///

        /*
        * 函数功能：获得二阶关联词 P（sWord2|sWord1）的概率,考虑一阶马尔可夫特性并且 有序性
        * 参数说明：sWord1，字1
        *           sWord2，字2
        * 返回值：二阶关联词的概率
        */

        public decimal GetWord2Pro_condition(string sWord1, string sWord2)
        {
            ///// sWord1和sWord2 有一个是新词,返回一个充分小的概率
            if (!m_WordDic2.ContainsKey(sWord1) || !m_WordDic2.ContainsKey(sWord2))
            {
                return (0.00000000001M) / m_totalWord_2;
            }

            int indx1 = m_WordDic2[sWord1];
            int indx2 = m_WordDic2[sWord2];

            UInt32 Occrs = m_A[indx1, indx2];

            if (Occrs <= 0)
            {   // 返回一个充分小的概率
                return (0.00000000001M) / m_totalWord_2;
            }

            //decimal d = ((decimal)Occrs) / m_WordNums[indx1]; // 相当于 P（sWord2|sWord1）

            decimal d = ((decimal)Occrs) / m_WordNumsCondition[indx1]; // 相当于 P（sWord2|sWord1）

            return d;

        }


        /********************************************/
        //                          空格  tab  中杠半角  中杆圆角
        private static char[] m_ViWordCj = {' ', '\t',  '-',    '—' };  // 可以作为字之间的连接符构成词

        public Dictionary<string, int> m_WordDic2 = null; // 字典，存储的是单词的索引，即 单词i：i，这样在数据库种存储索引即可

        private UInt32[,] m_A = null;  // 二阶关联矩阵，（单词1，单词2）的出现次数

        public UInt32[] m_WordNums = null;          // 统计原始所有文本所得单词出现次数
        public UInt32[] m_WordNumsCondition = null; // 仅使用二维矩阵计算单词出现的次数，计算条件概率用到如 P(w2|w1)

        public UInt32   m_totalWord_2 = 0;          // 2阶关联词的总数量
        public UInt32   m_totalWord = 0;            // 单个字的总数量，由原始文本统计得到的 前 10000个单词 的数量和 
        public UInt32   m_totalWordCondition = 0;   // 单个字的总数量，由二阶关联矩阵统计

        public UInt32 m_ACTTW_2 = 41291537;         // 实际二阶词的数量,经过特殊计算得到的虚拟 二阶词个数 

        List<string> m_LSqlCommUse = new List<string>();

    }
}
