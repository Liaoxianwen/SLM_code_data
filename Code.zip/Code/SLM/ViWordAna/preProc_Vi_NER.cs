﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.IO;

namespace ViWordAna
{

    public enum NERTAGS { S_O = 0, ERR = -1, 
                   B_PER = 1, M_PER = 2, E_PER = 3, S_PER = 4,
                   B_LOC = 5, M_LOC = 6, E_LOC = 7, S_LOC = 8,
                   B_ORG = 9, M_ORG = 10, E_ORG = 11, S_ORG = 12
    }

    /*
     * 存储 一个 单词 和标签
     * 
     * **/
    public class word_tag
    {
        public word_tag() { }

        public string getString()
        {
            if (isFilter == true)
            {
                return "";
            }

            string sTag = "";

            if (m_tag == NERTAGS.S_O)
            {
                sTag = "S_O";
            }
            else if (m_tag == NERTAGS.ERR)
            {
                sTag = "ERR";
            }
            else if (m_tag == NERTAGS.B_ORG)
            {
                sTag = "B_ORG";
            }
            else if (m_tag == NERTAGS.M_ORG)
            {
                sTag = "M_ORG";
            }
            else if (m_tag == NERTAGS.E_ORG)
            {
                sTag = "E_ORG";
            }
            else if (m_tag == NERTAGS.S_ORG)
            {
                sTag = "S_ORG";
            }
            else if (m_tag == NERTAGS.B_PER)
            {
                sTag = "B_PER";
            }
            else if (m_tag == NERTAGS.M_PER)
            {
                sTag = "M_PER";
            }
            else if (m_tag == NERTAGS.E_PER)
            {
                sTag = "E_PER";
            }
            else if (m_tag == NERTAGS.S_PER)
            {
                sTag = "S_PER";
            }
            else if (m_tag == NERTAGS.B_LOC)
            {
                sTag = "B_LOC";
            }
            else if (m_tag == NERTAGS.M_LOC)
            {
                sTag = "M_LOC";
            }
            else if (m_tag == NERTAGS.E_LOC)
            {
                sTag = "E_LOC";
            }
            else if (m_tag == NERTAGS.S_LOC)
            {
                sTag = "S_LOC";
            }
            else
            {
                sTag = "EERRRRRRRRR!";
            }

            return m_sword + " " + sTag;

            

        }

        public string m_sword = "";
        public NERTAGS m_tag = NERTAGS.ERR;

        public bool isFilter = false; // 是否被过滤

    }


    public class One_Sentence
    {
        public One_Sentence() { }

        // 给 句子 单词 序列 附上 正确的 标签
        public void Assign_word_tag()
        {
            int i = 0;

            if (m_wordLst.Count <= 4)
            {
                for (i = 0; i < m_wordLst.Count; ++i)
                {
                    m_wordLst[i].m_tag = NERTAGS.S_O;
                }

                return;
            }


            // 第一步 ：先找到 BEGIN 的位置

            for (i = 1; i < m_wordLst.Count; ++i)
            {
                if (m_wordLst[i].m_sword.ToLower().Equals("per") && m_wordLst[i - 1].m_sword.Equals("[") && m_wordLst[i + 1].m_sword.Equals(":") && i + 2 < m_wordLst.Count && !m_wordLst[i + 2].m_sword.Equals("]"))
                {
                    m_wordLst[i+2].m_tag = NERTAGS.B_PER;
                }
                else if (m_wordLst[i].m_sword.ToLower().Equals("loc") && m_wordLst[i - 1].m_sword.Equals("[") && m_wordLst[i + 1].m_sword.Equals(":") && i + 2 < m_wordLst.Count && !m_wordLst[i + 2].m_sword.Equals("]"))
                {
                    m_wordLst[i + 2].m_tag = NERTAGS.B_LOC;
                }
                else if (m_wordLst[i].m_sword.ToLower().Equals("org") && m_wordLst[i - 1].m_sword.Equals("[") && m_wordLst[i + 1].m_sword.Equals(":") && i + 2 < m_wordLst.Count && !m_wordLst[i + 2].m_sword.Equals("]"))
                {
                    m_wordLst[i + 2].m_tag = NERTAGS.B_ORG;
                }
                else
                {

                }
            }


            // 第二步： 把 B M E S 补全 

            for (i = 0; i < m_wordLst.Count-1; ++i)
            {
                if (m_wordLst[i].m_tag == NERTAGS.B_PER)
                {
                    if (m_wordLst[i + 1].m_sword.Equals("]"))
                    {
                        m_wordLst[i].m_tag = NERTAGS.S_PER; // 转换为 S 标签
                        continue;
                    }

                    i++;

                    while (i + 1 < m_wordLst.Count && m_wordLst[i].m_tag == NERTAGS.ERR && (!m_wordLst[i + 1].m_sword.Equals("]")))
                    {
                        m_wordLst[i].m_tag = NERTAGS.M_PER;
                        ++i;
                    }
                    
                    m_wordLst[i].m_tag = NERTAGS.E_PER;
                }
                else if (m_wordLst[i].m_tag == NERTAGS.B_LOC)
                {
                    if (m_wordLst[i + 1].m_sword.Equals("]"))
                    {
                        m_wordLst[i].m_tag = NERTAGS.S_LOC; // 转换为 S 标签
                        continue;
                    }

                    i++;

                    while (i + 1 < m_wordLst.Count && m_wordLst[i].m_tag == NERTAGS.ERR && (!m_wordLst[i + 1].m_sword.Equals("]")))
                    {
                        m_wordLst[i].m_tag = NERTAGS.M_LOC;
                        ++i;
                    }

                    m_wordLst[i].m_tag = NERTAGS.E_LOC;
                }
                else if (m_wordLst[i].m_tag == NERTAGS.B_ORG)
                {
                    if (m_wordLst[i + 1].m_sword.Equals("]"))
                    {
                        m_wordLst[i].m_tag = NERTAGS.S_ORG; // 转换为 S 标签
                        continue;
                    }

                    i++;

                    while (i + 1 < m_wordLst.Count && m_wordLst[i].m_tag == NERTAGS.ERR && (!m_wordLst[i + 1].m_sword.Equals("]")))
                    {
                        m_wordLst[i].m_tag = NERTAGS.M_ORG;
                        ++i;
                    }

                    m_wordLst[i].m_tag = NERTAGS.E_ORG;
                }
                else
                {
                    
                }

            }

            // 第三 步，过滤掉一些标签 

            for (i = 3; i < m_wordLst.Count-1; ++i)
            {
                if (m_wordLst[i].m_tag == NERTAGS.B_PER )
                {
                    if (m_wordLst[i - 1].m_sword.Equals(":") &&
                       m_wordLst[i - 2].m_sword.ToLower().Equals("per") &&
                       m_wordLst[i - 3].m_sword.Equals("["))
                    {
                        m_wordLst[i - 1].isFilter = true;
                        m_wordLst[i - 2].isFilter = true;
                        m_wordLst[i - 3].isFilter = true;
                    }
                }
                else if (m_wordLst[i].m_tag == NERTAGS.B_LOC)
                {
                    if (m_wordLst[i - 1].m_sword.Equals(":") &&
                        m_wordLst[i - 2].m_sword.ToLower().Equals("loc") &&
                        m_wordLst[i - 3].m_sword.Equals("["))
                    {
                        m_wordLst[i - 1].isFilter = true;
                        m_wordLst[i - 2].isFilter = true;
                        m_wordLst[i - 3].isFilter = true;
                    }
                }
                else if (m_wordLst[i].m_tag == NERTAGS.B_ORG)
                {
                    if (m_wordLst[i - 1].m_sword.Equals(":") &&
                        m_wordLst[i - 2].m_sword.ToLower().Equals("org") &&
                        m_wordLst[i - 3].m_sword.Equals("["))
                    {
                        m_wordLst[i - 1].isFilter = true;
                        m_wordLst[i - 2].isFilter = true;
                        m_wordLst[i - 3].isFilter = true;
                    }
                }
                else if (m_wordLst[i].m_tag == NERTAGS.E_ORG ||
                         m_wordLst[i].m_tag == NERTAGS.E_PER ||
                         m_wordLst[i].m_tag == NERTAGS.E_LOC)
                {
                    if (m_wordLst[i + 1].m_sword.Equals("]"))
                    {
                        m_wordLst[i + 1].isFilter = true;
                    }
                }
                else if (m_wordLst[i].m_tag == NERTAGS.S_ORG ||
                         m_wordLst[i].m_tag == NERTAGS.S_PER ||
                         m_wordLst[i].m_tag == NERTAGS.S_LOC)
                {
                        m_wordLst[i - 1].isFilter = true;
                        m_wordLst[i - 2].isFilter = true;
                        m_wordLst[i - 3].isFilter = true;
                        m_wordLst[i + 1].isFilter = true;
                }
            }

            //  第四 步：剩下的 赋予 OTHER 标签

            for (i = 0; i < m_wordLst.Count; ++i)
            {
                if (!m_wordLst[i].isFilter && m_wordLst[i].m_tag == NERTAGS.ERR)
                {
                    m_wordLst[i].m_tag = NERTAGS.S_O;
                }
            }

        }

        public void Write2File(StreamWriter sw)
        {
            int i = 0;
            string ss = "";

            for (i = 0; i < m_wordLst.Count; ++i)
            {
                ss = m_wordLst[i].getString();

                if (!ss.Equals(""))
                {
                    sw.WriteLine(ss);
                }

            }

            sw.WriteLine("");
        }

        public List<word_tag> m_wordLst = new List<word_tag>();
        public string m_sOriginal_Str = "";
    }



    /*
     * 类功能说明：对 梅岭 同学 标注的 越南语 NER 进行 预处理，包括：
     * （1）把手工标注如：ngành thuộc [ORG: UBND TP.HCM] đã tham 转换为：
     *        S_0    S_0  B_org  E_org S_0 S_0 .....
     *       ngành thuộc UBND TP.HCM đã tham .....
     *       
     * （2）从转换成 B_ I_ O_ 标注序列之后的“标注文件”，生成 句子 导入数据库，这样做的目的是，
     *      使得 预分词文件 和 golden 标注 文件 保持一致。
     * 
     * **/

    public class preProc_Vi_NER
    {
        public preProc_Vi_NER() { }


        public void convert_2_standard_NER_tags()
        {
            string sFilename = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_NER_original.txt";
            string sFile2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_NER.txt";

            StreamWriter sw = new StreamWriter(sFile2Save, false, Encoding.UTF8);

            StreamReader sr = new StreamReader(sFilename, Encoding.UTF8);
            string sLine = "";

            List<One_Sentence> Lst = new List<One_Sentence>();

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();

                if (sLine.Trim().Equals(""))
                {
                    continue;
                }

                sLine = Filter_Line_No(sLine);

                string[] res = splitSents(sLine);

                One_Sentence os = make_one_sentence(res);

                Lst.Add(os);
            }

            int i = 0;

            for (i = 0; i < Lst.Count; ++i)
            {
                //sw.WriteLine("/////: " + i.ToString());
                Lst[i].Write2File(sw);
            }

            //sw.WriteLine("/////: -- End --  " );

            sw.Dispose();
            sr.Dispose();

            MessageBox.Show("finish!");



        }


        /*
         * 函数功能：过滤掉前面每个句子的行号
         * 
         *  原始句子： 1493.	Vào năm 2015, ........
         *  过滤之后：Vào năm 2015, ......
         *  
         * 
         * 参数说明：sLine，一个字符串（句子）
         * 
         * 返回值：去掉行号的句子。
         * **/
        private string Filter_Line_No( string sLine)
        {
            if (sLine == null)
            {
                MessageBox.Show("过滤的字符串 居然 为null ");
                return "";
            }
            else if (sLine.Length == 0)
            {
                MessageBox.Show("过滤的字符串 长度 居然 为 0 ");
                return "";
            }

            string[] sp = { "	" }; // 行号 和 行内容 之间 特殊的 分隔符

            string []res = sLine.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            if (res.Length < 2)
            {
                MessageBox.Show("这行字符串 有点 问题，只有 分隔符，没有内容？？" + sLine);
                return "";
            }

            int i = 0;
            string sRT = "";

            for (i = 1; i < res.Length; ++i)
            {
                sRT += res[i] + " ";
            }

            return sRT;
        }

        // 对字符串进行 拆分 
        private string[] splitSents(string sSents)
        {
            string[] sp = { " ", "    ", "\t" }; // 空格 tab 和 \t

            if (sSents == null)
            {
                MessageBox.Show("拆分的字符串为 空！");
                return null;
            }

            if (sSents.Length == 0)
            {
                MessageBox.Show("拆分的字符串 长度为 0！");
                return null;
            }

            string[] res = sSents.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            return res;

        }

        public One_Sentence make_one_sentence(string[] res)
        {
            if (res == null)
            {
                MessageBox.Show("make_one_sentence 传入 数组 为空！");
                return null;
            }
            else if (res.Length == 0)
            {
                MessageBox.Show("make_one_sentence 传入 数组 长度 为 0 ！");
                return null;
            }

            One_Sentence asents = new One_Sentence();
            int i = 0;

            for (i = 0; i < res.Length; ++i)
            {
                word_tag wt = new word_tag();
                wt.m_sword = res[i];

                asents.m_wordLst.Add(wt);
            }

            asents.Assign_word_tag();

            return asents;
        }

        // 函数功能：统计 一个字符在一个句子里面的出现次数，用于查找 "["和"]"不匹配的情况
        private int get_num_of_char(string str, char ch)
        {
            if (str == null || str.Length == 0)
            {
                return 0;
            }

            int i = 0;
            int cnt = 0;

            for (i = 0; i < str.Length; ++i)
            {
                if (str[i] == ch)
                {
                    cnt++;
                }
            }

            return cnt;
        }

        /*
        * 函数功能：从标准 的 NER 标注 文件中 提取 句子 ，用于 入库 和 预 分词，这样可以保证 预 分词 不会出错（预分词 和 
         * 标准的 ner 标注文件 一一对应。）
        * 参数说明：无
        * 
        * 返回值：无
        * 
        */

        public void GetSentencesFrom_Standard_ner_file()
        {
            string sFilePathName = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_test.txt";
            string sFilePathName2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语NER\vi_ner_test_sents4preseg.txt";
            StreamWriter sw = new StreamWriter(sFilePathName2Save, false, Encoding.UTF8);

            StreamReader sr = new StreamReader(sFilePathName);
            List<string> lst = new List<string>();
            string str = "";
            string aSentence = "";

            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();

                str = str.Trim();

                if (!str.Equals(""))
                {
                    aSentence += str + " ";
                }
                else
                {
                    lst.Add(aSentence);
                    aSentence = "";
                }
            }

            sr.Close();
            sr.Dispose();

            int i = 0;
            string[] sp = { "S_O", 
                            "B_PER", "M_PER", "E_PER", "S_PER", 
                            "B_ORG", "M_ORG", "E_ORG", "S_ORG",
                            "B_LOC", "M_LOC", "E_LOC", "S_LOC",};


            for (i = 0; i < lst.Count; ++i)
            {
                string s = lst[i];


                s = s.Replace("B_PER", "");
                s = s.Replace("M_PER", "");
                s = s.Replace("E_PER", "");
                s = s.Replace("S_PER", "");

                s = s.Replace("B_ORG", "");
                s = s.Replace("M_ORG", "");
                s = s.Replace("E_ORG", "");
                s = s.Replace("S_ORG", "");

                s = s.Replace("B_LOC", "");
                s = s.Replace("M_LOC", "");
                s = s.Replace("E_LOC", "");
                s = s.Replace("S_LOC", "");

                s = s.Replace("S_O", ""); // 这个 一定要放 最后，要不然 会 替换 S_ORG，剩下 RG 形成句子的一部分

                if (!s.Trim().Equals(""))
                {
                    sw.WriteLine(s);
                }
            }

            sw.Close();
            sw.Dispose();
        }


    }
}
