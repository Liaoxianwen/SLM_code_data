﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.IO;
using System.Windows.Forms;

namespace ViWordAna
{
    /*
     * 类说明：用来存储 vi-ud-train/dev/test.conllu 中一个被标注的 词（可能包含多个越南语单词）
     * **/
       
    public class A_Word
    {
        public A_Word() { }

        public List<string> m_cLst = new List<string>();

        /*
         * 函数功能：获取 单词 和 其 对应的 标签，以 list 结构返回（也就是这个segment 会包含几个单词）
         * 参数说明：无
         * 
         * 返回值： “word tag”的列表
         * 
         * **/
        public List<string> getWord_and_Tag_4_Write()
        {
            List<string> lst = new List<string>();
            int i = 0;

            if (m_cLst == null || m_cLst.Count == 0)
            {
                return lst;
            }

            if (m_cLst.Count == 1)
            {
                lst.Add(m_cLst[0] + " S");
            }
            else if (m_cLst.Count == 2)
            {
                lst.Add(m_cLst[0] + " B");
                lst.Add(m_cLst[1] + " E");
            }
            else if (m_cLst.Count >= 3)
            {
                lst.Add(m_cLst[0] + " B");

                for (i = 1; i < m_cLst.Count - 1; ++i)
                {
                    lst.Add(m_cLst[i] + " M");
                }

                lst.Add(m_cLst[m_cLst.Count-1] + " E");

            }

            return lst;
        }

        /*
        * 函数功能：获取 这个“词”的 string，例如这个“词”包含 word1 word2 word3，则返回 word1+" "+word2+" "+word3
        * 参数说明：无
        * 
        * 返回值： word1+" "+word2+" "+word3
        * 
        * **/
        public string getWord_String_4_Write()
        {
            string sRT = "";
            int i = 0;

            for (i = 0; i < m_cLst.Count ; ++i)
            {
                sRT += m_cLst[i] + " ";
            }

            return sRT;
        }
    }

    /*
     * 类说明：用于表示 一个词和它的 词性
     * 
     */
    public class A_Word_POS
    {
        public A_Word_POS() { }

        public List<string> m_cLst = new List<string>();
        public string m_sPos = "";

        /*
         * 函数功能：获取 单词 和 其 对应的 标签，以 list 结构返回（也就是这个segment 会包含几个单词）
         * 参数说明：无
         * 
         * 返回值： “word tag”的列表
         * 
         * **/
        public List<string> getWord_and_POS_4_Write()
        {
            List<string> lst = new List<string>();
            int i = 0;

            if (m_cLst == null || m_cLst.Count == 0||m_sPos.Equals(""))
            {
                MessageBox.Show("一个词的 词性 居然 为 空 ！");
                return lst;
            }

            if (m_cLst.Count == 1)
            {
                lst.Add(m_cLst[0] + " S_" + m_sPos);
            }
            else if (m_cLst.Count == 2)
            {
                lst.Add(m_cLst[0] + " B_"+m_sPos);
                lst.Add(m_cLst[1] + " E_"+m_sPos);
            }
            else if (m_cLst.Count >= 3)
            {
                lst.Add(m_cLst[0] + " B_"+m_sPos);

                for (i = 1; i < m_cLst.Count - 1; ++i)
                {
                    lst.Add(m_cLst[i] + " M_"+m_sPos);
                }

                lst.Add(m_cLst[m_cLst.Count - 1] + " E_"+m_sPos);

            }

            return lst;
        }
    }

    /*
     * 类说明：用来存储 vi-ud-train/dev/test.conllu 中一个被分词标注的句子
     * 
     */
    public class A_Segmented_Sents
    {
        public A_Segmented_Sents() { }

        public void Write2File(StreamWriter sw)
        {
            int i = 0;

            for (i = 0; i < m_wLst.Count; ++i)
            {
                List<string> lst = m_wLst[i].getWord_and_Tag_4_Write();
                int j = 0;

                for (j = 0; j < lst.Count; ++j)
                {
                    sw.WriteLine(lst[j]);
                }

            }
        }

        public void Write2File_RawSentence(StreamWriter sw)
        {
            int i = 0;
            string sWord = "";

            for (i = 0; i < m_wLst.Count; ++i)
            {
                sWord += m_wLst[i].getWord_String_4_Write();
            }

            sw.WriteLine(sWord);

        }

        public List<A_Word> m_wLst = new List<A_Word>();
    }


    /*
     * 类说明：用来存储 vi-ud-train/dev/test.conllu 中一个 POS 的句子
     * 
     */
    public class A_POS_Sents
    {
        public A_POS_Sents() { }

        public void Write2File(StreamWriter sw)
        {
            int i = 0;

            for (i = 0; i < m_wLst.Count; ++i)
            {
                List<string> lst = m_wLst[i].getWord_and_POS_4_Write();
                int j = 0;

                for (j = 0; j < lst.Count; ++j)
                {
                    sw.WriteLine(lst[j]);
                }

            }
        }

        public List<A_Word_POS> m_wLst = new List<A_Word_POS>();
    }


    public class prePreocess_CONLL2017
    {
        public prePreocess_CONLL2017() { }

        /*
         * 函数功能：从 conll 2017 的 train dev test 文件中 提取 原始句子文件 ，用于把 n阶 关联词 写入 数据库
         * 参数说明：无
         * 
         * 返回值：一个文件，包含 train dev test 中 所有的 原始句子
         * **/

        public void get_Raw_sentences_from_train_dev_test_Dataset()
        {
            string sfilePathName_train = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-train.conllu";
            string sfilePathName_dev = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-dev.conllu";
            string sfilePathName_test = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-test.conllu";

            string sfilePathName_2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\conll2017_sents_test.txt";

            get_Golden_segmentation_from_file(sfilePathName_test, sfilePathName_2Save, true);

            return;

            // 下面都不用了。。。。 都统一用 get_Golden_segmentation_from_file 了

            StreamWriter sw = new StreamWriter(sfilePathName_2Save, false,Encoding.UTF8);
            StreamReader sr = new StreamReader(sfilePathName_train, Encoding.UTF8);
            StreamReader srdev = new StreamReader(sfilePathName_dev, Encoding.UTF8);
            StreamReader srtest = new StreamReader(sfilePathName_test, Encoding.UTF8);
/*
            while (!sr.EndOfStream)
            {
                string sLine = sr.ReadLine().Trim();

                if (isRawSentence(sLine))
                {
                    sw.WriteLine(getRawSentence(sLine));
                }

            }
            
            while (!srdev.EndOfStream)
            {
                string sLine = srdev.ReadLine().Trim();

                if (isRawSentence(sLine))
                {
                    sw.WriteLine(getRawSentence(sLine));
                }

            }*/
            
            while (!srtest.EndOfStream)
            {
                string sLine = srtest.ReadLine().Trim();

                if (isRawSentence(sLine))
                {
                    sw.WriteLine(getRawSentence(sLine));
                }

            }

            sw.Dispose();
            sr.Dispose();
            srdev.Dispose();
            srtest.Dispose();


        }

        /*
         * 函数功能：判断 一个 string 是不是 形如: # text = mảnh đất của đạn bom không còn người nghèo.
         * 参数说明：sLine,一个句子
         * 
         * 返回值：true or false；
         * 
         * **/
        private bool isRawSentence( string sLine )
        {
            string[] sp = { " " };

            sLine = sLine.ToLower();

            string[] sRES = sLine.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            if (sRES == null || sRES.Length < 2)
            {
                return false;
            }

            if (sRES[0].Equals("#") && sRES[1].Equals("text") && sRES[2].Equals("="))
            {
                return true;
            }
            return false;
        }

        /*
         * 函数功能：获得原始句子
         * 参数说明：sLine, 一个句子
         * 
         * 返回值：一个原始句子
         * 
         * 例如：sLine =:# text = mảnh đất của đạn bom không còn người nghèo.
         * 则返回：mảnh đất của đạn bom không còn người nghèo.
         * **/
        private string getRawSentence( string sLine)
        {
            string[] sp = { " " };

            string[] sRES = sLine.Split(sp, StringSplitOptions.RemoveEmptyEntries);

            if (sRES == null || sRES.Length < 2)
            {
                return null;
            }

            string str = "";
            int i = 0;

            for (i = 3; i < sRES.Length; ++i)
            {
                str += sRES[i] + " ";
            }

                return str;

        }

        /*
         * 函数功能：获取 CONLL2017 train dev test 数据集中 词性 标注的 标签， 用于提取分词 信息。
         * 参数说明：无
         * 
         * 返回值：Pos tag.
         * 
         */
        public void get_PosTag_from_train_dev_test_Dataset()
        {
            string sfilePathName_train = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-train.conllu";
            string sfilePathName_dev = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-dev.conllu";
            string sfilePathName_test = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-test.conllu";

            string sfilePathName_2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\conll2017_POS_Tag.txt";

            StreamWriter sw = new StreamWriter(sfilePathName_2Save, false, Encoding.UTF8);
            StreamReader sr = new StreamReader(sfilePathName_train, Encoding.UTF8);
            StreamReader srdev = new StreamReader(sfilePathName_dev, Encoding.UTF8);
            StreamReader srtest = new StreamReader(sfilePathName_test, Encoding.UTF8);

            Dictionary<string, int> posDic = new Dictionary<string, int>();
            string sLine = "";

            while(!sr.EndOfStream)
            {
                sLine = sr.ReadLine();

                if( isSegment_Line(sLine))
                {
                    string[] sp = { " ", "\t", "	" };
                    string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

                    if(res.Length >= 10 )
                    {
                        int pos = res.Length - 7;
                        posDic[res[pos]] = 1;
                    }
                }
            }

            ///----------------
            ///
            while (!srdev.EndOfStream)
            {
                sLine = srdev.ReadLine();

                if (isSegment_Line(sLine))
                {
                    string[] sp = { " ", "\t", "	" };
                    string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

                    if (res.Length >= 10)
                    {
                        int pos = res.Length - 7;
                        posDic[res[pos]] = 1;
                    }
                }
            }

            ////////----------------------

            while (!srtest.EndOfStream)
            {
                sLine = srtest.ReadLine();

                if (isSegment_Line(sLine))
                {
                    string[] sp = { " ", "\t", "	" };
                    string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

                    if (res.Length >= 10)
                    {
                        int pos = res.Length - 7;
                        posDic[res[pos]] = 1;
                    }
                }
            }



            foreach(KeyValuePair<string,int> kv in posDic)
            {
                sw.WriteLine(kv.Key);
            }
            

            sw.Dispose();
            sr.Dispose();
            srdev.Dispose();
            srtest.Dispose();
        }

        /*
         * 函数功能：判断 一个 string 是否 包含 分词 信息（或者标注信息），该判断 作为进一步处理的 条件
         * 
         * 参数说明：sLine, 一个字符串
         * 
         * 返回值：true or false
         * 
         * **/
        private bool isSegment_Line(string sLine)
        {
            string[] sp = { " ", "\t", "	" };

            string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

            if (res == null|| res.Length < 1)
            {
                return false;
            }


            if( Regex.Matches(res[0], @"\d+").Count>0 )
            {
                return true;
            }

            return false;
        }

        /*
         * 函数功能：判断 一句话 是否包含 词性 标签，可以用这个条件来 判断 这个句子是否包含分析信息（标注信息）
         * 参数说明:sLine,一个字符串
         * 
         * 返回值：true or false；
         * 
         * **/

        private bool hasPosTag( string sLine)
        {
            if (!isSegment_Line(sLine))
            {
                return false;
            }

            Dictionary<string, int> posDic = new Dictionary<string, int>();
            posDic["NOUN"] = 1;
            posDic["ADP"] = 1;
            posDic["X"] = 1;
            posDic["VERB"] = 1;
            posDic["ADJ"] = 1;
            posDic["PUNCT"] = 1;
            posDic["SCONJ"] = 1;
            posDic["NUM"] = 1;
            posDic["DET"] = 1;
            posDic["CCONJ"] = 1;
            posDic["PROPN"] = 1;
            posDic["AUX"] = 1;
            posDic["PART"] = 1;
            posDic["INTJ"] = 1;

            string[] sp = { " ", "\t", "	" };
            string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

            if (res == null || res.Length < 10)
            {
                return false;
            }

            string sss = res[res.Length - 7 ];

            if (posDic.ContainsKey(sss))
            {
                return true;
            }

            return false;

        }

        /*
         * 函数功能：提取 golden 分词 ，保存 文件
         * 参数说明：无
         * 
         * 返回值：golden 分词文件
         * 
         * **/
        public void get_Golden_segmentation_from_train_dev_test_Dataset()
        {
            string sfilePathName_train = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-train.conllu";
            string sfilePathName_dev = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-dev.conllu";
            string sfilePathName_test = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-test.conllu";

            string sfilePathName_2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-test_segment.txt";

            get_Golden_segmentation_from_file(sfilePathName_test, sfilePathName_2Save, false);

        }

        /*
         * 函数功能：从文件 vi-ud-train/dev/test.conllu 中提取 分词，并 写入到文件中去
         * 
         * 参数说明：sFilepathName，原文件
         *           sFilepathName2Save，分词信息写入的目标文件
         *           bgetRawSents，为true，则把 分词信息 拼接成句子。
         *                          false,只是写分词信息。
         *                          
         *  特 别 注 意 ： 用于 统计 分词的所有句子，都应该用这个 函数 来生成。
         *                 这样 统计预分词 和 golden 分词 的 单词数量就对得上了。
         *                 假如 直接 使用 原始句子，原始句子里面的标点和单词是粘连在一起的，
         *                 粘连在一起时，统计预分词是无法分开它们的，造成了 预分词 和 golden
         *                 分词 无法对应，在训练神经网络时，序列长度不一样，就很麻烦了，原因时单词不好对应。
         *           
         * 返回值：一个文件
         * 
         */

        public void get_Golden_segmentation_from_file( string sFilepathName, string sFilepathName2Save, bool bgetRawSents = false )
        {

            StreamReader sr = new StreamReader(sFilepathName, Encoding.UTF8);
            StreamWriter sw = new StreamWriter(sFilepathName2Save, false,Encoding.UTF8);

            string sLine = "";

            List<A_Segmented_Sents> Lst = new List<A_Segmented_Sents>();

            A_Segmented_Sents a_sent = new A_Segmented_Sents() ;

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();

                if(  ! (isSegment_Line(sLine)&& hasPosTag(sLine)) ) // 条件不成立，则 continue
                {
                    if (a_sent.m_wLst.Count > 0) // 句子里面有词
                    {
                        Lst.Add(a_sent);

                        a_sent = new A_Segmented_Sents();
                    }

                    continue;
                }

                // 包含 分词（标注信息）， 则进行 下面的处理
                string[] sp = { " ", "\t", "	" };
                string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

                A_Word w = new A_Word();

                int i = 0;
                int cnt = (res.Length-8)/2;

                for (i = 0; i < cnt; ++i)
                {
                    w.m_cLst.Add(res[i+1]);
                }

                a_sent.m_wLst.Add(w);
            }

            if (a_sent.m_wLst.Count > 0)
            {
                Lst.Add(a_sent);
            }

            int k =0;

            for (k = 0; k < Lst.Count; ++k)
            {
                if (k == 1311)
                {
                    int kkkkkkkk = 0;
                    kkkkkkkk++;
                }

                if (bgetRawSents)
                {
                    Lst[k].Write2File_RawSentence(sw);
                }
                else
                {
                    Lst[k].Write2File(sw);
                    sw.WriteLine("");
                }
                
            }

            sr.Dispose();
            sw.Dispose();
        }

        /*
         * 函数功能：从 CONLL2017的 train test dev 文件中 获得词性标注（POS）信息，保存成文件
         * 
         * 参数说明：无
         * 
         * 返回值：保存 POS 信息的文件
         * 
         */
        public void get_POS_from_train_dev_test_Dataset()
        {
            string sfilePathName_train = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-train.conllu";
            string sfilePathName_dev = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-dev.conllu";
            string sfilePathName_test = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-test.conllu";

            string sfilePathName_2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料2\vi-ud-train_POS.txt";

            get_POS_from_file(sfilePathName_train, sfilePathName_2Save);


        }

        /*
         * 函数功能：从文件中提取 词 性 信息
         * 
         * 参数说明：sFilePathName,数据来源的文件
         *           sFile2Save，保存的文件名
         *           
         * 返回值：一个文件，名为 sFile2Save
         * 
         */

        public void get_POS_from_file( string sFilePathName, string sFile2Save)
        {
            StreamReader sr = new StreamReader(sFilePathName, Encoding.UTF8);
            StreamWriter sw = new StreamWriter(sFile2Save, false, Encoding.UTF8);

            string sLine = "";

            List<A_POS_Sents> Lst = new List<A_POS_Sents>();

            A_POS_Sents a_sent = new A_POS_Sents();

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();





                if (!(isSegment_Line(sLine) && hasPosTag(sLine))) // 条件不成立，则 continue
                {
                    if (a_sent.m_wLst.Count > 0) // 句子里面有词
                    {
                        Lst.Add(a_sent);

                        a_sent = new A_POS_Sents();
                    }

                    continue;
                }

                // 包含 分词（标注信息）， 则进行 下面的处理
                string[] sp = { " ", "\t", "	" };
                string[] res = sLine.Trim().Split(sp, StringSplitOptions.RemoveEmptyEntries);

                A_Word_POS w = new A_Word_POS();
                w.m_sPos = res[res.Length - 7]; // 获得 词性标签的

                int i = 0;
                int cnt = (res.Length - 8) / 2;

                for (i = 0; i < cnt; ++i) // 获得被分割的单词
                {
                    w.m_cLst.Add(res[i + 1]);
                }

                a_sent.m_wLst.Add(w);
            }

            if (a_sent.m_wLst.Count > 0)
            {
                Lst.Add(a_sent);
            }

            int k = 0;

            for (k = 0; k < Lst.Count; ++k)
            {
                Lst[k].Write2File(sw);
                sw.WriteLine("");
            }

            sr.Dispose();
            sw.Dispose();
        }


    }
}
