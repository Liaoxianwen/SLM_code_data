﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ViWordAna
{
    /*
     * 类说明：用于表示 句子中的 一个单词 和它的 标签
     * 
     * **/
    class WordTagged
    {
        public WordTagged()
        {

        }

        public string m_sW   = null;  // 单词
        public string m_sTag = null;  // 标签
    }


    public class TestVi_jaistCorpus
    {
        public TestVi_jaistCorpus()
        {
        }

        /*
         * 函数功能：从jaist 数据集中，还原出句子，用于把关联词写入到数据库中去
         * 参数说明：无
         * 
         * 返回值：无
         * 
         */

        public void GetSentencesFromCorpus()
        {
            string sFilePathName = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料1\test1.iob2";
            string sFilePathName2Save = @"D:\C_Sharp_Proj\ViWordAna\Corpus\越南语分词语料1\trest1_sents.txt";
            StreamWriter sw = new StreamWriter(sFilePathName2Save, false,Encoding.UTF8);

            StreamReader sr = new StreamReader(sFilePathName);
            List<string> lst = new List<string>();
            string str = "";
            string aSentence = "";

            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();

                str = str.Trim();

                if (!str.Equals(""))
                {
                    aSentence += str + " ";
                }
                else
                {
                    lst.Add(aSentence);
                    aSentence = "";
                }
            }

            sr.Close();
            sr.Dispose();

            int i = 0;
            string[] sp = { "B_W","I_W","\tO"};


            for (i = 0; i < lst.Count; ++i)
            {
                string s = lst[i];

                s = s.Replace("B_W","");
                s = s.Replace("I_W","");
                s = s.Replace("\tO","");

                s = s.Replace("\t", "");

                sw.WriteLine(s);
            }

            sw.Close();
            sw.Dispose();
        }

        /*
         * 函数功能：把 jaist 数据集的 标签 改成 标准的 BMES
         * 参数说明：sFilePathName，路径 + 文件名。
         * 
         * 返回值：无
         * 
         */

        public void Convert_Tag_2_BMES( string sFilePathName,string sFilepathname2save )
        {
            StreamWriter sw = new StreamWriter(sFilepathname2save,false,Encoding.UTF8);
            int i = 0;
            List<WordsOFSentence> Lwordofsents = GetWordsFromCorpus(sFilePathName);

            for (i = 0; i < Lwordofsents.Count; ++i)
            {
                Lwordofsents[i].Write2File_Taged_BEMS(sw);
                sw.WriteLine();
            }

            sw.Dispose();
        }

        // 从语料库中加载分词
        public List<WordsOFSentence> GetWordsFromCorpus(string sFilePathName)
        {
            StreamReader sr = new StreamReader(sFilePathName);
            List<WordTagged> lst = new List<WordTagged>();
            string str = "";

            List<WordsOFSentence> Lwofs = new List<WordsOFSentence>();

            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();

                str = str.Trim();

                if (!str.Equals(""))
                {
                    WordTagged wt = ParseWordTaggedFromStr(str);
                    if(wt.m_sTag!=null && wt.m_sW!=null )
                    {
                        lst.Add(wt);
                    }
                }
                else
                {
                    WordsOFSentence wofs = GetWordOFSentenceFromWordTaggedList(lst);

                    Lwofs.Add(wofs);
                    lst.Clear();

                }
            }

            sr.Close();
            sr.Dispose();

            return Lwofs;
        }

        private WordsOFSentence GetWordOFSentenceFromWordTaggedList(List<WordTagged> Lwt)
        {
            WordsOFSentence wof = new WordsOFSentence();
            int i = 0;
            wordSeg ws = new wordSeg();

            for (i = 0; i < Lwt.Count; )
            {
                if (Lwt[i].m_sTag.Equals("B_W")) // 一个单词的开始
                {
                    viWord vw = new viWord();
                    //string[] A= ws.dowordSeg(Lwt[i].m_sW);
                    vw.m_sLst.Add(Lwt[i].m_sW);

                    i += 1;

                    while (i<Lwt.Count&&Lwt[i].m_sTag.Equals("I_W"))
                    {
                        vw.m_sLst.Add(Lwt[i].m_sW);
                        i += 1; // 别忘了 +1 
                    }
                    
                    wof.m_Lstwds.Add(vw);
          
                }
                else if (Lwt[i].m_sTag.Equals("O"))
                {
                    // 注意：有的是 O标签，但是也会是单词

                    viWord vw = new viWord();

                    vw.m_sLst.Add(Lwt[i].m_sW);

                    wof.m_Lstwds.Add(vw);
                   
                    i += 1;
                }
            }


            return wof;

        }

        // 从字符串中 解析 单词 和 标签
        /*
         * 函数功能：从一个字符串中解析出 单词 和 标签，例如：从“trình	I_W”中解析出 
         *           trình 和 I_W。
         *           
         * 参数说明：str，一个字符串，形如：trình	I_W
         * 
         * 返回值：一个结构体（单词，标签）
         * 
         * **/
        private WordTagged ParseWordTaggedFromStr( string str)
        {
            str = str.Trim();

            if(str.Equals(""))
            {
                return new WordTagged();
            }

            //str = str.ToLower();

            string[] sp = { "\t"," "};

            string[] A=str.Split(sp,StringSplitOptions.RemoveEmptyEntries);

            if(A.Length != 2)
            {
                return new WordTagged();
            }

            WordTagged wt = new WordTagged();

            wt.m_sW = A[0];
            wt.m_sTag = A[1];

            return wt;

        }

        /*
         * 函数功能：从VnTokenizer 的分词结果 xml 文件中 加载 分词 
         * 参数说明：sFilePathName，文件路径全名
         * 
         * 返回值：文件中包含的所有分词
         * **/

        public List<WordsOFSentence> GetWordsFrom_VnT_SpRes( string sFilePathName )
        {
            StreamReader sr = new StreamReader(sFilePathName);

            List<string> Lstr = new List<string>();
            string sLine = null;

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();
                if (!sLine.Trim().Equals(""))
                {
                    Lstr.Add(sLine);
                }
            }

            sr.Close();
            sr.Dispose();

            List<WordsOFSentence> Lwofs = new List<WordsOFSentence>();

            int i = 0;
            int FindSt = 0;

            int sentST = 0;
            int sentED = 0;

            for (i = 0; i < Lstr.Count; )
            {
                sentST = GetSentsSt(Lstr,FindSt);
                sentED = GetSentsEnd(Lstr, FindSt);

                if (sentST == -1 && sentED == -1)
                {
                    break;
                }

                WordsOFSentence wfs = Get_WordsOfSents(Lstr, sentST,sentED);

                Lwofs.Add(wfs);

                FindSt = sentED + 1; // 从下一个位置开始查找

            }

            return Lwofs;
        }


        /*
         * 函数功能：加载一个文件，以句子为单位读取词
         *           只能对以 “///////”进行行 分隔的文本进行读取
         *           
         *           过滤掉了 数字，符号，“A5520SA” 也会被拆分， 从Vntokenizer的结果中读取时，也进行相同的操作，所以不影响比较结果
         * 
         * 
         * 参数说明：sFileName，文件名
         * 返回值：句子列表
         * 
         */

        public List<WordsOFSentence> GetWordsFromFile_OurApproach(string sFileName)
        {
            List<WordsOFSentence> lst = new List<WordsOFSentence>();

            int i = 0;
            string sLine = null;
            List<string> Lstr = new List<string>();

            StreamReader sr = new StreamReader(sFileName);
            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();
                Lstr.Add(sLine);
            }

            sr.Close();
            sr.Dispose();

            int SentsBeg = 0;
            int SentsEnd = 0;
            int j = 0;

            for (i = 0; i < Lstr.Count; )
            {
                if (Lstr[i].IndexOf("/////") >= 0)
                {
                    WordsOFSentence wofs = new WordsOFSentence();
                    SentsBeg = i + 1;
                    SentsEnd = GetNextSentsBeg_OurApproach(i, Lstr);

                    for (j = SentsBeg; j < SentsEnd; ++j)
                    {
                        viWord vw = GetWordFromString_OurApproach(Lstr[j]);

                        if (vw.m_sLst.Count > 0)
                        {
                            wofs.m_Lstwds.Add(vw);
                        }
                    }

                    i = SentsEnd;

                    lst.Add(wofs);

                }
            }

            return lst;
        }

        /*
         * 函数功能：从一个字符串中提取 一个 词
         * 参数说明：str，一个字符串
         * 返回值：一个词
         * 
         */

        private viWord GetWordFromString_OurApproach(string str)
        {
            viWord vw = new viWord();

            wordSeg ws = new wordSeg();

            string[] A = ws.dowordSeg(str);

            int i = 0;

            for (i = 0; i < A.Length; ++i)
            {
                vw.m_sLst.Add(A[i].ToLower());
            }

            return vw;
        }

        /*
         * 函数功能：找到下一个 句子开始的位置
         * 参数说明：currIndx，当前句子分隔符的位置
         *           L，列表L
         *           
         * 返回值：下一个句子分隔符开始的位置
         * 
         * **/

        private int GetNextSentsBeg_OurApproach(int currIndx, List<string> L)
        {
            int i = 0;

            for (i = currIndx + 1; i < L.Count; ++i)
            {
                if (L[i].IndexOf("/////") >= 0) // 找到了
                {
                    return i;
                }
            }

            return i;

        }


        // 获得 一个句子，包括所有的分词
        public WordsOFSentence Get_WordsOfSents(List<string> L,int st,int ed )
        {
            int i = 0;

            WordsOFSentence wos = new WordsOFSentence();

            for (i = st; i < ed; ++i)
            {
                viWord vw = Get_ViWord(L[i]);

                if (vw.m_sLst.Count > 0)
                {
                    wos.m_Lstwds.Add(vw);
                }
            }

            return wos;

        }

        // 从字符串 str 中提取出越南语单词，过滤掉 数字 和 其他 符号
        public viWord Get_ViWord(string str)
        {
            viWord vw = new viWord();

            if (str.IndexOf("<w pos=") >= 0)
            {
                int contentST = str.IndexOf("\">")+2;
                int contentED = str.IndexOf("</w>");

                string substr = str.Substring(contentST,contentED-contentST);

                wordSeg ws = new wordSeg();
                string[] A = ws.dowordSeg(substr); // 实际上 把数字 和 符号都过滤掉了 

                int i = 0;

                for (i = 0; i < A.Length; ++i)
                {
                    vw.m_sLst.Add(A[i]);
                }
            }

            return vw;
        }

        // 获取 句子的开始 indx
        private int GetSentsSt( List<string> L,int FindST)
        {
            int i = 0;

            for (i = FindST; i < L.Count; ++i)
            {
                if (L[i].IndexOf("<s>") >= 0)
                {
                    return i;
                }
            }

            return -1;
        }

        // 获取 句子的结束 indx
        private int GetSentsEnd(List<string> L, int FindST)
        {
            int i = 0;

            for (i = FindST; i < L.Count; ++i)
            {
                if (L[i].IndexOf("</s>") >= 0)
                {
                    return i;
                }
            }

            return -1;
        }

    }
}
