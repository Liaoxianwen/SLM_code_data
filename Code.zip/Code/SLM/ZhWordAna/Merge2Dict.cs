﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;

namespace ZhWordAna
{
    /*
     * 类功能说明：合并 两个 字典 
     *             把 微博的字典 和 中文维基百科的 字典 合并起来，形成一个大的基准字典
     * 
     */
    public class Merge2Dict
    {
        public Merge2Dict()
        {
        }

        public void doMerge2Dict( string sDict1, string sDict2)
        {
            ChStatics cs_weibo = new ChStatics();
            cs_weibo.LoadWordDictionary("ZhWordsBase.txt");

            ChStatics cs_wiki = new ChStatics();
            cs_wiki.LoadWordDictionary("ZhWikiWords.txt");

            Dictionary<char, int>  TotalDic = new Dictionary<char, int>();

            Dictionary<char, int> weiboDic = cs_weibo.m_WordDic;
            Dictionary<char, int> wikiDic = cs_wiki.m_WordDic;

            int i = 0;

            // 把维基百科的字典 搬过来（去掉重复的了）
            for (i = 0; i < wikiDic.Count; ++i)
            {
                KeyValuePair<char, int> kp = wikiDic.ElementAt(i);

                if (!TotalDic.ContainsKey(kp.Key))
                {
                    TotalDic[kp.Key] = -1;
                    TotalDic[kp.Key] = TotalDic.Count - 1;
                }
            }

            // 把微博的字典 搬过来 （去掉重复的了）
            for (i = 0; i < weiboDic.Count; ++i)
            {
                KeyValuePair<char, int> kp = weiboDic.ElementAt(i);

                if (!TotalDic.ContainsKey(kp.Key))
                {
                    TotalDic[kp.Key] = -1;
                    TotalDic[kp.Key] = TotalDic.Count - 1;
                }
            }

           // -----------------保存起来 ---------------

            StreamWriter sw = new StreamWriter("TotalDic.txt", false);

            for (i = 0; i < TotalDic.Count; ++i)
            {
                KeyValuePair<char, int> kp = TotalDic.ElementAt(i);
                sw.WriteLine(kp.Key + ":" + kp.Value.ToString() + ",111");
            }

            // 必须释放资源
            sw.Close();
            sw.Dispose();


        }
    }
}
