﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ZhWordAna
{
    public class ChStatics
    {
        public ChStatics()
        {
            DirectoryInfo root = new DirectoryInfo(m_sPath);
            m_files = root.GetFiles();
        }


        /*
         * 函数功能：统计 中文维基百科的字符，并生成中文维基百科字典
         * 参数说明：无
         * 
         * 返回值:无
         * 
         */
        public void CharStatics()
        {

            if (m_files == null || m_files.Length == 0)
            {
                MessageBox.Show("语料库文件为空或者 没有预料文件！");
                return;
            }

            int i = 0;
            for (i = 0; i < m_files.Length; ++i)
            {
                //StreamReader sr = m_files[i].OpenText();
                // FileStream fs = m_files[i].OpenRead();
                StreamReader sr = null;
                try
                {

                    sr = new StreamReader(m_files[i].FullName, Encoding.UTF8);// 奇怪
                    string str = "";
                    while (!sr.EndOfStream)
                    {

                        try
                        {
                            str = sr.ReadLine();
                        }
                        catch (System.Text.EncoderFallbackException se)
                        {
                            MessageBox.Show(se.ToString() + " 111 " + str);
                        }

                        try
                        {
                            StatWords(str);
                        }
                        catch (System.Text.EncoderFallbackException se)
                        {
                            MessageBox.Show(se.ToString() + " 22+" + str);
                        }
                    }

                }
                catch
                {
                    MessageBox.Show("error");
                }

                //  必须要释放资源，否则造成资源占用导致其他进程无法写入或删除
                sr.Close();
                sr.Dispose();
            }

            // 把词频按降序保存再文件中
            StreamWriter sw = new StreamWriter("ZhWikiWords.txt", false,Encoding.UTF8);
            Dictionary<char, emergeTimes> dic1_SortedByVal = m_DWordIndx.OrderByDescending(o => o.Value.m_Cnt).ToDictionary(p => p.Key, o => o.Value);


            for (i = 0; i < dic1_SortedByVal.Count; ++i)
            {
              //  try
                {
                    KeyValuePair<char, emergeTimes> kp = dic1_SortedByVal.ElementAt(i);
                    sw.WriteLine(kp.Key + ":" + kp.Value.m_Indx.ToString() + "," + kp.Value.m_Cnt.ToString());
                }
               // catch (SystemException se)
                {
                //    MessageBox.Show("MBBB");
                }
            }



            // 必须释放资源

            try
            {
                sw.Close();
                sw.Dispose();
            }
            catch
            {
                MessageBox.Show("保存的时候出错了！！！ ");
            }

        }

        /*
        * 函数功能：对一个字符串中出现的字符进行统计
        * 参数说明：str，一个待统计字符的字符串
        * 返回值：无
        * 
        */
        private void StatWords(string str)
        {
            int i = 0;

            if (str == null || str.Length == 0)
            {
                return;
            }

            try
            {

                for (i = 0; i < str.Length; ++i)
                {
                    // 如果之前已经发现了 存在一个字 ,出现的次数 + 1

                    if (m_DWordIndx.ContainsKey(str[i]))
                    {
                        m_DWordIndx[str[i]].m_Cnt++;
                        continue;
                    }

                    emergeTimes et = new emergeTimes();
                    et.m_Cnt = 1;  // 新出现的单词，出现1次
                    et.m_Indx = (UInt32)m_DWordIndx.Count;  // 单词在出现序列的下标，第1次是0，第2次是1

                    m_DWordIndx[str[i]] = et;
                }
            }
            catch (System.Text.EncoderFallbackException se)
            {
                MessageBox.Show(se.ToString() + "  " + str);
            }
        }

        /*
         * 函数功能：统计一个文件中 有多少个不同的字符
         * 参数说明：sFilePathName，文件路径 + 文件名
         * 
         * 返回值：字符字典
         * 
         * **/

        private Dictionary<char, emergeTimes> GetCharInFile(string sFilePathName)
        {
            m_DWordIndx.Clear();

            StreamReader sr = null;

            sr = new StreamReader(sFilePathName, Encoding.Default);// 奇怪，必须用default ，用 utf8 或者 unicode 都乱码！！
            string str = "";
            while (!sr.EndOfStream)
            {
                try
                {
                    str = sr.ReadLine();
                }
                catch (System.Text.EncoderFallbackException se)
                {
                    MessageBox.Show(se.ToString() + " 从文件读一行时出错！！" + str);
                }

                try
                {
                    StatWords(str);
                }
                catch (System.Text.EncoderFallbackException se)
                {
                    MessageBox.Show(se.ToString() + " 统计字符时 出错 " + str);
                }
            }

            //  必须要释放资源，否则造成资源占用导致其他进程无法写入或删除
            sr.Close();
            sr.Dispose();



            return m_DWordIndx;

        }

        /*
          * 函数功能：加载微博字典， 需要显式 调用该函数
          * 参数说明：无
          * 返回值：无
          * 
          */
        public void LoadWordDictionary(string sDictFileName )
        {
            m_WordDic = new Dictionary<char, int>();

            StreamReader sr = new StreamReader(sDictFileName);        // 不要应编码
            //StreamReader sr = new StreamReader("ZhWordsBase.txt");
            //StreamReader sr = new StreamReader("ttwb.txt");
            string[] sp = { ":", "," };
            int i = 0;

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] sA = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);
                string sWord = sA[0];

                if (s[0] == ':' || s[0] == ',')
                {
                    sWord = s.Substring(0, 1);
                }
                else if (sWord.Length != 1)
                {
                    MessageBox.Show("有异常发生！加载字典的时候，得到长度大于1的字符串！！");
                }

                if (m_WordDic.ContainsKey(sWord[0])) // 处理 黑色菱形 问号的情况
                {
                    continue; // 黑色菱形不管出现多少次，只记录第一次的索引。其他字（key）的相对位置不变，那么索引不会乱
                              // 这个代码块在 合并 维基字典 和 微博字典的时候，会起作用
                              // 维基字典当中有很多 黑色的菱形，这些黑色的菱形是从维基文本中抽取出字 然后保存成字典时产生的，不知道为什么
                              // 变成黑色菱形的这些字，在入库时变成了陌生字（因为在字符串中 这些字不是黑色菱形）


                }

                m_WordDic[sWord[0]] = -1;  // 相当于把这个字添加到字典中去，但是字的下标还没添加
                m_WordDic[sWord[0]] = m_WordDic.Count - 1; // 数组的下标，方便再关联矩阵中进行索引

            }

            sr.Close();
            sr.Dispose();
        }


        /*
         * 函数功能：把待处理的文件中的新字（原来字典中不存在的字） 添加到微博字典中
         * 参数说明：sFilePathName，待处理文件的 路径 + 文件名 
         * 
         * 返回值：无
         *
         */

        public void AddChar2Dictionary(string sFilePathName )
        {
            Dictionary<char, emergeTimes> dict = GetCharInFile(sFilePathName );

            // 加载之前的微博字典
            LoadWordDictionary("ZhWordsBase.txt");

            List<char> lst = new List<char>();
            int i = 0;

            for (i = 0; i < dict.Count; ++i)
            {
                KeyValuePair<char, emergeTimes> kp = dict.ElementAt(i);

                if (!m_WordDic.ContainsKey(kp.Key))
                {
                    lst.Add(kp.Key);
                }
            }

            // 把新发现的字添加到 微博字典文件中
            AddNewWord2DictFile(lst);

            // 重新加载微博字典
            LoadWordDictionary("ZhWordsBase.txt");

        }

        /*
         * 函数功能：把（原来微博字典中不存在的）新发现的 字 添加到 微博字典中
         *           微博字典的 名称 采用 硬编码
         *           
         *           动态扩充字典的用途：在分词过程中可能会 遇到新的字，把新的字添加到字典，处理OOV的情况
         * 
         * 参数说明：lst 新发现的字的列表
         * 
         * 返回值：无
         */

        private void AddNewWord2DictFile(List<char> lst)
        {
            StreamWriter sw = new StreamWriter("ZhWordsBase.txt", true);

            int i = 0;

            for (i = 0; i < lst.Count; ++i)
            {
                sw.WriteLine(lst[i]+":5678,1");
            }

            sw.Close();
            sw.Dispose();

        }


        public FileInfo[] m_files = null;
        private Dictionary<char, emergeTimes> m_DWordIndx = new Dictionary<char, emergeTimes>(); // 过程统计
        private string m_sPath = @"D:\C_Sharp_Proj\ViWordAna\zhWiki";

        public Dictionary<char, int> m_WordDic = null; // 字典，存储的是单词的索引，即 单词i：i，这样在数据库种存储索引即可
    }
}
