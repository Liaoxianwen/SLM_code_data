﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZhWordAna
{
    public class CalcAvgLR_IE
    {
        public CalcAvgLR_IE(DBConn db, Dictionary<char, int> worddic)
        {
            m_WordDic = worddic;
            m_db = db;
            // 类初始化
        }

        /*
         * 函数功能：计算一个可行分词的 左右信息熵 之差的 平均
         * 参数说明：str，原始字符串
         *           bL,用 0，1 表示的可行分词
         * 返回值：左右信息熵之差的平均           
         */

        public Decimal CalcAvg_IE(string str, UInt32[] bL)
        {
            int i = 0;
            List<string> Words = GetWords(str, bL);

            Decimal sumEnt = 0;
            int ActualCnt = 0;

            for (i = 0; i < Words.Count-1; ++i)
            {
                if (GetOccurencesInDB(Words[i], Words[i + 1]) > m_LowFreqValve)
                {
                    ActualCnt++;
                    sumEnt += GetDeltaIE(Words[i], Words[i + 1]);
                }
            }

            return sumEnt / ((Decimal)ActualCnt+1);
          
        }

        /*
         * 函数功能：获取两个候选词之间的 信息熵 之差
         * 参数说明：word1，前一个候选词
         *           word2，后一个候选词
         * 返回值：前一个词的右信息熵 后一个词的左信息熵 之差
         *
         */
        public Decimal GetDeltaIE(string word1, string word2)
        {
            string word = word1 + word2;

            if (m_HisLRIE.ContainsKey(word))
            {
                return m_HisLRIE[word];
            }

            Decimal dREnt = Get_IE_Right(word1);
            Decimal dLEnt = Get_IE_Left(word2);

            //Decimal val = Math.Abs(dREnt + dLEnt);
            Decimal val = Math.Max(dREnt , dLEnt);

            m_HisLRIE[word] = val;

            return val;
        }

        /*
         * 函数功能：获取一个词的左信息熵
         * 参数说明：word2，候选词
         * 返回值：左信息熵
         *
         */
        private Decimal Get_IE_Left(string word2)
        {
            int[] index = new int[word2.Length];
            int i = 0;

            for (i = 0; i < word2.Length; ++i)
            {
                index[i] = m_WordDic[word2[i]];
            }

            List<int> iLst = m_db.Get_Left_AdjNum(index);

            double sum = 0;

            for (i = 0; i < iLst.Count; ++i)
            {
                sum += (double)iLst[i];
            }

            double ent = 0;

            for (i = 0; i < iLst.Count; ++i)
            {
                double p = iLst[i] / sum;
                ent += 0 - p * Math.Log10(p);
            }

            return (Decimal)ent;
        }

        /*
         * 函数功能：获取一个词的右信息熵
         * 参数说明：word1，候选词
         * 返回值：右信息熵
         *
         */
        private Decimal Get_IE_Right(string word1)
        {
            int[] index = new int[word1.Length];
            int i = 0;

            for (i = 0; i < word1.Length; ++i)
            {
                index[i] = m_WordDic[word1[i]];
            }

            List<int> iLst = m_db.Get_Right_AdjNum(index);

            double sum = 0;

            for (i = 0; i < iLst.Count; ++i)
            {
                sum += (double)iLst[i];
            }

            double ent = 0;

            for (i = 0; i < iLst.Count; ++i)
            {
                double p = iLst[i] / sum;
                ent += 0 - p * Math.Log10(p);
            }

            return (Decimal)ent;
        }

        /*
         * 函数功能：根据 bL的分段标志 从str 中获取候选 词
         * 参数说明：str,待分词的 字符串
         * 返回值：候选词 集合 
         **/

        private List<string> GetWords(string str, UInt32[] bL)
        {
            int i = 0;
            List<string> Lrt = new List<string>();

            int j = 0;
            int subLen = 0;

            for (i = 0; i < bL.Length; )
            {
                if (bL[i] == 1)
                {
                    j = i;
                    subLen = 0;
                    while (j < bL.Length)
                    {
                        subLen++;
                        j++;

                        if (j >= bL.Length || bL[j] == 1) // 遇到下一个子串开始的地方 ，
                        {
                            break;
                        }
                    }

                    string substr = str.Substring(i, subLen);
                    Lrt.Add(substr);

                    i = j; // i 往前移动
                }
            }

            return Lrt;
        }


        /*
         * 函数功能：获取虚拟词串 word= Word1+Words2 在数据库中出现的次数。
         * 参数说明：Word1，可行分词1
         *           Word2，可行分词2
         *           
         * 返回值：虚拟词串 word 在数据库中出现的次数。 
         */

        public int GetOccurencesInDB(string Word1, string Word2)
        {
            string word = Word1 + Word2;

            if (word.Length >8 )
            {
                return 0;
            }

            if (m_HisWordNumInDB.ContainsKey(word))
            {
                return m_HisWordNumInDB[word];
            }

            int[] index = new int[word.Length];
            int i = 0;

            for (i = 0; i < word.Length; ++i)
            {
                index[i] = m_WordDic[word[i]];
            }

            int Num = m_db.GetWordNumFromDB(index, word.Length);

            m_HisWordNumInDB[word] = Num;

            return Num;
        }


        ///////// Attributes //////////

        private DBConn m_db;

        public Dictionary<char, int> m_WordDic = null; // 字典，存储的是单词的索引，即 单词i：i，这样在数据库种存储索引即可

        public int m_LowFreqValve = 5;

        public Dictionary<string, int> m_HisWordNumInDB = new Dictionary<string,int>();

        public Dictionary<string, Decimal> m_HisLRIE = new Dictionary<string, Decimal>();


    }
}
