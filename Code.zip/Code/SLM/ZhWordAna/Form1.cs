﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace ZhWordAna
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /*
         * 函数功能：单纯统计中文字符
         * 参数说明：无
         * 返回值：无
         * **/
        private void m_btnCharStatics_Click(object sender, EventArgs e)
        {

            DateTime dBeg = System.DateTime.Now;
            WeiBoCorpus wbc = new WeiBoCorpus();

            wbc.CharStatics();

            DateTime dEnd = System.DateTime.Now;
            TimeSpan ts = dEnd - dBeg;

            MessageBox.Show("语料库字符统计完成！！"+ "共耗时：" + ts.ToString());
        }


        /*
         * 函数功能：把中文微博的 1到 8阶 关联词 输入到数据库
         * 参数说明：无
         * 返回值：无
         *
         */

        private void button1_Click(object sender, EventArgs e)
        {
            return;

            WeiBoCorpus wbc = new WeiBoCorpus();
            wbc.LoadWordDictionary();
            wbc.WriteCoExist2DB();

        }


        // 八阶分词响应 函数
        private void m_btn8Split_Click(object sender, EventArgs e)
        {
            //string str = "子电林桂是一所很好的学校，老师、学生的水平都很高";
            //string str = "会上习总书记提出了新要求。";
            string str = "开始忙碌着布置开馆仪式现场";
            //string str = "我们周末相约桂林栞烧烤";
            //string str = "子电林桂是一个很好的学校，老师、学生的水平都很高";//栞栞栞栞栞栞栞栞栞栞栞";
            //string str = "人工智能";//网络新词旧丝H妹是一款游戏的名字。
            //string str = "Bạn đã nghe việc ngồi một chỗ có thể cướp đi tính mạng của chúng ta chưa";
            //string str = "Các ngôi sao sáng giá nhất đang thi đấu ở nước ngoài như Chanathip hay Dangda đều được HLV Rajevac gọi về";//giúp cô gái Ê đê

            //string str = " tràn đầy năng lượng và sự tự tin giúp cô gái Ê đê ghi dấu ấn ở cuộc thi nhan sắc quốc tế";

            //string str = "tràn đầy năng lượng ";

            //string str = "và  sự  tự  tin";

            //string str = "việc ngồi";

           
            //wco.ReadWordCoExistArr(); // 读取2阶关联矩阵

            ChStatics cs = new ChStatics();
            cs.AddChar2Dictionary(@"D:\C_Sharp_Proj\ViWordAna\ZhWordAna\WeiboCorpus_newWordDetection\子电林桂.txt");

            Delta2DB d2db = new Delta2DB();
            d2db.m_WordDic = cs.m_WordDic;

            int[]DelataAssWordNum=d2db.Write2DeltaDB(@"D:\C_Sharp_Proj\ViWordAna\ZhWordAna\WeiboCorpus_newWordDetection\子电林桂.txt");

            DBConn db = new DBConn();

            CalcProbCond cpc = new CalcProbCond(db,cs.m_WordDic);

            CalcAvgLR_IE calrie = new CalcAvgLR_IE(db, cs.m_WordDic);


            cpc.UpdateWordNum(1, DelataAssWordNum);
          
            SplitSents sps = new SplitSents(cpc, str,calrie);

            sps.doSplit(str);

            MessageBox.Show("6阶分词完成！");
        }

        /*
         * 函数功能：中文维基百科 字符统计
         * 参数说明：无 
         * 返回值：无 
         */
        private void m_btnStaticWikiw_Click(object sender, EventArgs e)
        {
            ChStatics cs = new ChStatics(); // 在构造函数中设置了 维基文本文件的 路径，
            cs.CharStatics();
        }


        /// 测试 按钮 响应 函数 
        private void m_btnTest_Click(object sender, EventArgs e)
        {
            //ZHOOVStatics zhvss = new ZHOOVStatics();

           // zhvss.Calc_P_R_F_oov();

             // SplitSentsByNum_DateTime ssdt = new SplitSentsByNum_DateTime();
             // string str = "二００一年一月一日";

             // ssdt.RSplit(str);

           // return;

            //SplitChineseFile scf = new SplitChineseFile("msr_original.txt");

            //scf.Split2ShortSents();

            //ProcCWSMaster pcm = new ProcCWSMaster();
            //pcm.dismissBlank();


       

            

            SplitSentsByNum_DateTime ssbd = new SplitSentsByNum_DateTime();

            ssbd.PreSplit(@"D:\C_Sharp_Proj\ViWordAna\pku\CWS-Master\msr\msr_dev__shortSents4StatisticalSeg",
                          @"D:\C_Sharp_Proj\ViWordAna\pku\CWS-Master\msr\msr_dev__shortSents4StatisticalSeg_PresplitSents");
             
              //对文件使用 规则 进行 预分词
             



        }

        private void strtest( string ss)
        {
            ss = "";
        }

        private void m_btnWiki2DB_Click(object sender, EventArgs e)
        {
            ZhWikiCorpus zhwc = new ZhWikiCorpus();

            zhwc.m_tbProgress = m_tbWriteInProgress;
            zhwc.m_dataDir = m_dataDir.Text;

            zhwc.m_isTbl4 = m_rb4.Checked;
            zhwc.m_isTbl5 = m_rb5.Checked;
            zhwc.m_isTbl6 = m_rb6.Checked;
            zhwc.m_isTbl7 = m_rb7.Checked;
            zhwc.m_isTbl8 = m_rb8.Checked;
            zhwc.m_btn = m_btnWiki2DB;

            Thread th = new Thread(zhwc.WriteCoExist2DB);

            th.Start();

            m_btnWiki2DB.Enabled = false;

            //zhwc.WriteCoExist2DB();
        }

        // 中文文件分词的 响应 
        private void m_btnZhFileSplit_Click(object sender, EventArgs e)
        {
            //string str = "中华人民共和国国徽高高挂在那座两层办公楼的大门之上";
            /*string str = "他与记者谈话也是直来直去";

            TotalDictionary TDict = new TotalDictionary("TotalDicBase.txt");

            DBConn db = new DBConn();

            CalcProbCond cpc = new CalcProbCond(db, TDict.m_WordDic);

            CalcAvgLR_IE calrie_noUse = new CalcAvgLR_IE(db, TDict.m_WordDic);

            int[] PKUAssWordNum = {1643853,1641943,1640033,1638123,1636213,1634303, 1632393, 1630483 };

            cpc.UpdateWordNum(1910, PKUAssWordNum);

            SplitSents sps = new SplitSents(cpc, str, calrie_noUse);

            sps.doSplit(str);

            return;

            CalcOptimalSplit cos = new CalcOptimalSplit(str,sps);

            OptRes opres= cos.CalcOptimal();

            opres.Write2File("递归分词结果.txt",str);

            MessageBox.Show("6阶分词完成！");

            
            return;*/

            SplitChineseFile scf = new SplitChineseFile("短句_msr_original.txt");

            scf.m_tbInfo = m_tbWriteInProgress;

            scf.SplitFiles();

            Thread th = new Thread(scf.SplitFiles);

            //th.Start();



        }

        private void m_btnPKU2DB_Click(object sender, EventArgs e)
        {
            ZhWikiCorpus zhwc = new ZhWikiCorpus();

            zhwc.m_tbProgress = m_tbWriteInProgress;
            zhwc.m_dataDir = m_dataDir.Text;

            zhwc.m_isTbl4 = m_rb4.Checked;
            zhwc.m_isTbl5 = m_rb5.Checked;
            zhwc.m_isTbl6 = m_rb6.Checked;
            zhwc.m_isTbl7 = m_rb7.Checked;
            zhwc.m_isTbl8 = m_rb8.Checked;
            zhwc.m_btn = m_btnWiki2DB;

            zhwc.StatistNewWord("pku_original.txt");

            //zhwc.WriteCoExist2DB();

            Thread th = new Thread(zhwc.WriteCoExist2DB);

           // th.Start();

            m_btnWiki2DB.Enabled = false;
        }

        private void m_btnMSR2DB_Click(object sender, EventArgs e)
        {
            ZhWikiCorpus zhwc = new ZhWikiCorpus();

            zhwc.m_tbProgress = m_tbWriteInProgress;
            zhwc.m_dataDir = m_dataDir.Text;
            zhwc.m_btn = m_btnMSR2DB;

            //zhwc.StatistNewWord("msr_original.txt");

           

            //zhwc.WriteCoExist2DB();

            Thread th = new Thread(zhwc.WriteCoExist2DB);

            //th.Start();

            m_btnMSR2DB.Enabled = false;
        }

        private void m_btnPKUTest2DB_Click(object sender, EventArgs e)
        {
            ZhWikiCorpus zhwc = new ZhWikiCorpus();

            zhwc.m_tbProgress = m_tbWriteInProgress;
            zhwc.m_dataDir = m_dataDir.Text;
            zhwc.m_btn = m_btnMSR2DB;

            //zhwc.StatistNewWord(@"D:\C_Sharp_Proj\ViWordAna\pku\pku_test_original.txt");


            // zhwc.WriteCoExist2DB();

            Thread th = new Thread(zhwc.WriteCoExist2DB);

            th.Start();

            m_btnMSR2DB.Enabled = false;
        }

        private void m_btnPKUMSRMaster2DB_Click(object sender, EventArgs e)
        {
            ZhWikiCorpus zhwc = new ZhWikiCorpus();

            zhwc.m_tbProgress = m_tbWriteInProgress;
            zhwc.m_dataDir = m_dataDir.Text;
            zhwc.m_btn = m_btnPKUMSRCWSMaster;

           // zhwc.StatistNewWord("msr_original.txt");



            //zhwc.WriteCoExist2DB();

            Thread th = new Thread(zhwc.WriteCoExist2DB);

            //th.Start();

            m_btnPKUMSRCWSMaster.Enabled = false;
        }
    }

    public class FeasibleResult : IComparable<FeasibleResult>
    {
        public FeasibleResult()
        {

        }

        public int CompareTo(FeasibleResult other)
        {
            if (this.m_Prob > other.m_Prob)
            {
                return -1;
            }

            return 1;
        }

        public double m_Prob;
        public UInt32[] m_BL;
    }
}
