﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ZhWordAna
{

    /*
     * 类使用说明：去掉空格，训练集 入库时 ，做的 处理
     * 
     */


    public class ProcCWSMaster
    {
        public ProcCWSMaster()
        {
        }

        public void dismissBlank()
        {
            string sDir = @"D:\C_Sharp_Proj\ViWordAna\CWSMaster\";

            StreamReader sr = new StreamReader(sDir + "msr_test", Encoding.UTF8);
            StreamWriter sw = new StreamWriter(sDir + "msr_test_2DB");

            string ss = "";
            string sold = " ";

            while (!sr.EndOfStream)
            {
                ss = sr.ReadLine();

                ss = ss.Replace(sold, "");

                sw.WriteLine(ss);
            }

            sr.Dispose();
            sw.Dispose();


        }
    }
}
