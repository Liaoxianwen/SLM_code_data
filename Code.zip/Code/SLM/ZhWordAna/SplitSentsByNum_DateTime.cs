﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ZhWordAna
{
    /*
     * 类说明：用规则 把数字（包括百分数） 日期 拆分 
     * 
     */

    // 字符的类型
    public enum CharType
    {
        OTHER = -1,  // 其他
        DIGIT = 0,   // 数字
        DIGIT_ZH,    // 中文数字
        UNIT,        // 单位
        DOT,         // 点
        PERCNT,      // 百分号
        VS,          // 比，如 88：78
        YEAR,        // 年
        MONTH,       // 月
        DAY,         // 日
        HOUR,        // 时
        MINUITE,     // 分
        SECOND       // 秒
    };

    // 句子类型
    public enum StringType 
    { 
        NONE = 1,  // 正常的字符串
        REXP       // 规则字符串
    };

    // 类说明，用于存储拆分的结果
    public class RSplitRes
    {
        public string m_str;          // 字符串
        public StringType m_strType;  // 字符串类型

        /*
         * 函数功能：获取字符串类型
         * 参数说明：无
         * 返回值：类型字符串
         */
        public string GetType()
        {
            if (m_strType == StringType.NONE)
            {
                return "NONE";
            }
            else if (m_strType == StringType.REXP)
            {
                return "__R_";
            }
            else
            {
                return "OTHER";
            }
        }
    }

    /*
     * 类说明：数字字符串 类
     * 
     *
     */
    public class digitsStr
    {
        public int m_st = -1; // 起始位置
        public int m_ed = -1; // 终止位置

        public CharType m_CT = CharType.OTHER;

        // 获取数字串
        public string GetStr(string sOriginal)
        {
            return sOriginal.Substring(m_st, m_ed - m_st);
        }
    }

    /*
     * 类说明：把时间、日期字符串 拆分开
     */
    public class SplitSentsByNum_DateTime
    {
        public SplitSentsByNum_DateTime()
        {
        }

        /*
         * 函数功能： 对字符串进行拆分
         * 参数说明：字符串
         * 返回值：拆分结果
         */
        public List<RSplitRes> RSplit(string str)
        {
            List<RSplitRes> Lrt = new List<RSplitRes>();
            List<digitsStr> Ltmp = GetDigitsStr(str);

            DeleteInValidRexp(Ltmp,str);

            if (Ltmp.Count == 0)
            {
                RSplitRes rsr = new RSplitRes();
                rsr.m_str = str;
                rsr.m_strType = StringType.NONE;

                Lrt.Add(rsr);

                //Save(Lrt, str);

                return Lrt;
            }

            int i = 0;

            if (Ltmp[0].m_st > 0)
            {
                RSplitRes r = new RSplitRes();
                r.m_str = str.Substring(0, Ltmp[0].m_st); // 
                r.m_strType = StringType.NONE;
                Lrt.Add(r);
            }

            for (i = 0; i < Ltmp.Count - 1; ++i)
            {
                RSplitRes r = new RSplitRes();
                r.m_str = str.Substring(Ltmp[i].m_st, Ltmp[i].m_ed - Ltmp[i].m_st); // 
                r.m_strType = StringType.REXP;
                Lrt.Add(r);

                if (Ltmp[i + 1].m_st - Ltmp[i].m_ed > 0)
                {
                    RSplitRes r1 = new RSplitRes();
                    r1.m_str = str.Substring(Ltmp[i].m_ed, Ltmp[i + 1].m_st - Ltmp[i].m_ed); // 
                    r1.m_strType = StringType.NONE;
                    Lrt.Add(r1);
                }

            }

            RSplitRes rf = new RSplitRes();
            rf.m_str = str.Substring(Ltmp[i].m_st, Ltmp[i].m_ed - Ltmp[i].m_st); // 
            rf.m_strType = StringType.REXP;
            Lrt.Add(rf);


            if (str.Length - Ltmp[i].m_ed > 0)
            {
                RSplitRes r2 = new RSplitRes();
                r2.m_str = str.Substring(Ltmp[i].m_ed, str.Length - Ltmp[i].m_ed); // 
                r2.m_strType = StringType.NONE;
                Lrt.Add(r2);
            }

            //Save(Lrt,str);

            return Lrt;
        }

        // 函数功能：对文件进行规则拆分，然后保存成文件
        public void PreSplit( string file2split, string content2save)
        {
            StreamReader sr = new StreamReader(file2split);
            StreamWriter sw = new StreamWriter(content2save);
            string str = null;
            int indx = 0;

            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();
                List<RSplitRes> Lrt = RSplit(str);

                Save(sw, Lrt, ++indx);
            }

            sr.Close();
            sw.Close();

        }

        public void GenerateFinalFile(string fromFile,string toFile )
        {
            StreamReader sr = new StreamReader(fromFile);
            StreamWriter sw = new StreamWriter(toFile);
            string str = null;

            string aLine = "";

            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();

                if (NoUseLine(str))
                {
                    if (aLine.Length > 0)
                    {
                        sw.WriteLine(aLine.Trim());
                    }

                    aLine = "";
                }
                else
                {
                    aLine =aLine+"  "+ str.Trim();
                }
            }

            sw.WriteLine(aLine.Trim());

            sr.Dispose();
            sw.Dispose();
        }

        private bool NoUseLine( string sLine)
        {
            int ipos = sLine.IndexOf(">>:");

            if (ipos > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void RestorePresplitSents_From_RexpSplit(string presplitfile,string tofile)
        {
            StreamReader sr = new StreamReader(presplitfile);
            StreamWriter sw = new StreamWriter(tofile); 
            string str = null;

            string sPreLineNum = "-1";
            string currLineno = "";

            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();

                if (isNone_line(str))
                {
                    currLineno = GetOriginalLineNum(str);

                    if (currLineno.Equals(sPreLineNum))
                    {

                    }
                    else
                    {

                        sPreLineNum = currLineno;
                        sw.WriteLine(">>" + sPreLineNum + ">>:");
                    }
                }
                else if (isREXP_line(str))
                {
                    currLineno = GetOriginalLineNum(str);

                    if (currLineno.Equals(sPreLineNum))
                    {
                        // // 是同一行，什么也不做
                    }
                    else
                    { // 不是同一行
                        sPreLineNum = currLineno;
                        sw.WriteLine(">>" + sPreLineNum + ">>:");
                    }

                }
                else
                {
                    sw.WriteLine(str);
                }

            }

            sr.Close();
            sr.Dispose();
            sw.Close();
            sw.Dispose();
        }

        // >>17>>:>13:NONE>:
        private string GetOriginalLineNum(string str)
        {
            int ipos_st = str.IndexOf(":>");
            int ipos_ed = str.IndexOf(":", ipos_st + 2);

            if (ipos_st > -1 && ipos_ed > -1)
            {
                return str.Substring(ipos_st + 2, ipos_ed - ipos_st - 2);
            }

            return "-1";
        }

        // 判断 是不是 Rexp 行
        private bool isREXP_line(string str)
        {
            if (str.IndexOf(":REXP>:") > 0)
            {
                return true;
            }

            return false;
        }

        // 判断 是不是 NONE 行
        private bool isNone_line(string str)
        {
            if (str.IndexOf(":NONE>:") > 0)
            {
                return true;
            }

            return false;
        }

        private void Save(StreamWriter sw,List<RSplitRes> Lrt, int indx)
        {
            int i = 0;

            for (i = 0; i < Lrt.Count; ++i)
            {
                if (Lrt[i].m_strType == StringType.NONE)
                {
                    sw.WriteLine(">" + indx.ToString() + ":NONE>:" + Lrt[i].m_str);
                }
                else if (Lrt[i].m_strType == StringType.REXP)
                {
                    sw.WriteLine(">" + indx.ToString() + ":REXP>:" + Lrt[i].m_str);

                }
            }
        }

        private void DeleteInValidRexp(List<digitsStr> Lst, string str)
        {
            int i = 0;

            for (i = 0; i < Lst.Count; ++i)
            {
                if (!isValidRexp(Lst[i], str))
                {
                    Lst.RemoveAt(i);
                    i = -1; //   又从头开始 
                }
            }
        }

        private bool isValidRexp(digitsStr ds, string str)
        {
            if (ds.m_CT == CharType.DIGIT ||
                ds.m_CT == CharType.YEAR ||
                ds.m_CT == CharType.MONTH ||
                ds.m_CT == CharType.DAY ||
                ds.m_CT == CharType.HOUR ||
                ds.m_CT == CharType.MINUITE ||
                ds.m_CT == CharType.SECOND)
            {
                return true;
            }
            else if (ds.m_CT == CharType.DIGIT_ZH && IsValidDigit_ZH(ds, str))
            {
                return true;
            }

            return false;
        }

        private bool IsValidDigit_ZH(digitsStr ds,string str)
        {
            if (ds == null)
            {
                return false;
            }
            else if (ds.m_ed - ds.m_st < 3)
            {
                return false;
            }

            string szh = ds.GetStr(str);

            bool hasDigitZH = false;
            bool hasUnitZH = false;

            int i = 0;

            for (i = 0; i < szh.Length; ++i)
            {
                if (isDigitsZH(szh[i]))
                {
                    hasDigitZH = true;
                }
                if (isUnits(szh[i])||isDot(szh[i]))
                {
                    hasUnitZH = true;
                }
            }
            
            return hasDigitZH && hasUnitZH;

        }

        private List<digitsStr> GetDigitsStr(string str)
        {
            List<digitsStr> Lst = GetDigitsStrLst(str);

            DeleteSomeUnits(Lst, str);

            int i = 0;

        DoAgain:
            for (i = 0; i < Lst.Count - 1; ++i)
            {
                if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.DOT &&
                    i < Lst.Count - 2 && Lst[i + 2].m_CT == CharType.DIGIT &&
                    isAdjacent(Lst[i], Lst[i + 1]) && isAdjacent(Lst[i + 1], Lst[i + 2]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.DIGIT&&
                         isAdjacent(Lst[i], Lst[i + 1]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.DIGIT_ZH &&
                         isAdjacent(Lst[i], Lst[i + 1])) // 处理 二００一年一月一日 的情况
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT_ZH && Lst[i + 1].m_CT == CharType.DIGIT &&
                         isAdjacent(Lst[i], Lst[i + 1])) // 处理 二００一年一月一日
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.DIGIT &&
                         Lst[i + 1].m_st - Lst[i].m_ed == 1 && isConn(str[Lst[i].m_ed]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.VS &&
                         isAdjacent(Lst[i], Lst[i + 1]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.UNIT &&
                         isAdjacent(Lst[i], Lst[i + 1]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT_ZH && Lst[i + 1].m_CT == CharType.UNIT &&
                         isAdjacent(Lst[i], Lst[i + 1]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT_ZH && Lst[i + 1].m_CT == CharType.DIGIT_ZH &&
                         isAdjacent(Lst[i], Lst[i + 1]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT_ZH && Lst[i + 1].m_CT == CharType.DOT &&
                         i < Lst.Count - 2 && Lst[i + 2].m_CT == CharType.DIGIT_ZH &&
                         isAdjacent(Lst[i], Lst[i + 1]) && isAdjacent(Lst[i + 1], Lst[i + 2]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else if (Lst[i].m_CT == CharType.DIGIT && Lst[i + 1].m_CT == CharType.PERCNT &&
                         isAdjacent(Lst[i], Lst[i + 1]))
                {
                    Merge2DigitsStr(Lst, i);
                    goto DoAgain;
                }
                else
                {
                }

            }

            MergeDateTime(Lst, str);
            MergePercentZH(Lst,str);
            MergeMinusDigit(Lst,str);

            return Lst;
        }

        private bool isAdjacent(digitsStr d1,digitsStr d2)
        {
            if (d1 == null || d2 == null)
            {
                return false;
            }

            if (d1.m_ed == d2.m_st)
            {
                return true;
            }

            return false;
        }

        private void MergeMinusDigit(List<digitsStr> Lst, string str)
        {
            int i = 0;

            for (i = 0; i < Lst.Count ; ++i)
            {
                if (Lst[i].m_CT == CharType.DIGIT && Lst[i].m_st > 0 && isMinus(str[Lst[i].m_st-1]))
                {
                    Lst[i].m_st -= 1; // 前面有个 负号
                }
            }
        }

        private void MergePercentZH(List<digitsStr> Lst, string str)
        {
            int i = 0;

            for (i = 0; i < Lst.Count-1; ++i)
            {
                if (Lst[i].m_CT == CharType.UNIT && Lst[i].GetStr(str).Equals("百") &&
                   Lst[i].m_ed + 1 < str.Length && str[Lst[i].m_ed].Equals('分') &&
                   str[Lst[i].m_ed + 1].Equals('之')&& Lst[i+1].m_CT== CharType.DIGIT_ZH&&
                   Lst[i].m_ed+2==Lst[i+1].m_st)
                {
                    Lst[i].m_ed = Lst[i + 1].m_ed;
                    Lst[i].m_CT = CharType.DIGIT_ZH;

                    Lst.RemoveAt(i+1);
                    i = -1;
                }
            }
        }

        private void MergeDateTime(List<digitsStr> Lst, string str)
        {
            int i = 0;

            for (i = 0; i < Lst.Count; ++i)
            {
                if (isYearNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('年'))
                {
                    Lst[i].m_ed += 1;
                    Lst[i].m_CT = CharType.YEAR;
                }
                else if (isMonthNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length - 1 && str[Lst[i].m_ed].Equals('月') && str[Lst[i].m_ed+1].Equals('份'))
                {
                    Lst[i].m_ed += 2;
                    Lst[i].m_CT = CharType.MONTH;
                }
                else if (isMonthNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('月'))
                {
                    Lst[i].m_ed += 1;
                    Lst[i].m_CT = CharType.MONTH;
                }
                else if (isDayNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('日'))
                {
                    Lst[i].m_ed += 1;
                    Lst[i].m_CT = CharType.DAY;
                }
                else if (isHour_MinuiteNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('时'))
                {
                    Lst[i].m_ed += 1;
                    Lst[i].m_CT = CharType.HOUR;
                }
                else if (isHour_MinuiteNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('分')&&
                         i > 0 && Lst[i - 1].m_CT == CharType.HOUR && Lst[i - 1].m_ed == Lst[i].m_st)
                {
                    Lst[i].m_ed += 1;
                    Lst[i].m_CT = CharType.MINUITE;
                }
                else if (isHour_MinuiteNum(Lst[i].GetStr(str)) && Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('秒')&&
                        i > 0 && Lst[i - 1].m_CT == CharType.MINUITE && Lst[i - 1].m_ed == Lst[i].m_st)
                {
                    Lst[i].m_ed += 1;
                    Lst[i].m_CT = CharType.SECOND;
                }
            }
        }

        private bool isYearNum(string str)
        {
            if (str.Length < 3 || str.Length > 4)
            {
                return false;
            }

            int i = 0;

            for (i = 0; i < str.Length; ++i)
            {
                if (isDigits(str[i]) || isDigitsZH(str[i]))
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }

            return true;
        }

        private bool isMonthNum(string str)
        {
            if (str.Equals("0") ||
                str.Equals("1") ||
                str.Equals("2") ||
                str.Equals("3") ||
                str.Equals("4") ||
                str.Equals("5") ||
                str.Equals("6") ||
                str.Equals("7") ||
                str.Equals("8") ||
                str.Equals("9") ||
                str.Equals("10") ||
                str.Equals("11") ||
                str.Equals("12"))
            {
                return true;
            }
            else if (str.Equals("０") ||
                     str.Equals("１") ||
                     str.Equals("２") ||
                     str.Equals("３") ||
                     str.Equals("４") ||
                     str.Equals("５") ||
                     str.Equals("６") ||
                     str.Equals("７") ||
                     str.Equals("８") ||
                     str.Equals("９") ||
                     str.Equals("１０") ||
                     str.Equals("１１") ||
                     str.Equals("１２"))
            {
                return true;
            }
            else if (str.Equals("一") ||
                     str.Equals("二") ||
                     str.Equals("三") ||
                     str.Equals("四") ||
                     str.Equals("五") ||
                     str.Equals("六") ||
                     str.Equals("七") ||
                     str.Equals("八") ||
                     str.Equals("九") ||
                     str.Equals("十") ||
                     str.Equals("十一") ||
                     str.Equals("十二"))
            {
                return true;
            }

            return false;
        }

        private bool isDayNum(string str)
        {
            if (str.Equals("0") ||
                str.Equals("1") ||
                str.Equals("2") ||
                str.Equals("3") ||
                str.Equals("4") ||
                str.Equals("5") ||
                str.Equals("6") ||
                str.Equals("7") ||
                str.Equals("8") ||
                str.Equals("9") ||
                str.Equals("10") ||
                str.Equals("11") ||
                str.Equals("12") ||
                str.Equals("13") ||
                str.Equals("14") ||
                str.Equals("15") ||
                str.Equals("16") ||
                str.Equals("17") ||
                str.Equals("18") ||
                str.Equals("19") ||
                str.Equals("20") ||
                str.Equals("21") ||
                str.Equals("22") ||
                str.Equals("23") ||
                str.Equals("24") ||
                str.Equals("25") ||
                str.Equals("26") ||
                str.Equals("27") ||
                str.Equals("28") ||
                str.Equals("29") ||
                str.Equals("30") ||
                str.Equals("31")
                )
            {
                return true;
            }
            else if (str.Equals("０") ||
                     str.Equals("１") ||
                     str.Equals("２") ||
                     str.Equals("３") ||
                     str.Equals("４") ||
                     str.Equals("５") ||
                     str.Equals("６") ||
                     str.Equals("７") ||
                     str.Equals("８") ||
                     str.Equals("９") ||
                     str.Equals("１０") ||
                     str.Equals("１１") ||
                     str.Equals("１２") ||
                     str.Equals("１３") ||
                     str.Equals("１４") ||
                     str.Equals("１５") ||
                     str.Equals("１６") ||
                     str.Equals("１７") ||
                     str.Equals("１８") ||
                     str.Equals("１９") ||
                     str.Equals("２０") ||
                     str.Equals("２１") ||
                     str.Equals("２２") ||
                     str.Equals("２３") ||
                     str.Equals("２４") ||
                     str.Equals("２５") ||
                     str.Equals("２６") ||
                     str.Equals("２７") ||
                     str.Equals("２８") ||
                     str.Equals("２９") ||
                     str.Equals("３０") ||
                     str.Equals("３１")
                )
            {
                return true;
            }
            else if (str.Equals("一") ||
                     str.Equals("二") ||
                     str.Equals("三") ||
                     str.Equals("四") ||
                     str.Equals("五") ||
                     str.Equals("六") ||
                     str.Equals("七") ||
                     str.Equals("八") ||
                     str.Equals("九") ||
                     str.Equals("十") ||
                     str.Equals("十一") ||
                     str.Equals("十二") ||
                     str.Equals("十三") ||
                     str.Equals("十四") ||
                     str.Equals("十五") ||
                     str.Equals("十六") ||
                     str.Equals("十七") ||
                     str.Equals("十八") ||
                     str.Equals("十九") ||
                     str.Equals("二十") ||
                     str.Equals("二十一") ||
                     str.Equals("二十二") ||
                     str.Equals("二十三") ||
                     str.Equals("二十四") ||
                     str.Equals("二十五") ||
                     str.Equals("二十六") ||
                     str.Equals("二十七") ||
                     str.Equals("二十八") ||
                     str.Equals("二十九") ||
                     str.Equals("三十") ||
                     str.Equals("三十一"))
            {
                return true;
            }

            return false;
        }

        private bool isHour_MinuiteNum(string str)
        {
            if (  str.Equals("0") ||
                  str.Equals("1") ||
                  str.Equals("2") ||
                  str.Equals("3") ||
                  str.Equals("4") ||
                  str.Equals("5") ||
                  str.Equals("6") ||
                  str.Equals("7") ||
                  str.Equals("8") ||
                  str.Equals("9") ||
                  str.Equals("01") ||
                  str.Equals("02") ||
                  str.Equals("03") ||
                  str.Equals("04") ||
                  str.Equals("05") ||
                  str.Equals("06") ||
                  str.Equals("07") ||
                  str.Equals("08") ||
                  str.Equals("09") ||
                  str.Equals("10") ||
                  str.Equals("11") ||
                  str.Equals("12") ||
                  str.Equals("13") ||
                  str.Equals("14") ||
                  str.Equals("15") ||
                  str.Equals("16") ||
                  str.Equals("17") ||
                  str.Equals("18") ||
                  str.Equals("19") ||
                  str.Equals("20") ||
                  str.Equals("21") ||
                  str.Equals("22") ||
                  str.Equals("23") ||
                  str.Equals("24") ||
                  str.Equals("25") ||
                  str.Equals("26") ||
                  str.Equals("27") ||
                  str.Equals("28") ||
                  str.Equals("29") ||
                  str.Equals("30") ||
                  str.Equals("31") ||
                  str.Equals("32") ||
                  str.Equals("33") ||
                  str.Equals("34") ||
                  str.Equals("35") ||
                  str.Equals("36") ||
                  str.Equals("37") ||
                  str.Equals("38") ||
                  str.Equals("39") ||
                  str.Equals("40") ||
                  str.Equals("41") ||
                  str.Equals("42") ||
                  str.Equals("43") ||
                  str.Equals("44") ||
                  str.Equals("45") ||
                  str.Equals("46") ||
                  str.Equals("47") ||
                  str.Equals("48") ||
                  str.Equals("49") ||
                  str.Equals("50") ||
                  str.Equals("51") ||
                  str.Equals("52") ||
                  str.Equals("53") ||
                  str.Equals("54") ||
                  str.Equals("55") ||
                  str.Equals("56") ||
                  str.Equals("57") ||
                  str.Equals("58") ||
                  str.Equals("59") ||
                  str.Equals("00") ||
                  str.Equals("0"))
            {
                return true;
            }
            else if (str.Equals("０") ||
                     str.Equals("１") ||
                     str.Equals("２") ||
                     str.Equals("３") ||
                     str.Equals("４") ||
                     str.Equals("５") ||
                     str.Equals("６") ||
                     str.Equals("７") ||
                     str.Equals("８") ||
                     str.Equals("９") ||
                     str.Equals("０１") ||
                     str.Equals("０２") ||
                     str.Equals("０３") ||
                     str.Equals("０４") ||
                     str.Equals("０５") ||
                     str.Equals("０６") ||
                     str.Equals("０７") ||
                     str.Equals("０８") ||
                     str.Equals("０９") ||
                     str.Equals("１０") ||
                     str.Equals("１１") ||
                     str.Equals("１２") ||
                     str.Equals("１３") ||
                     str.Equals("１４") ||
                     str.Equals("１５") ||
                     str.Equals("１６") ||
                     str.Equals("１７") ||
                     str.Equals("１８") ||
                     str.Equals("１９") ||
                     str.Equals("２０") ||
                     str.Equals("２１") ||
                     str.Equals("２２") ||
                     str.Equals("２３") ||
                     str.Equals("２４") ||
                     str.Equals("２５") ||
                     str.Equals("２６") ||
                     str.Equals("２７") ||
                     str.Equals("２８") ||
                     str.Equals("２９") ||
                     str.Equals("３０") ||
                     str.Equals("３１") ||
                     str.Equals("３２") ||
                     str.Equals("３３") ||
                     str.Equals("３４") ||
                     str.Equals("３５") ||
                     str.Equals("３６") ||
                     str.Equals("３７") ||
                     str.Equals("３８") ||
                     str.Equals("３９") ||
                     str.Equals("４０") ||
                     str.Equals("４１") ||
                     str.Equals("４２") ||
                     str.Equals("４３") ||
                     str.Equals("４４") ||
                     str.Equals("４５") ||
                     str.Equals("４６") ||
                     str.Equals("４７") ||
                     str.Equals("４８") ||
                     str.Equals("４９") ||
                     str.Equals("５０") ||
                     str.Equals("５１") ||
                     str.Equals("５２") ||
                     str.Equals("５３") ||
                     str.Equals("５４") ||
                     str.Equals("５５") ||
                     str.Equals("５６") ||
                     str.Equals("５７") ||
                     str.Equals("５８") ||
                     str.Equals("５９") ||
                     str.Equals("００") ||
                     str.Equals("０"))
            {
                return true;
            }
            else if (str.Equals("一") ||
                     str.Equals("二") ||
                     str.Equals("三") ||
                     str.Equals("四") ||
                     str.Equals("五") ||
                     str.Equals("六") ||
                     str.Equals("七") ||
                     str.Equals("八") ||
                     str.Equals("九") ||
                     str.Equals("十") ||
                     str.Equals("十一") ||
                     str.Equals("十二") ||
                     str.Equals("十三") ||
                     str.Equals("十四") ||
                     str.Equals("十五") ||
                     str.Equals("十六") ||
                     str.Equals("十七") ||
                     str.Equals("十八") ||
                     str.Equals("十九") ||
                     str.Equals("二十") ||
                     str.Equals("二十一") ||
                     str.Equals("二十二") ||
                     str.Equals("二十三") ||
                     str.Equals("二十四") ||
                     str.Equals("二十五") ||
                     str.Equals("二十六") ||
                     str.Equals("二十七") ||
                     str.Equals("二十八") ||
                     str.Equals("二十九") ||
                     str.Equals("三十") ||
                     str.Equals("三十一") ||
                     str.Equals("三十二") ||
                     str.Equals("三十三") ||
                     str.Equals("三十四") ||
                     str.Equals("三十五") ||
                     str.Equals("三十六") ||
                     str.Equals("三十七") ||
                     str.Equals("三十八") ||
                     str.Equals("三十九") ||
                     str.Equals("四十") ||
                     str.Equals("四十一") ||
                     str.Equals("四十二") ||
                     str.Equals("四十三") ||
                     str.Equals("四十四") ||
                     str.Equals("四十五") ||
                     str.Equals("四十六") ||
                     str.Equals("四十七") ||
                     str.Equals("四十八") ||
                     str.Equals("四十九") ||
                     str.Equals("五十") ||
                     str.Equals("五十一") ||
                     str.Equals("五十二") ||
                     str.Equals("五十三") ||
                     str.Equals("五十四") ||
                     str.Equals("五十五") ||
                     str.Equals("五十六") ||
                     str.Equals("五十七") ||
                     str.Equals("五十八") ||
                     str.Equals("五十九"))
            {
                return true;
            }

            return false;
        }

        private void Merge2DigitsStr(List<digitsStr> Lst, int iPos)
        {
            if (iPos < 0 || iPos >= Lst.Count - 1)
            {
                return;
            }

            Lst[iPos].m_ed = Lst[iPos + 1].m_ed;

            Lst.RemoveAt(iPos + 1);
        }

        private List<digitsStr> GetDigitsStrLst(string str)
        {
            List<digitsStr> Lst = new List<digitsStr>();

            if (str == null || str.Equals(""))
            {
                return Lst;
            }

            int i = 0;
            digitsStr dgstr = null;

            for (i = 0; i < str.Length; )
            {
                if (isDigits(str[i]))
                {
                    dgstr = GetContinueStr(str, i, CharType.DIGIT);
                    Lst.Add(dgstr);
                    i = dgstr.m_ed;
                }
                else if (isDigitsZH(str[i]))
                {
                    dgstr = GetContinueStr(str, i, CharType.DIGIT_ZH);
                    Lst.Add(dgstr);
                    i = dgstr.m_ed;
                }
                else if (isDot(str[i]))
                {
                    dgstr = GetContinueStr(str, i, CharType.DOT);
                    Lst.Add(dgstr);
                    i = dgstr.m_ed;
                }
                else if (isVs(str[i]))
                {
                    dgstr = GetContinueStr(str, i, CharType.VS);
                    Lst.Add(dgstr);
                    i = dgstr.m_ed;
                }
                else if (isUnits(str[i]))
                {
                    dgstr = GetContinueStr(str, i, CharType.UNIT);
                    Lst.Add(dgstr);
                    i = dgstr.m_ed;
                }
                else if (isPercent(str[i]))
                {
                    dgstr = GetContinueStr(str, i, CharType.PERCNT);
                    Lst.Add(dgstr);
                    i = dgstr.m_ed;
                }
                else
                {
                    i++;
                }
            }


            return Lst;
        }

        private void DeleteSomeUnits(List<digitsStr> Lst,string str)
        {
            int i = 0;

            for (i = 0; i < Lst.Count - 1; ++i)
            {
                if (UnitIsBigger(Lst[i], Lst[i + 1],str))
                {
                    Lst.RemoveAt(i+1);
                    i = -1;
                }
            }

            for (i = 0; i < Lst.Count; ++i)
            {
                if (Lst[i].m_CT == CharType.UNIT && Lst[i].GetStr(str).Equals("千") &&
                   Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('米'))
                {
                    Lst.RemoveAt(i);
                    i = -1;
                }
                else if (Lst[i].m_CT == CharType.UNIT && Lst[i].GetStr(str).Equals("千") &&
                   Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('克'))
                {
                    Lst.RemoveAt(i);
                    i = -1;
                }
                else if (Lst[i].m_CT == CharType.UNIT && Lst[i].GetStr(str).Equals("千") &&
                   Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('瓦'))
                {
                    Lst.RemoveAt(i);
                    i = -1;
                }
                else if (Lst[i].m_CT == CharType.UNIT && Lst[i].GetStr(str).Equals("千") &&
                         Lst[i].m_ed < str.Length && str[Lst[i].m_ed].Equals('伏'))
                {
                    Lst.RemoveAt(i);
                    i = -1;
                }
            }

        }

        private bool UnitIsBigger(digitsStr u1, digitsStr u2,string str)
        {
            if (u1.m_CT != CharType.UNIT || u2.m_CT != CharType.UNIT)
            {
                return false;
            }

            int v1 = GetValueOfUnit(u1,str);
            int v2 = GetValueOfUnit(u2,str);

            if (v1 > v2)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        private int GetValueOfUnit(digitsStr u,string str)
        {
            if (u.m_CT != CharType.UNIT)
            {
                return -1000;
            }

            if (u.GetStr(str).Equals("十"))
            {
                return 1;
            }
            else if (u.GetStr(str).Equals("百"))
            {
                return 2;
            }
            else if (u.GetStr(str).Equals("千"))
            {
                return 3;
            }
            else if (u.GetStr(str).Equals("万"))
            {
                return 4;
            }
            else if (u.GetStr(str).Equals("亿"))
            {
                return 5;
            }
            else if (u.GetStr(str).Equals("兆"))
            {
                return 6;
            }
            else
            {
                return -1;
            }
        }

        private digitsStr GetContinueStr(string str, int ipos, CharType ct)
        {
            int i = 0;
            digitsStr dgstr = new digitsStr();

            dgstr.m_CT = ct;
            dgstr.m_st = ipos;

            if (ct == CharType.UNIT)
            {
                dgstr.m_ed = ipos + 1;
                return dgstr;
            }

            for (i = ipos; i < str.Length; ++i)
            {
                if (GetCharType(str[i]) != ct)
                {
                    dgstr.m_ed = i;

                    return dgstr;
                }
            }

            dgstr.m_ed = i;

            return dgstr;
        }

        private CharType GetCharType(char ch)
        {
            if (isDigits(ch))
            {
                return CharType.DIGIT;
            }
            else if (isDigitsZH(ch))
            {
                return CharType.DIGIT_ZH;
            }
            else if (isDot(ch))
            {
                return CharType.DOT;
            }
            else if (isPercent(ch))
            {
                return CharType.PERCNT;
            }
            else if (isVs(ch))
            {
                return CharType.VS;
            }
            else if (isUnits(ch))
            {
                return CharType.UNIT;
            }
            else
            {
                return CharType.OTHER;
            }
        }

        private bool isConn( char ch)
        {
            return isIn(ch,m_Conn);
        }

        private bool isMinus( char ch)
        {
            return isIn(ch,m_Minus);
        }

        private bool isDigits(char ch)
        {
            return isIn(ch, m_Digits);
        }

        private bool isDigitsZH(char ch)
        {
            return isIn(ch, m_DigitsZH);
        }

        private bool isUnits(char ch)
        {
            return isIn(ch, m_Units);
        }

        private bool isDot(char ch)
        {
            return isIn(ch, m_Dots);
        }

        private bool isPercent(char ch)
        {
            return isIn(ch, m_Perc);
        }

        private bool isVs(char ch)
        {
            return isIn(ch, m_Vs);
        }

        private bool isIn(char ch, char[] arr)
        {
            int i = 0;

            if (ch == null || arr == null)
            {
                return false;
            }

            for (i = 0; i < arr.Length; ++i)
            {
                if (ch.Equals(arr[i]))
                {
                    return true;
                }
            }

            return false;
        }


        public char[] m_Digits = {'０', '１', '２', '３','４','５','６','７', '８', '９',
                                  '0','1','2','3','4','5','6','7','8','9'};

        public char[] m_DigitsZH = {'○', '零', '一', '二', '三', '四', '五', '六', '七', '八', '九','十' };

        public char[] m_Units = { '十', '百', '千', '万', '亿', '兆' };

        public char[] m_Dots = { '点', '.', '．', '·' };
        public char[] m_Perc = { '%', '％', '‰' };
        public char[] m_Vs = { '∶', ':' };
        public char[] m_Conn = { '／' };
        public char[] m_Minus = { '－' };
    }
}
