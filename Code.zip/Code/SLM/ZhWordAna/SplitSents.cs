﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using ViWordAna;

namespace ZhWordAna
{
    public class Word_AB_4Check
    {
        public char[] m_A = null;
        public char[] m_B = null;
    }

    /*
     * 类说明：用于存储一个 “词” 在整个词序列种的 起始 终止位置，[st,ed),闭 开区间
     * **/
    public class WordIndexPair
    {
        public WordIndexPair(int st, int ed)
        {
            m_st = st;
            m_ed = ed;
        }


        /*
         * 函数功能：获取一个 “可行词” 内部检测的 词的 各种组合
         *           例如 originalWords="ABCDEF"，那么返回的该词的各种组合为：
         *           "A","BCDEF"
         *           "AB","CDEF"
         *           "ABC","DEF"
         *           "ABCD","EF"
         *           "ABCDE","F"
         *           "ABCDEF",null
         *
         * 参数说明：originalWords，原始的需要被 检测的一个词 
         * 
         *           m_st, 该“可行词” 的起始位置
         *           m_ed, 该“可行词” 的结束位置
         *           
         * 返回值：词的组合 序列
         */

        public List<Word_AB_4Check> GetWords4CheckInner(string originalWords)
        {
            List<Word_AB_4Check> Lst = new List<Word_AB_4Check>();
            int i = 0;
            int cnt = 0;

            if (originalWords== null || originalWords.Length == 0 ) // null 或者是长度为0， 直接返回。
            {
                return Lst;
            }

            if (m_ed - m_st == 1)
            {
                char[] Fst = new char[1];
                Fst[0] = originalWords[m_st];

                Word_AB_4Check wab = new Word_AB_4Check();
                wab.m_A = Fst;
                wab.m_B = null;

                Lst.Add(wab);

                return Lst;
            }

            for (i = m_st; i < m_ed - 1; ++i)
            {
                char[] A = new char[i - m_st + 1];
                char[] B = new char[m_ed - i - 1];
                int j = 0;

                cnt = 0;

                for (j = m_st; j <= i; ++j)
                {
                    A[cnt++] = originalWords[j];
                }

                cnt = 0;
                for (j = i + 1; j < m_ed; ++j)
                {
                    B[cnt++] = originalWords[j];
                }

                Word_AB_4Check wab = new Word_AB_4Check();
                wab.m_A = A;
                wab.m_B = B;

                Lst.Add(wab);
            }

            Word_AB_4Check t = new Word_AB_4Check();
            t.m_A = new char[m_ed - m_st];// 把整个字拷贝回去
            t.m_B = null;

            cnt = 0;

            for (i = m_st; i < m_ed; ++i)
            {
                t.m_A[cnt++] = originalWords[i];
            }

            Lst.Add(t);

            return Lst;
        }

        /*
         * 函数功能：获取一个 “可行词” 之间(注意是“之间”)校验时的，“前面”一个单词的组合 序列 ，也就是对一个“可行分词”A|B，
         *           检验A和B是否可以这样分时，获取A的各种拆分
         *           
         *           假设：originalWords="ABCDEF", 那么返回的结果为：
         *           "ABCDE","F"
         *           "ABCD","EF"
         *           "ABC","DEF"
         *           "AB","CDEF"
         *           "A","BCDE"
         *           "ABCDEF",null
         * 
         *           
         * 参数说明：originalWords，也就是 单词 A
         *           
         * 返回值：词的 各种组合序列
         */

        public List<Word_AB_4Check> GetWords4Check_A(string  originalWords) // 其实这个函数 和 GetWords4Check_inner 是一样的
        {
            List<Word_AB_4Check> Lst = new List<Word_AB_4Check>();
            int i = 0;
            int cnt = 0;

            // 为null 或者 长度为 0 ，直接返回
            if (originalWords == null || originalWords.Length == 0)
            {
                return Lst;
            }

            if (m_ed - m_st == 1)
            {
                char[] Fst = new char[1];
                Fst[0] = originalWords[m_st];

                Word_AB_4Check wab = new Word_AB_4Check();
                wab.m_A = Fst;
                wab.m_B = null;
                Lst.Add(wab);

                return Lst;
            }

            for (i = m_ed - 1; i > m_st; --i)
            {
                char[] Fst = new char[i - m_st];
                char[] Sec = new char[m_ed - i];
                int j = 0;

                cnt = 0;

                for (j = m_st; j < i; ++j)
                {
                    Fst[cnt++] = originalWords[j];
                }

                cnt = 0;
                for (j = i; j < m_ed; ++j)
                {
                    Sec[cnt++] = originalWords[j];
                }

                Word_AB_4Check wab = new Word_AB_4Check();
                wab.m_A = Fst;
                wab.m_B = Sec;

                Lst.Add(wab);
            }

            Word_AB_4Check t = new Word_AB_4Check();
            t.m_A = new char[m_ed - m_st];// 把整个字拷贝回去, 这里好像有点问题波，应该是让 A为null，因为 A 在前面，B返回整个字符串
            t.m_B = null;

            cnt = 0;

            for (i = m_st; i < m_ed; ++i)
            {
                t.m_A[cnt++] = originalWords[i];
            }

            Lst.Add(t);


            return Lst;
        }

        public int m_st = 0; // 起始indx，包含
        public int m_ed = 0; // 终止indx，不包含
    }


    /*
     * 类功能说明：分词的类，目前最多 8阶分词
     * **/
    public class SplitSents
    {

        public SplitSents(CalcProbCond cpc, string str, CalcAvgLR_IE calrie)
        {
            m_str = str;
            m_cpc = cpc;
            m_calrie = calrie;
        }

        public SplitSents(CalcProbCond cpc)
        {
            m_cpc = cpc;
        }

        /*
        * 函数功能：对字符串进行分词
        * 参数说明：str, 需要进行分解的字符串
        * 
        * 返回值：最优分词结果
        *         
        */

        public OptRes doSplit_JustGetOptimal(string str)
        {
            if (str.Length > 32 || str.Length == 0)
                return null;

            string[] NoUsewords = new string[str.Length]; // 只是用来传一个长度给 GenSearchSpace
            UInt32 srchP = CommFuns.GenSearchSpace(NoUsewords); // 生成枚举法 搜索的 空间 

            UInt32 i = 0;
            double dPro = 0D;
            double dPmax = -0x7FFFFFFFD;
            UInt32[] aMaxBL = null;
            UInt32[] bL = null;

            // 并发处理的思路：
            // (1)先生成 bL的数组，比如说 100个，然后再并行，这样一次可以减少缓存的申请
            for (i = 0; i < srchP; ++i)
            {
                if (i % 2 == 0)
                {
                    continue;//最低位是0，跳过。因为第一个字要么它本身是一个词，要么是更长词的开头
                }

                bL = CommFuns.GenBinaryList(i, str.Length); // 二进制序列

                // 目前只能做到 8 阶
                if (!CommFuns.isVaildBitSeq_n_odr(bL, 8))
                {
                    continue;
                }

                dPro = calcProb_sents(str, bL); // 计算该二进制序列所代表的 分词 的 序列 

                if (dPro < -10000 + 1)
                {
                    continue;
                }

                if (dPro > dPmax) // 更新 最优分词结果
                {

                    aMaxBL = bL;
                    dPmax = dPro;
                }
            }

            OptRes op = new OptRes(); // 构造 最优分词结果
            op.m_dsumH = dPmax;
            op.m_bits = aMaxBL;

            return op;
        }


        /*
         * 函数功能：对字符串进行分词
         * 参数说明：str, 需要进行分解的字符串
         * 
         * 返回值：分词结果，数组的最0位对应第0个字。
         *         1表示一个词的开始，紧接着的0表示和前面的字构成一个词
         *
         */

        public UInt32[] doSplit(string str)
        {
            if (str.Length > 32|| str.Length == 0 )
                return null;

            m_calrie.m_HisWordNumInDB.Clear(); // 左右信息熵，已经不用了
            m_calrie.m_HisLRIE.Clear();        // 左右信息熵，已经不用了

            UInt32[] bL = null;
            string[] NoUsewords = new string[str.Length]; // 只是用来传一个长度给 GenSearchSpace

            UInt32 srchP = CommFuns.GenSearchSpace(NoUsewords); // 生成枚举法 搜索的 空间 

            UInt32 i = 0;

            double dPro = 0D;

            double dPmax = -0x7FFFFFFFD;

            UInt32[] aMaxBL = null;

            List<FeasibleResult> LFR = new List<FeasibleResult>();


            // 并发处理的思路：
            // (1)先生成 bL的数组，比如说 100个，然后再并行，这样一次可以减少缓存的申请
            for (i = 0; i < srchP; ++i)
            {
                if (i % 2 == 0)
                {
                    continue;//最低位是0，跳过。因为第一个字要么它本身是一个词，要么是更长词的开头
                }

                bL = CommFuns.GenBinaryList(i, str.Length); // 二进制序列

                // 目前只能做到 8 阶
                if (!CommFuns.isVaildBitSeq_n_odr(bL, 8))
                {
                    continue;
                }

                dPro = calcProb_sents(str, bL); // 计算该二进制序列所代表的 分词 的 序列 

                if (dPro < -10000 + 1)
                {
                    continue;
                }

                FeasibleResult fr = new FeasibleResult();
                fr.m_Prob = dPro;
                fr.m_BL = bL;

                LFR.Add(fr);

                if (dPro > dPmax)
                {

                    aMaxBL = bL;
                    dPmax = dPro;
                }
            }

            LFR.Sort();

            // ======== 结果写入文件



            StreamWriter sw = new StreamWriter("SplitResult.txt", false);
            int j = 0;
            string words = str;
            int iBeg = 0;
            int iLen = 0;

            for (j = 0; j < LFR.Count; ++j)
            {

                sw.WriteLine("===== 第 " + j.ToString()+" 个分词结果，dprob = ："+ LFR[j].m_Prob.ToString()+" =========");
                iBeg = 0;
                iLen = 0;

                for (i = 0; i < words.Length - 1; ++i)
                {
                    iLen++;
                    

                    if (LFR[j].m_BL[i + 1] == 1)
                    {
                        sw.WriteLine(words.Substring(iBeg,iLen));
                        iBeg = (int)i + 1;
                        iLen = 0;
                    }
                }


                sw.WriteLine(words.Substring(iBeg));

            }

            sw.Close();
            sw.Dispose();

            return aMaxBL;
        }

        /*
        * 函数功能：计算整个句子的一个可行分词序列的 对数概率。
        * 参数说明：sWords，整个句子的字序列(数组)
        *           bL，一个分词可行解
        *           
        * 返回值：概率的对数值。
        */
        private double calcProb_sents(string str, UInt32[] bL)
        {
            int i = 0;
            double pSum = 0D;
            int nextBeg = -1;

            if (bL[0] != 1)
            {
                return -100000D;// 一个充分小的数
            }

            List<WordIndexPair> Lwip = new List<WordIndexPair>();  // 记录一句话上的 可行词 划分，用于检验 可行词之间的 划分

            i = 0;        // 刚刚开始第一个词的开始位置是 0
            nextBeg = 0;
            while (i < str.Length)
            {
                nextBeg = CommFuns.NextWordBeg(bL, i);             // 下一个词的开始位置

                //double pTmp = calcProb_word(str, i, nextBeg);   // 计算一个词[ i, nextBeg) 的 概率 ， 以概率最大为目标函数

                double pTmp = calcH_word(str, i, nextBeg); // 计算一个词的 平均结合力 ，以平均结合力最大为目标函数

                if (CheckProb_InnerWord(str, i, nextBeg) == false)  // 检验这个可行词的内部 是否满足 组词条件
                {// 没有必要进行下去了 ，直接返回
                    return pSum = -10000D;
                }

                Lwip.Add(new WordIndexPair(i, nextBeg));

                pSum += pTmp;

                i = nextBeg; // 移动到下一个词的开始

                if (i == str.Length) // 已经没有词了，退出
                {
                    break;
                }
            }

            // 检查一个可行分词的 词 间 是否满足规则
            // 
            // 不满足约束条件，则返回一个充分小的概率

            // 以概率最大为目标时，该条件可以使得一个可行词 尽可能长
            
            if (CheckProb_InterWord_WeakCheck(Lwip, str) == false)
            //if (CheckProb_InterWord(Lwip, str) == false)
            {
                return -10000D;
            }
            /*  * 
             *  如果是 以平均结合力之和 最大 为 目标函数时，则不需要该检查条件，该检查条件会导致如下情况：
             *  tràn đầy năng lượng（充满 能量），在分词时，对一个可行的划分，（tràn đầy）（năng lượng）， 
             *  （tràn đầy）和 năng 的结合力 大于 năng和lượng的结合力，由此导致该条件返回false，即（tràn đầy）（năng lượng）
             *  不能构成一个可行的划分，后面的一个词因为前面一个词被 拆分 了。
             * 
             * 但是完全不检查又不行，对于这种情况：và  sự  tự  tin  ，正确的划分是这样：（và）（ sự  tự  tin ），“和”“自信”
             * 因为 （ sự  tự  tin ）和平均结合力 小于 （và sự）（tự  tin），固 这4个字被切分成：（và sự）（tự  tin），不正确。
             * 
             * 这样就出现了一对矛盾：一个需要检查，另一个 不需要检查，如何解决这个坑？？ ？结合力 经可能大，又要单词尽可能长！！！
             * （计算结合力时 log 的分母要尽可能大，但是不能大到和分子一样）
             * 2019.3.28 19：13， 还是需要检查的，需要弱检查（只检查断开处的 前后 一个 字（如果再多一点，两个字呢？）），不需要像以最大概率为目标的 强检查（所有的切分组合都要检查）
             * 
             */

           //double LRIE = (double)m_calrie.CalcAvg_IE(str,bL); // 计算 左右信息熵 之差的 平均值（该优化项 把 高频组合词 分开）

            double LRIE = 0;
            return pSum + LRIE;
        }

        /*
        * 函数功能：计算区间[stPos,edPos)（不包括edPos）的字组成的可行词的 对数概率
        * 参数说明：sWords，原始字符串；
        *           stPos，起始位置；
        *           edPos，终止位置（不包含）
        * 返回值： 区间[stPos,edPos)（不包括edPos）的字组成的可行词的 对数概率
        */

        private double calcProb_word(string  sWords, int stPos, int edPos)
        {

            if (stPos >= edPos)
            {
                return -10000D; // 充分小的数
            }

            int odr = edPos - stPos;
            char[] one_word = new char[odr];
            int i = 0;

            for (i = 0; i < odr; ++i)
            {
                one_word[i] = sWords[stPos + i];
            }

            Decimal p = m_cpc.CalcProb(one_word, odr);

            return (double)p;
        }

        /*
        * 函数功能：计算字符串str中，区间[stPos,edPos)(不包括edPos）构成的词的 结合力（结合力的定义参加 定义）
        * 参数说明：str，字符串；
        *           stPos，起始位置；
        *           edPos，终止位置（不包含）
        *
        * 返回值： 区间[stPos到edPos)（不包括edPos）的字组成的词的 平均 结合力
        */

        private double calcH_word(string str, int stPos, int edPos)
        {

            if (stPos >= edPos || str == null )  // 参数有误，直接返回
            {
                return -10000D; // 充分小的数
            }

            if (edPos - stPos == 1) // 定义 一个词的结合力为 0 
            {
                return 0; // 充分小的数 
            }

            int odr = edPos - stPos;
            char[] one_word = new char[odr]; // 用于存储一整个词
            char[] aWord = new char[1];      // 一个字
            Decimal pSum = 0;
            int i = 0;

            for (i = 0; i < odr; ++i)
            {
                one_word[i] = str[stPos + i];
                aWord[0] = str[stPos + i];

                pSum += m_cpc.CalcProb(aWord, 1);
            }

            Decimal p = m_cpc.CalcProb(one_word, odr);// 这个词的 对数概率，

            

            p = p - pSum; // 对数 变换 之后 相减 即可，参见结合力的定义

           //return (double)p/(odr-1);
           // return (double)p / (odr);   // 平均结合力，

            // 不搞平均结合力了，要尝试新的东西！
            // 结合力 乘以 出现次数 2019.10.12

            int wdNum = 1;

            //if (odr == 2)
            {
                wdNum = m_cpc.GetWordNum(one_word);
            }

            return ((double)p) * wdNum;


        }


        


        /*
         * 函数功能：检查一个可行词的内部是否满足构词条件，即:如果AB是一个词， P(B|A) > P(B)以此类推
         * 参数说明：sWords，整个句子的字符序列
         *           [stPos,edPos)，可行词在原始字符序列中的 闭开区间
         *           
         * 返回值：true,可以构成一个词
         *         false,不能构成一个词
         * **/

        private bool CheckProb_InnerWord(string sWords, int stPos, int edPos)
        {
            // 只有一个单词，直接返回真
            if (edPos - stPos == 1)
            {
                return true;
            }

            // 概率和的检查 , 考虑了各种组合的情况，而不是简单的单个字 的 概率

            Decimal psum = 0;
            int j = 0;
            int i = 0;
            Decimal pLongWord = (Decimal)calcProb_word(sWords, stPos,edPos); // 整个单词的 概率

            List<List<WordIndexPair>> Lall = CommFuns.GetAllCombination(stPos, edPos); // 获取该“可行词” 的所有可能的 “切分”组合

            for (i = 0; i < Lall.Count; ++i)
            {
                List<WordIndexPair> Lonesplit = Lall[i];
                psum = 0;
                j=0;

                for( j = 0; j < Lonesplit.Count; ++j)
                {
                    int st = Lonesplit[j].m_st;
                    int ed =  Lonesplit[j].m_ed;

                    psum += (Decimal) calcProb_word(sWords,st ,ed); // 经过对数变换，所以相加
                }

                if (!(pLongWord > psum)) // 单词的概率要大于 各个字的概率之和
                {                        //如果不满足，直接返回 false, 没有必要进行下去了
                    return false;
                }

            }

            // 条件 概率的检查 

            WordIndexPair wip = new WordIndexPair(stPos, edPos);
            List<Word_AB_4Check> Lst = wip.GetWords4CheckInner(sWords);

            for (i = 0; i < Lst.Count; ++i)
            {
                char[] A = Lst[i].m_A;
                char[] B = Lst[i].m_B;

                if (A == null || B == null)
                {
                    continue;
                }

                Decimal p_AB = m_cpc.CalcProb(A, B);         // 条件概率 P(B|A)
                Decimal p_B = m_cpc.CalcProb(B, B.Length);   // 概率 P(B)

                if ( !(p_AB > p_B) ) // 一定要满足 P(B|A) > P(B)
                {
                    // 不满足返回 false 
                    return false;
                }
            }

            return true;
        }

        /*
          * 函数功能：检查两个单词之间是不是一个合理的划分，即:如果AB|CD是一个划分， 则有：P(B|A) > P(B|C)、P(C|D) > P(C|B) 以此类推
          * 参数说明：oneWord
          * 返回值：true,可以构成一个词
          *         false,不能构成一个词
          * **/
        public bool CheckProb_InterWord(List<WordIndexPair> lst, string originalWords)
        {
            int i = 0;
            int m = 0;
            int k = 0;

            Decimal val = 0;

            for (i = 0; i < lst.Count - 1; ++i)
            {
                WordIndexPair fst = lst[i];   // 表示前一个单词
                WordIndexPair sec = lst[i + 1]; // 表示后一个单词

                List<Word_AB_4Check> Lpre = fst.GetWords4Check_A(originalWords);    // 前一个单词的各种 切分，包括自己本身在内（切分出来的单词一个是本身，一个为空）
                List<Word_AB_4Check> Lsec = sec.GetWords4CheckInner(originalWords); // 后一个单词的各种 切分，包括自己本身在内（切分出来的单词一个是本身，一个为空）

                if (Lpre.Count == 0 || Lsec.Count == 0)
                {
                    MessageBox.Show("检验可行分词之间的 概率关系时，前后 链表无元素！！");
                    return false;
                }

                for (m = 0; m < Lpre.Count; ++m)
                { // for 1

                    char[] A = Lpre[m].m_A;
                    char[] B = Lpre[m].m_B; // A B 对应 pre

                    for (k = 0; k < Lsec.Count; ++k)
                    { // for2

                        char[] C = Lsec[k].m_A;
                        char[] D = Lsec[k].m_B; // C D对应 sec

                        if (B == null && D == null) // 前后只有一个单字：A B 的情况，不需要再校验，直接跳过 ，用于概率最大, 可以使得一个“可行词” 尽可能长
                        //if (B == null || D == null)  // 用于平均 结合力 最大 , 注意：这是一个 十分 重要的条件 ！
                        {
                            // 什么也不用做。
                        }
                        else if (B == null && D != null)  // A CD
                        {
                            if (A.Length + C.Length > 8) // 长度超过 8 了，无法校验，直接跳过
                            {
                                continue;
                            }

                            Decimal h_a_c = m_cpc.CalcH_AB(A, C);
                            Decimal h_c_d = m_cpc.CalcH_AB(C, D);

                            if (!(h_a_c+val < h_c_d))
                            {
                                return false; // 只要有一个不满足，返回假
                            }
                        }
                        else if (B != null && D == null) // AB C
                        {
                            if (B.Length + C.Length > 8) // 太长了，无法校验
                            {
                                continue;
                            }

                            Decimal h_a_b = m_cpc.CalcH_AB(A, B);
                            Decimal h_b_c = m_cpc.CalcH_AB(B, C);

                            if (!(h_a_b > h_b_c+val))
                            {
                                return false;  //只要一个不满足，返回假
                            }
                        }
                        else if (B != null && D != null) // AB CD 的情况
                        {
                            if (B.Length + C.Length > 8) // 太长了 ，处理不了，直接跳过
                            {
                                continue;
                            }

                            Decimal h_A_B = m_cpc.CalcH_AB(A, B);
                            Decimal h_B_C = m_cpc.CalcH_AB(B, C);
                            Decimal h_C_D = m_cpc.CalcH_AB(C, D);

                            if (!(h_B_C+val < Math.Min(h_A_B, h_C_D))) // h_B_C比他们两个都小，否则直接返回错误！
                            {
                                return false;
                            }
                        }
                    } // for2 end
                } //  for1 end

            }// outer for end

            // 都满足 则返回 true
            return true;
        } // function end

        /*
          * 函数功能：弱检查，检查两个单词之间是不是一个合理的划分，即:如果AB|CD是一个划分， 则有：H(B,C)<min(H(A,B),H(C,D))只考虑B、C是一个字的情况
          * 参数说明：lst，代表整个句子的 一个分词方案
          *           originalWords，原始的字符串（代表一个句子）
         *           
          * 返回值：true, lst表示的划分 是一个 可行的 方案
          *         false, 表示 这不是一个可行的 方案
          * **/
        public bool CheckProb_InterWord_WeakCheck(List<WordIndexPair> lst, string  originalWords)
        {
            int i = 0;
            int m = 0;
            int k = 0;

            Decimal val = 0;

            for (i = 0; i < lst.Count - 1; ++i)
            {
                WordIndexPair fst = lst[i];   // 表示前一个单词
                WordIndexPair sec = lst[i + 1]; // 表示后一个单词

                List<Word_AB_4Check> Lpre = fst.GetWords4Check_A(originalWords);    // 前一个单词的各种 切分，包括自己本身在内（切分出来的单词一个是本身，一个为空）
                List<Word_AB_4Check> Lsec = sec.GetWords4CheckInner(originalWords); // 后一个单词的各种 切分，包括自己本身在内（切分出来的单词一个是本身，一个为空）

                if (Lpre.Count == 0 || Lsec.Count == 0)
                {
                    MessageBox.Show("检验可行分词之间的 概率关系时，前后 链表无元素！！");
                    return false;
                }

                for (m = 0; m < Lpre.Count; ++m)
                { // for 1

                    char[] A = Lpre[m].m_A;
                    char[] B = Lpre[m].m_B; // A B 对应 pre

                    for (k = 0; k < Lsec.Count; ++k)
                    { // for2

                        char[] C = Lsec[k].m_A;
                        char[] D = Lsec[k].m_B; // C D对应 sec

                        if (B == null && D == null) // 前后只有一个单字：A B 的情况，不需要再校验，直接跳过 ，用于概率最大, 可以使得一个“可行词” 尽可能长
                        //if (B == null || D == null)  // 用于平均 结合力 最大 , 注意：这是一个 十分 重要的条件 ！
                        {
                            // 什么也不用做。
                        }
                        else if( B!=null && B.Length == 1 && C.Length == 1 && D == null ) // 这里隐含 一个条件：A,C不可能是null
                        {
                            Decimal h_ab = m_cpc.CalcH_AB(A, B);
                            Decimal h_bc = m_cpc.CalcH_AB(B, C);

                            if (!(h_bc < h_ab)) // h_bc比h_ab小
                            {
                                return false;
                            }
                        
                        }
                        else if (B!= null && B.Length == 1 && C.Length == 1 && D!=null) // AB CD 的情况
                        {
                            Decimal h_A_B = m_cpc.CalcH_AB(A, B);
                            Decimal h_B_C = m_cpc.CalcH_AB(B, C);
                            Decimal h_C_D = m_cpc.CalcH_AB(C, D);

                            if (!(h_B_C + val < Math.Min(h_A_B, h_C_D))) // h_B_C比他们两个都小，否则直接返回错误！
                            {
                                return false;
                            }
                        }
                        else if (A.Length == 1 && B == null && C.Length == 1 && D!=null)
                        {
                            Decimal h_ac = m_cpc.CalcH_AB(A, C);
                            Decimal h_cd = m_cpc.CalcH_AB(C, D);

                            if (!(h_ac < h_cd)) // h_bc比h_ab小
                            {
                                return false;
                            }
                        }
                    } // for2 end
                } //  for1 end

            }// outer for end

            // 都满足 则返回 true
            return true;
        } // function end


        private string m_str = null;
        public CalcProbCond m_cpc = null;
        private CalcAvgLR_IE m_calrie = null;

    }
}
