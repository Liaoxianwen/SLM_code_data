﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.IO;

namespace ZhWordAna
{
    /*
     * 类说明：存储最优分词结果的 结构体
     * 
     */
    public class OptRes
    {
        public UInt32[] m_bits = null; // 分词方案
        public double m_dsumH = 0;     // 平均结合力之和

        public void Write2File(string sFileName, string str)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            int j = 0;
            string words = str;
            int iBeg = 0;
            int iLen = 0;
            int i = 0;

            sw.WriteLine("===== 第 " + j.ToString() + " 个分词结果，dprob = ：" + m_dsumH.ToString() + " =========");
            iBeg = 0;
            iLen = 0;

            for (i = 0; i < str.Length - 1; ++i)
            {
                iLen++;


                if (m_bits[i + 1] == 1)
                {
                    sw.WriteLine(str.Substring(iBeg, iLen));
                    iBeg = (int)i + 1;
                    iLen = 0;
                }
            }

            sw.WriteLine(str.Substring(iBeg));

            sw.Close();
            sw.Dispose();
        }

        public void Write2FileREXP(StreamWriter sw, string str, string sPrefix)
        {
            sw.WriteLine(sPrefix);
            sw.WriteLine(str);
            sw.Flush();
        }

        public void Write2File(StreamWriter sw, string str,string sPrefix)
        {
            int j = 0;
            string words = str;
            int iBeg = 0;
            int iLen = 0;
            int i = 0;

            sw.WriteLine(sPrefix);
            iBeg = 0;
            iLen = 0;

            for (i = 0; i < str.Length - 1; ++i)
            {
                iLen++;

                if (m_bits[i + 1] == 1)
                {
                    sw.WriteLine(str.Substring(iBeg, iLen));
                    iBeg = (int)i + 1;
                    iLen = 0;
                }
            }

            sw.WriteLine(str.Substring(iBeg));

            sw.Flush();
        }
    }

    /*
     * 类说明：从某个位置把句子分开，分为 左子句 和 右子句
     *
     */
    public class LeftRightStrPair
    {
        // 构造函数 
        // sLeft,左子句
        // sRight,右子句
        public LeftRightStrPair(string sLeft, string sRight)
        {
            m_sLeft = sLeft;
            m_sRight = sRight;
        }

        /*
         * 函数功能：分别获取 左子句 右子句 的最优分词方案， 然后拼接在一起
         * 参数说明：spsts，简单句分词器
         * 
         * 返回值：左 右 子句最优 分词的拼接
         * 
         */
        public OptRes CalcOptimal(SplitSents spsts)
        {
            if (m_sLeft == null)
            {
                MessageBox.Show("左子串 为空 ！！");
                return null;
            }
            else if (m_sRight == null)
            {
                MessageBox.Show("右子串 为空！！");
                return null;
            }

            //  左右 子串都不为空 才往下

            UInt32[] aRt = new UInt32[m_sLeft.Length + m_sRight.Length];

            CalcOptimalSplit LeftCalc = new CalcOptimalSplit(m_sLeft, spsts);
            CalcOptimalSplit RighCalc = new CalcOptimalSplit(m_sRight, spsts);

            OptRes leftOptSp = LeftCalc.CalcOptimal();
            OptRes righOptSp = RighCalc.CalcOptimal();

            // 还要以该位置 做词间检查 

            List<WordIndexPair> Lwip = GetWordIndexPairAtSplit(leftOptSp, righOptSp); //??这里是不是有点问题
            bool isValid= spsts.CheckProb_InterWord_WeakCheck(Lwip,m_sLeft+m_sRight);
            //bool isValid = spsts.CheckProb_InterWord(Lwip, m_sLeft + m_sRight);

            // 把左边最优 和右边最优拼接起来
            leftOptSp.m_bits.CopyTo(aRt, 0);
            righOptSp.m_bits.CopyTo(aRt, leftOptSp.m_bits.Length);

            OptRes op = new OptRes();

            op.m_bits = aRt; // 最优的分词方案

            if (isValid)
            {
                op.m_dsumH = leftOptSp.m_dsumH + righOptSp.m_dsumH; // 把结合力都加起来
            }
            else
            {
                op.m_dsumH = -9900; // 不符合弱检查 ，赋一个很小的数

            }

            return op;
        }

        /*
         * 函数功能：获取一个长句断开处（断开成 left、right子句）的 两个候选词， 以检查这两个候选词是否满足词间的弱检查条件
         * 参数说明：left，左子句
         *           right，右子句
         *           
         * 返回值：一个 候选词 对
         * 
         */
        private List<WordIndexPair> GetWordIndexPairAtSplit(OptRes left, OptRes right)
        {
            List<WordIndexPair> lrt = new List<WordIndexPair>();

            int beg = -1;
            int Nextbeg = -1;

            int i = 0;

            for (i = 0; i < left.m_bits.Length; ++i)
            {
                if (left.m_bits[i] == 1)
                {
                    beg = i; // 只需要最后一个
                }
            }

            Nextbeg = left.m_bits.Length;

            WordIndexPair wipL = new WordIndexPair(beg, Nextbeg); // 第一个候选词

            lrt.Add(wipL);

            // 

            Nextbeg = -1;

            for (i = 1; i < right.m_bits.Length; ++i)
            {
                if(right.m_bits[i] == 1)
                {
                    Nextbeg = i;
                    break;
                }
            }

            if (Nextbeg == -1) // 后面全是 0，没有1
            {
                Nextbeg = right.m_bits.Length;
            }

            beg = left.m_bits.Length;

            WordIndexPair wipR = new WordIndexPair(beg, Nextbeg + left.m_bits.Length);

            lrt.Add(wipR);

            return lrt;
        }

        public string m_sLeft = null;
        public string m_sRight = null;
    }

    /*
     * 类说明：用递归的方式计算 最优分词
     * 
     */

    public class CalcOptimalSplit
    {
        // 构造函数
        public CalcOptimalSplit(string str, SplitSents sps)
        {
            m_str = str;
            m_spsts = sps;
        }

        /*
         * 函数功能：计算最优分词
         * 参数说明：无
         * 返回值：无
         *
         */
        public OptRes CalcOptimal()
        {
            if (m_str == null || m_str.Length == 0)
            {
                return null;
            }

            if (m_str.Length < 10)
            {
                // 直接计算 最优分词 方案，
                // 对 aRt 进行赋值
                OptRes op = m_spsts.doSplit_JustGetOptimal(m_str);

                return op;

            }

            // 如果长度够长，需要再进行分解

            List<LeftRightStrPair> Lst = SplitString_at_Middle();
            List<OptRes> Lopt = new List<OptRes>();

            int i = 0;

            for (i = 0; i < Lst.Count; ++i)
            {
                OptRes op = Lst[i].CalcOptimal(m_spsts);
                Lopt.Add(op);
            }

            if (Lopt.Count == 0)
            {
                MessageBox.Show("奇怪！一种分解方案的 解居然为空！");
                return null;
            }

            OptRes optimal = Lopt[0];

            for (i = 1; i < Lopt.Count; ++i)
            {
                if (Lopt[i].m_dsumH > optimal.m_dsumH)
                {
                    optimal.m_dsumH = Lopt[i].m_dsumH;
                    optimal.m_bits = Lopt[i].m_bits;
                }
            }

            return optimal;
        }

        /*
         * 函数功能：把一个长句，从中间的位置分开，然后以中间位置为中心，返回maxWordLen 个 “左右句对”（LeftRightStrPair）
         *           maxWordLen 个“左右句对”的拆分位置，至少有一个被包含在最优分词中
         *           
         * 参数说明：无
         * 
         * 返回值：maxWordLen 个 “左右句对”
         * **/
        private List<LeftRightStrPair> SplitString_at_Middle()
        {
            List<LeftRightStrPair> lrt = new List<LeftRightStrPair>();

            int Middle = m_str.Length / 2;

            int j = 0;

            for (j = Middle - maxWordLen / 2+1; j < Middle + maxWordLen / 2+1; ++j)
            {
                string sLeft = m_str.Substring(0, j);
                string sRight = m_str.Substring(j);

                LeftRightStrPair lrsp = new LeftRightStrPair(sLeft, sRight);

                lrt.Add(lrsp);
            }

            return lrt;
        }


        private const UInt16 maxWordLen = 8;
        private string m_str = null;
        public SplitSents m_spsts = null;
    }
}
