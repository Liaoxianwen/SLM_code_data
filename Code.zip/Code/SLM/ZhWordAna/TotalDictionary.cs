﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.IO;

namespace ZhWordAna
{
    /*
     * 类说明：字典 对象
     * 
     * **/
    public class TotalDictionary
    {
        public TotalDictionary( string sDictname)
        {
            LoadWordDictionary(sDictname);
        }

        /*
    * 函数功能：加载微博字典， 需要显式 调用该函数
    * 参数说明：无
    * 返回值：无
    * 
    */
        public void LoadWordDictionary(string sDictFileName)
        {
            m_WordDic = new Dictionary<char, int>();

            StreamReader sr = new StreamReader(sDictFileName);        // 不要应编码
            //StreamReader sr = new StreamReader("ZhWordsBase.txt");
            //StreamReader sr = new StreamReader("ttwb.txt");
            string[] sp = { ":", "," };
            int i = 0;

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] sA = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);
                string sWord = sA[0];

                if (s[0] == ':' || s[0] == ',')
                {
                    sWord = s.Substring(0, 1);
                }
                else if (sWord.Length != 1)
                {
                    MessageBox.Show("有异常发生！加载字典的时候，得到长度大于1的字符串！！");
                }

                if (m_WordDic.ContainsKey(sWord[0])) // 处理 黑色菱形 问号的情况
                {
                    continue; // 黑色菱形不管出现多少次，只记录第一次的索引。其他字（key）的相对位置不变，那么索引不会乱
                    // 这个代码块在 合并 维基字典 和 微博字典的时候，会起作用
                    // 维基字典当中有很多 黑色的菱形，这些黑色的菱形是从维基文本中抽取出字 然后保存成字典时产生的，不知道为什么
                    // 变成黑色菱形的这些字，在入库时变成了陌生字（因为在字符串中 这些字不是黑色菱形）


                }

                m_WordDic[sWord[0]] = -1;  // 相当于把这个字添加到字典中去，但是字的下标还没添加
                m_WordDic[sWord[0]] = m_WordDic.Count - 1; // 数组的下标，方便再关联矩阵中进行索引

            }

            sr.Close();
            sr.Dispose();
        }

        public Dictionary<char, int> m_WordDic = null; // 字典，存储的是单词的索引，即 单词i：i，这样在数据库种存储索引即可
    }
}
