﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ZhWordAna
{
    public class ZHOOVStatics
    {
        public ZHOOVStatics()
        {
        }

        // 函数功能：计算 准确率 召回率 F值（ P R F ）
        public double Calc_P_R_F_oov()
        {
            int i = 0;
            int count = 0;
            double P = 0;
            double R = 0;
            double F = 0;

            Dictionary<string,int> actOOVs = GetActOOVs();
            Dictionary<string, int> candidateOOVs = Get_OOV_Candidate(GetWordsFromPKU_Training(),GetWordsFromPKU_Test());

            for (i = 0; i < candidateOOVs.Count; ++i)
            {
                KeyValuePair<string, int> kp = candidateOOVs.ElementAt(i);

                if (actOOVs.ContainsKey(kp.Key))
                {
                    count++;
                }
            }

            R= ((double)count) / actOOVs.Count;
            P = ((double)count) / candidateOOVs.Count;

            F = (2 * P * R) / (P + R);

            return F;
            

        }

        private Dictionary<string,int> GetActOOVs()
        {
            Dictionary<string,int> Dic = new Dictionary<string,int>();
            string sOOVFileName = "pku_oov__";
            int i = 0;
            string[] sp = { "," };

            for (i = 1; i < 8; ++i)
            {
                string sFN = sOOVFileName + i.ToString() + "_.txt";
                StreamReader sr = new StreamReader(sFN);

                while (!sr.EndOfStream)
                {
                    string sLine = sr.ReadLine();
                    string[] sA = sLine.Split(sp,StringSplitOptions.RemoveEmptyEntries);

                    if (sA.Length != 2)
                    {
                        continue;
                    }

                    Dic[sA[0]] = 1;

                }

                sr.Close();
                sr.Dispose();


            }
            return Dic;
        }

        private Dictionary<string, int> GetWordsFromPKU_Training()
        {
            string sFilename = "短句_pku_trainingNEW_original__pkumsr+目标函数结合力乘频次+词间校验 单词结合力.txt";

            return GetWordsFromSplitResFile(sFilename);
        }

        private Dictionary<string, int> GetWordsFromPKU_Test()
        {
            string sFilename = "短句_pku_test_original__分词结果.txt";

            return GetWordsFromSplitResFile(sFilename);
        }

        private Dictionary<string, int> GetWordsFromSplitResFile(string sFileName)
        {
            Dictionary<string, int> Dic = new Dictionary<string, int>();

            StreamReader sr = new StreamReader(sFileName);

            while (!sr.EndOfStream)
            {
                string sLine = sr.ReadLine();

                if (sLine.IndexOf(">NONE>:") > 0 || sLine.IndexOf(">__R_>:") > 0)
                {
                    continue;
                }

                Dic[sLine] = 1;

            }

            sr.Close();
            sr.Dispose();


            return Dic;
        }

        private Dictionary<string, int> Get_OOV_Candidate(Dictionary<string,int> BGDic,Dictionary<string,int> TestDic)
        {
            Dictionary<string, int> Dic = new Dictionary<string, int>();

            int i = 0;

            for (i = 0; i < TestDic.Count; ++i)
            {
                KeyValuePair<string, int> kp = TestDic.ElementAt(i);

                if (!BGDic.ContainsKey(kp.Key))
                {
                    Dic[kp.Key] = 1;
                }
            }

            return Dic;
        }

    }
}
