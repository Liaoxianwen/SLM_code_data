﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ZhWordAna
{
    /*
     * 类说明：微博语料库类。通过该类可以：
     * （1）统计微博语料库中字的频率；
     * （2）把1到8阶共现矩阵 写到数据库；
     * 
     * ***/
    public class WeiBoCorpus
    {
        /*
         * 函数说明：构造函数
         * 参数说明：无
         * 返回值：无
         * 
         */
        public WeiBoCorpus()
        {
            DirectoryInfo root = new DirectoryInfo(m_sPath);
            m_files = root.GetFiles();
            //LoadWordDictionary(); 需要显式 调用 该函数 
        }

        /*
         * 函数说明：统计语料库中的字符的频率，字符可以是中文字符，英文字母及各种中英文符号
         * 参数说明：无
         * 返回值：无
         * 
         */
        public void CharStatics()
        {

            if (m_files == null || m_files.Length == 0)
            {
                MessageBox.Show("语料库文件为空或者 没有预料文件！");
                return;
            }

            int i = 0;
            for (i = 0; i < m_files.Length; ++i)
            {
                //StreamReader sr = m_files[i].OpenText();
               // FileStream fs = m_files[i].OpenRead();
                StreamReader sr = new StreamReader(m_files[i].FullName,Encoding.Default);// 奇怪，必须用default ，用 utf8 或者 unicode 都乱码！！

                while (!sr.EndOfStream)
                {
                    string str = sr.ReadLine();
                    StatWords(str);
                }

                //  必须要释放资源，否则造成资源占用导致其他进程无法写入或删除
                sr.Close();
                sr.Dispose();
            }

            // 把词频按降序保存再文件中
            StreamWriter sw = new StreamWriter("ZhWords.txt",false);
            Dictionary<char, emergeTimes> dic1_SortedByVal = m_DWordIndx.OrderByDescending(o => o.Value.m_Cnt).ToDictionary(p => p.Key, o => o.Value);

            for (i = 0; i < dic1_SortedByVal.Count; ++i)
            {
                KeyValuePair<char, emergeTimes> kp = dic1_SortedByVal.ElementAt(i);
                sw.WriteLine(kp.Key + ":" + kp.Value.m_Indx.ToString() + "," + kp.Value.m_Cnt.ToString());
            }

            // 必须释放资源
            sw.Close();
            sw.Dispose();

        }

        /*
         * 函数功能：加载字典， 需要显式 调用该函数
         * 参数说明：无
         * 返回值：无
         * 
         */
        public void LoadWordDictionary()
        {
            m_WordDic = new Dictionary<char, int>();

            StreamReader sr = new StreamReader("ZhWordsBase.txt");
            string[] sp = { ":", "," };
            int i = 0;

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] sA = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);
                string sWord = sA[0];

                if(s[0] == ':' || s[0] == ',')
                {
                    sWord = s.Substring(0, 1);
                }
                else if (sWord.Length != 1 )
                {
                    MessageBox.Show("有异常发生！加载字典的时候，得到长度大于1的字符串！！");
                }

                if (m_WordDic.ContainsKey(sWord[0])) // 处理 黑色菱形 问号的情况
                {
                    continue; // 黑色菱形不管出现多少次，只记录第一次的索引。key的相对位置（索引）不变，那么索引不会乱
                }

                m_WordDic[sWord[0]] = -1;  // 相当于把这个字添加到字典中去，但是字的下标还没添加
                m_WordDic[sWord[0]] = m_WordDic.Count - 1; // 数组的下标，方便再关联矩阵中进行索引

            }

            sr.Close();
            sr.Dispose();
        }

        /*
         * 函数功能：对一个字符串中出现的字符进行统计
         * 参数说明：str，一个待统计字符的字符串
         * 返回值：无
         * 
         */
        private void StatWords(string str)
        {
            int i = 0;

            if (str == null || str.Length == 0)
            {
                return;
            }

            for (i = 0; i < str.Length; ++i)
            {
                // 如果之前已经发现了 存在一个字 ,出现的次数 + 1
                if (m_DWordIndx.ContainsKey(str[i]))
                {
                    m_DWordIndx[str[i]].m_Cnt++;
                    continue;
                }

                emergeTimes et = new emergeTimes();
                et.m_Cnt = 1;  // 新出现的单词，出现1次
                et.m_Indx = (UInt32)m_DWordIndx.Count;  // 单词在出现序列的下标，第1次是0，第2次是1

                m_DWordIndx[str[i]] = et;
            }
        }

        /*
         * 函数功能：把1到8阶 共现矩阵写入到数据库中去
         * 参数说明：无
         * 返回值：无
         * 
         */

        public void WriteCoExist2DB()
        {
            int i = 0;

            DBConn dbc = new DBConn();
 
            // 用来存储关联词的数量
            List<string> LSql = new List<string>();
            int NumOfSents = 0;

            int[] WordNum = new int[8];
            for (i = 0; i < 8; ++i)
            {
                WordNum[i] = 0; // 清零
            }

   

            for (i = 0; i < m_files.Length; ++i)
            {
                StreamReader sr = new StreamReader(m_files[i].FullName, Encoding.Default);
                string LongText = "";

                while (!sr.EndOfStream)
                {
                    LongText += sr.ReadLine(); // 把一个文件的内容变成一个 长长的 字符串
                }

                if (LongText.Length < 8) // 字符串的长度 太短了，直接跳过 ！！！ 
                {
                    continue;
                }

                NumOfSents++; // 句子数量 累加

                 //WordNum[0] += WriteString2DB(LongText, 1, dbc, LSql);
                 //WordNum[1] += WriteString2DB(LongText, 2, dbc, LSql);
                 //WordNum[2] += WriteString2DB(LongText, 3, dbc, LSql);
                  //WordNum[3] += WriteString2DB(LongText, 4, dbc, LSql);
                  //WordNum[4] += WriteString2DB(LongText, 5, dbc, LSql);
                  //WordNum[5] += WriteString2DB(LongText, 6, dbc, LSql);
                  //WordNum[6] += WriteString2DB(LongText, 7, dbc, LSql);
                  //WordNum[7] += WriteString2DB(LongText, 8, dbc, LSql);

                sr.Close();
                sr.Dispose();
            }
/*
            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库


            StreamWriter sw = new StreamWriter("4,5,6阶词写入结果统计.txt", false);
            sw.WriteLine("分句的数量：" + NumOfSents.ToString());

            for (i = 0; i < 8; ++i)
            {
                sw.WriteLine((i + 1).ToString() + "阶词的数量：" + WordNum[i].ToString());
            }

            sw.Close();
            sw.Dispose();*/

            MessageBox.Show("1-8阶词写入数据库完成！");
        }

        /*
         * 函数功能：把一个字符串 按 特定的阶数 写入到数据库中去 
         * 参数说明：str,一个字符串
         *           odr,阶数
         *           dbc,数据库连接
         *           
         * 返回值 :该阶数 “关联词”的数量
         * 
         */

        private int WriteString2DB(string str, int odr, DBConn dbc, List<string> LSql)
        {
            if (odr <= 0)
            {
                MessageBox.Show("发生了异常！odr <= 0 !");
                return 0;
            }

            if (str == null)
            {
                MessageBox.Show("发生了异常！把要写入数据库的str 居然是 null ！");
                return 0;
            }

            int i = 0;
            int j = 0;
            int []wordIndxs = new int[odr];

            for (i = 0; i < str.Length- odr + 1 ; ++i)
            {
                for (j = 0; j < odr; ++j)
                {
                    wordIndxs[j] = m_WordDic[str[i+j]]; // 写词的索引。数据库里面存的是索引
                }

                string sql = CreateSqlStatement(wordIndxs);
                LSql.Add(sql);

                if (LSql.Count > 600)
                {
                    dbc.WriteWCO2DB(LSql);  // 批量写入到数据库中去
                    LSql.Clear();           // 写完了要清空数据库
                }

            }

            return str.Length - odr +1;
        }

        private string CreateSqlStatement(int[] wordIndxs)
        {
            if (wordIndxs.Length <= 0)
            {
                return "";
            }

            int odr = wordIndxs.Length;
            int i = 0;

            string sql = "insert into tbl" + odr.ToString() + " values(" + wordIndxs[0].ToString();

            for (i = 1; i < odr; ++i)
            {
                sql += "," + wordIndxs[i].ToString();
            }

            sql += ",1) on duplicate key update coe=coe+1; ";

            return sql;

        }



        public FileInfo[] m_files = null;
        private Dictionary<char, emergeTimes> m_DWordIndx = new Dictionary<char,emergeTimes>();
        public string m_sPath = @"D:\C_Sharp_Proj\ViWordAna\ZhWordAna\WeiboCorpus";
        public Dictionary<char, int> m_WordDic = null; // 字典，存储的是单词的索引，即 单词i：i，这样在数据库种存储索引即可
    }
}
