﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZhWordAna;

namespace ZhWordAna
{
    /*
     * 类说明：负责从数据库中 查询数据，计算条件概率。
     *         使用缓存机制，不重复计算条件概率，提升效率
     * 
     * **/
    public class CalcProbCond
    {
        public CalcProbCond(DBConn db, Dictionary<char, int> wordDic)
        {
            m_db = db;

            m_wordDic = wordDic;
            
            m_DicProHasCalc = new Dictionary<string, int>();
        }

        /*
         * 函数功能：计算条件概率 P(B|A)的对数值 ,通常计算的条件概率是：P(w4,w5,w6,w7|w1,w2,w3)
         * 参数说明：A，字数组，A={w1,w2,w3...}
         *           B, 字数组, B={w5,w6,w7...}
         * 返回值：P(B|A),（已经过对数变换）
         * **/
        public Decimal CalcProb(char[] A, char[] B)
        {
            if (A == null || B == null || A.Length == 0 || B.Length == 0)
            {
                MessageBox.Show("计算条件概率的 字数组为null 或者 没有元素 ~！\n");
                return 0M;
            }

            if (A.Length + B.Length >= 9)
            {
                MessageBox.Show("阶数太高,超过8阶，计算不了\n A的阶数="+A.Length.ToString() + "\nB的阶数="+ B.ToString() );
                return 0M;

            }

            int odr = A.Length + B.Length;
            char[] T = new char[ odr];
            

            A.CopyTo(T, 0);
            B.CopyTo(T, A.Length);

            Decimal p_A = CalcProb(A, odr);
            Decimal p_AB = CalcProb(T, odr);

            Decimal p = p_AB-p_A;
            return p;
        }

        /*
         * 函数功能：计算 AB 的聚合度。 
         *                             P(AB)
         *              h(A,B) =  Log ————
         *                            P(A)P(B)
         * 参数说明：A，单字序列
         *           B, 单字序列
         *           
         * 返回值：AB的聚合度
         *
         */

        public Decimal CalcH_AB(char[]A, char[] B)
        {
            Decimal h = 0M;

            if (A == null || B == null)
            {
                MessageBox.Show("计算 AB 的聚合度时 A==null 或者 B==null\n");
                return -10000M;
            }

            Decimal LogpAB = CalcProb_AandB(A, B);
            Decimal LogpA  = CalcProb(A, A.Length);
            Decimal LogpB  = CalcProb(B, B.Length);

            h = LogpAB - (LogpA + LogpB);

            //return h*GetWordNum(A,B);
            return h;
        }

        /*
         * 函数功能：计算概率 P(AB) 的对数值 ,通常计算的概率是：P(w1,w2,w3 &&w4,w5) 等
         * 参数说明：A，字数组，A={w1,w2,w3...}
         *           B, 字数组，B={w4,w5}
         *          
         * 返回值：P(AB)的对数值
         * **/

        public Decimal CalcProb_AandB(char[] A,char []B)
        {
            if (A == null || B == null)
            {
                MessageBox.Show("计算P（AB）的时候，A B中有一个为空！" );
                return -10000M;
            }

            char []T = new char[A.Length + B.Length];
            A.CopyTo(T,0);
            B.CopyTo(T, A.Length);

            return CalcProb(T,T.Length);
        }

        /*
         * 函数功能：计算概率 P(A) 的对数值 ,通常计算的概率是：P(w1,w2,w3)
         * 参数说明：A，字数组，A={w1,w2,w3...}
         *           odr, 阶数。注：这个阶数大部分情况下等于 A.Length，但是在计算条件概率时，odr可能会大于 A.Length
         * 返回值：P(A)的对数值
         * 
         * **/
        public Decimal CalcProb(char[] A,int odr)
        {
            Decimal p = 0;

            if (A == null || A.Length == 0)
            {
                MessageBox.Show("计算概率出错！\n A="+ A.ToString());

                return -10000M;
            }

            if (A.Length > 8 || odr > 8) // 太长了，计算不了
            {
                return -10000M;
            }

            int []ia = new int[A.Length];
            int i = 0;

            for (i = 0; i < A.Length; ++i)
            {
                if (!m_wordDic.ContainsKey(A[i]))
                {
                    MessageBox.Show("发现陌生的单词，概率无法计算！\n" + A.ToString());
                    return -10000M;
                }

                ia[i] = m_wordDic[A[i]];
            }

            string sIndx = GetIndexStr(ia,odr);  // 注意这里指定了阶数，并不是 A.Length

            int wdNum = 0;

            if (m_DicProHasCalc.ContainsKey(sIndx))
            {
                wdNum = m_DicProHasCalc[sIndx];  // 存在，直接用缓存赋值
            }
            else
            {
                if (m_DicProHasCalc.Count > 5000000)
                {
                    m_DicProHasCalc.Clear(); // 太多了就清楚的缓存
                }

                wdNum = m_db.GetWordNumFromDB(ia, odr);  // 不存在，再去查找数据库

                m_DicProHasCalc[sIndx] = wdNum;          // 存起来，后面再用
                
            }

            if (wdNum == 0)
            {
                p = -10000M; // 很小很小的概率值
            }
            else
            {
                p = (Decimal)Math.Log10((double)(wdNum / m_WordNum[odr - 1]));
            }

            return p;
        }

        /*
         * 函数功能：获取关联词 A 的出现次数，要么从缓存获取，要么从数据库获取
         * 参数说明：A, 关联词
         * 
         * 返回值：关联词的出现次数
         */

        public int GetWordNum(char[] A)
        {

            if (A == null || A.Length == 0)
            {
                MessageBox.Show("计算关联词的出现次数出错！\n A=" + A.ToString());

                return 0;
            }

            if (A.Length > 8) // 太长了，计算不了
            {
                return 0;
            }

            int[] ia = new int[A.Length];
            int i = 0;

            for (i = 0; i < A.Length; ++i)
            {
                if (!m_wordDic.ContainsKey(A[i]))
                {
                    MessageBox.Show("发现陌生的单词，关联词的出现次数无法计算！\n" + A.ToString());
                    return 0;
                }

                ia[i] = m_wordDic[A[i]];
            }

            string sIndx = GetIndexStr(ia,A.Length); // 索引字符串 

            int wdNum = 0;

            if (m_DicProHasCalc.ContainsKey(sIndx))
            {
                wdNum = m_DicProHasCalc[sIndx];  // 存在，直接用缓存赋值
            }
            else
            {
                wdNum = m_db.GetWordNumFromDB(ia, A.Length);  // 不存在，再去查找数据库

                m_DicProHasCalc[sIndx] = wdNum;               // 存起来，后面再用
                
            }

            return wdNum;
        }

        /*
         * 函数功能：获取 A和B拼接而成的字符串的出现次数
         * 参数说明：
         * 
         * 返回值：出现次数
         */
        public int GetWordNum(char[] A, char[] B)
        {
            if (A == null || B == null)
            {
                return 0;
            }
            else if (A.Length + B.Length > 8)
            {
                return 0;
            }

            char []T= new char[A.Length+B.Length];

            A.CopyTo(T, 0);
            B.CopyTo(T,A.Length);

            return GetWordNum(T);

        }


        /*
         * 函数功能：把所有序列拼接成字符串 ，用于概率计算结果的索引
         * 参数说明：iArr，索引数组
         * 返回值：拼接的字符串
         * **/

        private string GetIndexStr(int [] iArr, int odr )
        {
            if (iArr == null || iArr.Length == 0)
            {
                return "";
            }

            int j = 0;
            string sIndx = iArr[0].ToString();

            for (j = 1; j < iArr.Length; ++j)
            {
                sIndx += "_" + iArr[j].ToString();
            }

            sIndx += "_R" + odr.ToString();

            return sIndx;
        }


        /*
         * 函数功能：更新K阶词的估算
         * 参数说明：
         * 
         * **/

        public void UpdateWordNum(int SentNum,int []DeltaAssociateWordNum)
        {
            if (DeltaAssociateWordNum.Length != 8)
            {
                MessageBox.Show("Delta 关联词表的阶数 不对！");
                return;
            }

            int i = 0;

            for (i = 0; i < 8; ++i)
            {
                m_AssociatedWordNum[i] += DeltaAssociateWordNum[i];
            }

            m_SentsNum += SentNum;

            //m_WordNum[0] = m_AssociatedWordNum[0];

            for (i = 0; i < 8; ++i)
            {
                m_WordNum[i] = (m_AssociatedWordNum[i] + 2 * i * m_SentsNum) / (2 * i + 1);
            }

        }


        private DBConn m_db = null;
        Dictionary<char, int> m_wordDic;
        public Dictionary<string, int> m_DicProHasCalc;


        // 在 统一 8阶的句子长度 下，对各阶词 进行 的 估算（只有1阶是最准确的）

        // 1-8阶关联词的数量, 各阶数据库表中 SUM（coe）的数量, 这是msr 训练集 入库， 现在用 msr 和 pku的训练集 做背景数据库
        Decimal[] m_AssociatedWordNum = { 4050470,
                                          4041777,
                                          4033084,
                                          4024391,
                                          4015698,
                                          4007005,
                                          3998312,
                                          3989619
                                        };
        int m_SentsNum = 8693; // 句子的数量




        // 使用k阶词数量估算公司 计算，
        Decimal[] m_WordNum = {   0, // 一阶词的计算值      会随着delta数据库动态改变      
                                  0,  // 二阶词的估算值     会随着delta数据库动态改变
                                  0,  // 三阶词的估算值     会随着delta数据库动态改变
                                  0,  // 四阶词的估算值     会随着delta数据库动态改变
                                  0,  // 五阶词的估算值     会随着delta数据库动态改变
                                  0,  // 六阶词的估算值     会随着delta数据库动态改变
                                  0,   // 七阶词的估算值    会随着delta数据库动态改变
                                  0 }; // 八阶词的估算值，  会随着delta数据库动态改变



        
    }
}
