﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace ZhWordAna
{
    public class CommFun
    {
        public CommFun()
        {
        }


        /*
         * 函数功能：根据索引数组 和 数据库表（等价于是哪个数据库） 生成 sql 语句
         * 参数说明：wordIndxs，索引数组
         *           sTblType，表的类型，例如 微博数据库 ，wiki数据库等
         * **/

        public static string CreateSqlStatement(int[] wordIndxs, string sTblType)
        {
            if (wordIndxs.Length <= 0)
            {
                return "";
            }

            int odr = wordIndxs.Length;
            int i = 0;

            string sql = "insert into " + sTblType + odr.ToString() + " values(" + wordIndxs[0].ToString();

            for (i = 1; i < odr; ++i)
            {
                sql += "," + wordIndxs[i].ToString();
            }

            sql += ",1) on duplicate key update coe=coe+1; ";

            return sql;
        }

        /*
         * 函数功能：把一个字符串 按 特定的阶数 写入到数据库中去 
         * 参数说明：str,一个字符串
         *           odr,阶数
         *           dbc,数据库连接
         *           
         * 返回值 :该阶数 “关联词”的数量
         * 
         */

        public static int WriteString2DB(string str, int odr, DBConn dbc, List<string> LSql, Dictionary<char, int> WordDic, string sTblType)
        {
            if (odr <= 0)
            {
                MessageBox.Show("发生了异常！odr <= 0 !");
                return 0;
            }

            if (str == null)
            {
                MessageBox.Show("发生了异常！把要写入数据库的str 居然是 null ！");
                return 0;
            }

            int i = 0;
            int j = 0;
            int[] wordIndxs = new int[odr];

            for (i = 0; i < str.Length - odr + 1; ++i)
            {

                for (j = 0; j < odr; ++j)
                {
                    wordIndxs[j] = WordDic[str[i + j]]; // 写词的索引。数据库里面存的是索引
                }
                
                string sql = CreateSqlStatement(wordIndxs, sTblType);
                LSql.Add(sql);

                if (LSql.Count > 4500)
                {
                    dbc.WriteWCO2DB(LSql);  // 批量写入到数据库中去
                    LSql.Clear();           // 写完了要清空数据库
                }

            }

            return str.Length - odr + 1;
        }

    }
}
