﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace ZhWordAna
{
    public class DBConn
    {

       public MySqlConnection m_mysqlConn;
        
       public DBConn()
        {
            m_sUserName = "";
            m_sDbConn = "Server=127.0.0.1;Database=zhvdb;Uid=root;Pwd=123456;CharSet=utf8; Allow User Variables=True;";

            InitDBconn();

            m_mysqlCmd = new MySqlCommand();
            m_mysqlCmd.Connection = m_mysqlConn;
        }

       ~DBConn()
       {
           CloseDbConn();
       }

        /*
         * 函数功能：初始化数据库连接
         * 
         */
       private void InitDBconn()
       {
           try
           {
               m_mysqlConn = new MySqlConnection();
               m_mysqlConn.ConnectionString = m_sDbConn; // 设置连接字符串

               m_mysqlConn.Open(); // 打开连接

           }
           catch (MySqlException ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       /*
        * 函数功能：把一批 sql 语句当事务来处理。
        * 参数说明：LSql，一批sql 语句
        * 返回值：无
        */
       public void  WriteWCO2DB( List<string> LSql )
       {

          // string sQueryString = "insert into tbl set w0=" + w0.ToString() + ",w1=" + w1.ToString() + ",w2=" + w2.ToString() + ",coe=1 on duplicate key update coe=coe+1; ";
          // string sQueryString = "insert into tbl values(" + w0.ToString() + "," + w1.ToString() + "," + w2.ToString() + ",coe=1); ";

           MySqlTransaction ta = m_mysqlConn.BeginTransaction();

           try
           {
               MySqlCommand mysqlCmd = new MySqlCommand( );
               mysqlCmd.Connection = m_mysqlConn;
               mysqlCmd.Transaction = ta;

               int i = 0;

               for (i = 0; i < LSql.Count; ++i)
               {
                   mysqlCmd.CommandText = LSql[i];
                   mysqlCmd.ExecuteNonQuery();
               }

               ta.Commit();
           }
           catch( System.Exception ee)
           {
               MessageBox.Show("RollBack 发生！\n" + ee.ToString());

               ta.Rollback();
               MessageBox.Show("写入关联表时发生了错误！事务已经回滚！\n"+ ee.ToString());
           }
       }

        /*
         * 函数功能：删除new word 增量表
         * 参数说明：无
         * 返回值：无
         * **/
       public void ClearDeltaNewWordDB()
       {
           MySqlTransaction ta = m_mysqlConn.BeginTransaction();

           try
           {
               MySqlCommand mysqlCmd = new MySqlCommand();
               mysqlCmd.Connection = m_mysqlConn;
               mysqlCmd.Transaction = ta;

               int i = 0;

               for (i = 0; i < 8 ; ++i)
               {
                   mysqlCmd.CommandText = " DELETE FROM deltatbl"+(i+1).ToString();
                   mysqlCmd.ExecuteNonQuery();
               }

               ta.Commit();
           }
           catch (System.Exception ee)
           {
               MessageBox.Show("RollBack 发生！\n" + ee.ToString());

               ta.Rollback();
               MessageBox.Show("删除增量表时发生了错误！事务已经回滚！\n" + ee.ToString());
           }
       }

       /*
        * 函数功能：获得数组 i 的出现次数
        *           tblno 可能要比 i.Length 大
        *           
        * 参数说明：sDBName，数据库表的前缀
        *           i数组，1阶词，2阶词，3阶词
        *           tblno，数据库表的编号
        *           
        * 返回值：词出现的次数
        * 
        */
       public int GetWordNumFromDB( string sDBName,int[] i, int tblno )
       {
           int rt = 0;

           if (i == null || i.Length == 0)
           {
               return 0;
           }
           
           if (i.Length > 8)
           {
               MessageBox.Show("不支持这么多的字段查询！字段数量等于：" + i.Length);
               return 0;
           }

           string sCmd = "select sum(coe) from " + sDBName + tblno.ToString() + "  where w0=" + i[0].ToString();

           int k = 0;

           for (k = 1; k < i.Length; ++k)
           {
               sCmd += " and w" + k.ToString() + " = " + i[k].ToString();
           }

           try
           {
               //MySqlCommand mysqlCmd = new MySqlCommand(sCmd, m_mysqlConn);
               m_mysqlCmd.CommandText = sCmd;
               MySqlDataReader myReader = m_mysqlCmd.ExecuteReader();

               while(myReader.Read())
               {
                   //string strt = (string)myReader[0]; //类型转换不对时，可以用这句话来试错

                   if (myReader.IsDBNull(0))
                   {
                       break;
                   }

                   rt = (int)((Decimal)myReader[0]);
               }

               myReader.Close();
           }
           catch (System.Exception ee)
           {
               MessageBox.Show("读数据库时 发生了错误！\n<sql 语句："+ sCmd+">\n" + ee.ToString());
           }

           return rt;
       }

       /*
        * 函数功能：从多个表中获取 关联词i 的出现次数
        * 参数说明：i，关联词i的索引数组
        *           tblno，表号
        *         
        * 返回值：关联词的出现次数
        * 
        * **/
       public int GetWordNumFromDB(int[] i, int tblno)
       {
           int n0 = GetWordNumFromDB("cwspkumsrtrain", i, tblno);
           //int n1 = GetWordNumFromDB("cwspkutest", i, tblno);
           int n1 = GetWordNumFromDB("cwsmsrtest", i, tblno);
           //int n2 = GetWordNumFromDB("pkutest_tbl", i, tblno);
           
           return n0+n1;
       }

        /*
         * 函数功能：获取 候选词 的 左 邻接字的数量的集合
         * 参数说明:i2，候选词字符索引
         * 返回值：左邻接字 的数量 的集合
         *
         */
       public List<int> Get_Left_AdjNum(int[]i2)
       {
           List<int> Lrt = new List<int>();

           if (i2.Length >= 8)
           {
               return Lrt;
           }

           int tblno = i2.Length + 1;

           string sCmd = "select coe from tbl" + tblno.ToString() + "  where w1=" + i2[0].ToString();// 从w1开始，w0是左邻接字符

           int k = 0;

           for (k = 1; k < i2.Length; ++k)
           {
               sCmd += " and w" + (k+1).ToString() + " = " + i2[k].ToString();
           }

           try
           {
               m_mysqlCmd.CommandText = sCmd;
               MySqlDataReader myReader = m_mysqlCmd.ExecuteReader();

               while (myReader.Read())
               {
                   //string strt = (string)myReader[0]; //类型转换不对时，可以用这句话来试错

                   if (myReader.IsDBNull(0))
                   {
                       break;
                   }

                   int rt = (int)((Int32)myReader[0]);
                   Lrt.Add(rt);
               }

               myReader.Close();
           }
           catch (System.Exception ee)
           {
               MessageBox.Show("读 左邻接字符集 时 发生了错误！\n<sql 语句：" + sCmd + ">\n" + ee.ToString());
           }

           return Lrt;
       }

       /*
        * 函数功能：获取 候选词 的 右 邻接字的数量的集合
        * 参数说明:i1，候选词字符索引
        * 返回值：右邻接字 的数量 的集合
        *
        */
       public List<int> Get_Right_AdjNum(int[] i1)
       {
           List<int> Lrt = new List<int>();

           if (i1.Length >= 8)
           {
               return Lrt;
           }

           int tblno = i1.Length + 1;

           string sCmd = "select coe from tbl" + tblno.ToString() + "  where w0=" + i1[0].ToString();// 从w0开始，wn是右邻接字符

           int k = 0;

           for (k = 1; k < i1.Length; ++k)
           {
               sCmd += " and w" + k.ToString() + " = " + i1[k].ToString();
           }

           try
           {
               m_mysqlCmd.CommandText = sCmd;
               MySqlDataReader myReader = m_mysqlCmd.ExecuteReader();

               while (myReader.Read())
               {
                   //string strt = (string)myReader[0]; //类型转换不对时，可以用这句话来试错

                   if (myReader.IsDBNull(0))
                   {
                       break;
                   }

                   int rt = (int)((Int32)myReader[0]);
                   Lrt.Add(rt);
               }

               myReader.Close();
           }
           catch (System.Exception ee)
           {
               MessageBox.Show("读 右邻接字符集 时 发生了错误！\n<sql 语句：" + sCmd + ">\n" + ee.ToString());
           }

           return Lrt;
       }


       private void CloseDbConn()
       {
           m_mysqlConn.Close(); // 关闭数据库连接
       }

       public static string m_sUserName; // 记录当前登陆的用户名称
       public static string m_sDbConn;   // 数据库连接字符串

       public UInt32[] m_WordNums = null;  

       private MySqlCommand m_mysqlCmd;

    }
}
