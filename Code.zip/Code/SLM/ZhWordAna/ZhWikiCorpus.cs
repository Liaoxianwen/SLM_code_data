﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Windows.Forms;

namespace ZhWordAna
{
    public class ZhWikiCorpus
    {
        public ZhWikiCorpus()
        {
        }

        /*
         * 函数功能：加载 一个总的 基准字典
         * 参数说明：无 
         * 返回值：无
         * **/
        public void LoadWordDictionary()
        {
            m_WordDic = new Dictionary<char, int>();

            StreamReader sr = new StreamReader("TotalDicBase.txt");
            string[] sp = { ":", "," };
            int i = 0;

            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] sA = s.Split(sp, StringSplitOptions.RemoveEmptyEntries);
                string sWord = sA[0];

                if (s[0] == ':' || s[0] == ',')
                {
                    sWord = s.Substring(0, 1);
                }
                else if (sWord.Length != 1)
                {
                    MessageBox.Show("有异常发生！加载字典的时候，得到长度大于1的字符串！！");
                }

                if (m_WordDic.ContainsKey(sWord[0])) // 处理 黑色菱形 问号的情况
                {
                    continue; // 黑色菱形不管出现多少次，只记录第一次的索引。key的相对位置（索引）不变，那么索引不会乱
                }

                m_WordDic[sWord[0]] = -1;  // 相当于把这个字添加到字典中去，但是字的下标还没添加
                m_WordDic[sWord[0]] = m_WordDic.Count - 1; // 数组的下标，方便再关联矩阵中进行索引

            }

            sr.Close();
            sr.Dispose();
        }

        /*
         * 函数功能：把1到8阶 共现矩阵写入到数据库中去
         * 参数说明：无
         * 返回值：无
         * 
         */

        public void WriteCoExist2DB()
        {
            int i = 0;
            int j = 0;

            DBConn dbc = new DBConn();

            string sTbl = "";

            // 用来存储关联词的数量
            List<string> LSql = new List<string>();
            int NumOfSents = 0;

            int[] WordNum = new int[8];
            for (i = 0; i < 8; ++i)
            {
                WordNum[i] = 0; // 清零
            }

            string[] wikiFiles = { @"D:\C_Sharp_Proj\ViWordAna\pku\CWS-Master\msr\msr_test__shortSents4StatisticalSeg" };
            string sDBTblName = "cwsmsrtest";

            string sLine = "";

            LoadWordDictionary();

            for (i = 0; i < wikiFiles.Length; ++i)
            {
               // List<string> lst = getDocString(wikiFiles[i]);
                List<string> lst = getDocStringFromPKUMSR(wikiFiles[i]);

                for (j = 0; j < lst.Count; ++j)
                {
                    sLine = lst[j];

                      WordNum[0] += CommFun.WriteString2DB(sLine, 1, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[1] += CommFun.WriteString2DB(sLine, 2, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[2] += CommFun.WriteString2DB(sLine, 3, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[3] += CommFun.WriteString2DB(sLine, 4, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[4] += CommFun.WriteString2DB(sLine, 5, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[5] += CommFun.WriteString2DB(sLine, 6, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[6] += CommFun.WriteString2DB(sLine, 7, dbc, LSql, m_WordDic, sDBTblName);
                      WordNum[7] += CommFun.WriteString2DB(sLine, 8, dbc, LSql, m_WordDic, sDBTblName);

                    m_tbProgress.Text = i.ToString() + "--->:" + j.ToString();
                }

                NumOfSents += lst.Count; // 句子数量 累加
            }

            dbc.WriteWCO2DB(LSql); // 把 LSql 中剩余的语句写入到数据库
            
            StreamWriter sw = new StreamWriter(sTbl +"CWSMasterMSRTest数据写入结果统计1-8阶.txt", false);
            sw.WriteLine("分句的数量：" + NumOfSents.ToString());

            for (i = 0; i < 8; ++i)
            {
                sw.WriteLine((i + 1).ToString() + "阶词的数量：" + WordNum[i].ToString());
            }

            sw.Close();
            sw.Dispose();

            MessageBox.Show(sTbl+"词写入数据库完成！");
            m_btn.Enabled = true;
        }


        /*
         * 函数功能：从维基 数据文件中 读取 <doc > 和 </doc> 之间的 字符串
         *           最后还进行了过滤陌生字的操作
         *           
         * 参数说明：sFileName， 维基数据文件
         * 
         * 返回值：维基数据文件中 字符串列表（ 相当于一篇文章一个字符串）
         * 
         * **/

        private List<string> getDocString(string sFileName)
        {
            List<string> lst = new List<string>();
            string sLine = null;
            string sLongLine = "";

            StreamReader sr = new StreamReader(sFileName, Encoding.UTF8);

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();

                if ((sLine.IndexOf("<doc") >= 0 && sLine.IndexOf("<doc") <= 2) ||
                    (sLine.IndexOf("</doc>") >= 0 && sLine.IndexOf("</doc>") <= 2))     // 找到开始句 和结束句
                {
                    if (sLongLine.Length > 8)
                    {
                        lst.Add(sLongLine);
                    }

                    sLongLine = "";
                    continue;
                }

                sLongLine += sLine;
            }

            if (sLongLine.Length > 8)
            {
                lst.Add(sLongLine);
            }

            sr.Close();
            sr.Dispose();

            return stringSplitbyUnkownword(lst);
        }

        /*
         * 函数功能：从pku、msr文件中提取字符串，以10个原始串为单位拼接起来！
         *           最后还以陌生字为边界 进行拆分          
         * 
         * 参数说明：sFileName，文件名
         *        
         * 返回值：字符串列表
         */
        private List<string> getDocStringFromPKUMSR(string sFileName)
        {
            List<string> Lrt = new List<string>();

            string sLine = null;
            string sLongLine = "";

            StreamReader sr = new StreamReader(sFileName);
            int cnt = 0;
            int LineInFile = 0;

            while (!sr.EndOfStream)
            {
                sLine = sr.ReadLine();
                sLongLine += sLine;
                cnt++;
                
                if (cnt % 10 == 0)
                {
                    Lrt.Add(sLongLine);
                    sLongLine = "";
                    cnt=0;
                }

                LineInFile++;
       
            }

            if (sLongLine.Length > 8)
            {
                Lrt.Add(sLongLine);
            }

            sr.Close();
            sr.Dispose();

            return stringSplitbyUnkownword(Lrt); 
        }

        /*
         * 函数功能： 从维基数据文件中读取到的 字符串 可能包含 不在字典中的 陌生 字，因此要在陌生字处断开
         *            为什么会包含 陌生 字，可能是字符编码的原因
         * 参数说明：Lin，从维基数据文件中读取到的原始字符串
         * 
         * 返回值：从陌生字 处 断开 后 所得的 字符串
         * 
         * **/

        private List<string> stringSplitbyUnkownword(List<string> Lin)
        {
            List<string> Lrt = new List<string>();
            int i = 0;

            for (i = 0; i < Lin.Count; ++i)
            {
                string sLine = Lin[i];
                string sNewLine = "";
                int j = 0;

                for (j = 0; j < sLine.Length; ++j)
                {
                    if (m_WordDic.ContainsKey(sLine[j]))
                    {
                        sNewLine += sLine[j];
                    }
                    else
                    {
                        if (sNewLine.Length >= 8)
                        {
                            Lrt.Add(sNewLine);
                        }

                        sNewLine = "";
                    }
                }


                if (sNewLine.Length >= 8)
                {
                    Lrt.Add(sNewLine);
                }
            }


            return Lrt;
        }

        public void StatistNewWord( string sFileName)
        {
            LoadWordDictionary();

            StreamReader sr = new StreamReader(sFileName);
            StreamWriter sw = new StreamWriter("newwords.txt",false);

            string sL = "";
            int j = 0;

            int TotalWords = 0;

            while (!sr.EndOfStream)
            {
                sL = sr.ReadLine();

                for (j = 0; j < sL.Length; ++j)
                {
                    if (!m_WordDic.ContainsKey(sL[j]))
                    {
                        sw.WriteLine(sL[j].ToString());
                    }

                    TotalWords++;
                }

            }

            sr.Dispose();
            sw.Dispose();

        }

        private Dictionary<char, emergeTimes> m_DWordIndx = new Dictionary<char, emergeTimes>();
        private string m_FilePath = @"D:\C_Sharp_Proj\ViWordAna\zhWiki";

        Dictionary<char, int> m_WordDic = null;

        public bool m_isTbl4 = false;
        public bool m_isTbl5 = false;
        public bool m_isTbl6 = false;
        public bool m_isTbl7 = false;
        public bool m_isTbl8 = false;

        public string m_dataDir = "";

        public TextBox m_tbProgress = null;

        public Button m_btn=null;

    }
}
