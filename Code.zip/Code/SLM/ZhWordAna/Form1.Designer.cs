﻿namespace ZhWordAna
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.m_btnCharStatics = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.m_btn8Split = new System.Windows.Forms.Button();
            this.m_btnStaticWikiw = new System.Windows.Forms.Button();
            this.m_btnTest = new System.Windows.Forms.Button();
            this.m_btnWiki2DB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.m_dataDir = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.m_rb4 = new System.Windows.Forms.RadioButton();
            this.m_rb5 = new System.Windows.Forms.RadioButton();
            this.m_rb6 = new System.Windows.Forms.RadioButton();
            this.m_rb7 = new System.Windows.Forms.RadioButton();
            this.m_rb8 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.m_tbWriteInProgress = new System.Windows.Forms.TextBox();
            this.m_btnZhFileSplit = new System.Windows.Forms.Button();
            this.m_btnPKU2DB = new System.Windows.Forms.Button();
            this.m_btnMSR2DB = new System.Windows.Forms.Button();
            this.m_btnPkuTest2DB = new System.Windows.Forms.Button();
            this.m_btnPKUMSRCWSMaster = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_btnCharStatics
            // 
            this.m_btnCharStatics.Enabled = false;
            this.m_btnCharStatics.Location = new System.Drawing.Point(30, 22);
            this.m_btnCharStatics.Name = "m_btnCharStatics";
            this.m_btnCharStatics.Size = new System.Drawing.Size(66, 35);
            this.m_btnCharStatics.TabIndex = 0;
            this.m_btnCharStatics.Text = "中文微博字符统计";
            this.m_btnCharStatics.UseVisualStyleBackColor = true;
            this.m_btnCharStatics.Click += new System.EventHandler(this.m_btnCharStatics_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(30, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 51);
            this.button1.TabIndex = 1;
            this.button1.Text = "生成关联矩阵（1到8阶）";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // m_btn8Split
            // 
            this.m_btn8Split.Location = new System.Drawing.Point(30, 178);
            this.m_btn8Split.Name = "m_btn8Split";
            this.m_btn8Split.Size = new System.Drawing.Size(75, 23);
            this.m_btn8Split.TabIndex = 2;
            this.m_btn8Split.Text = "8阶分词";
            this.m_btn8Split.UseVisualStyleBackColor = true;
            this.m_btn8Split.Click += new System.EventHandler(this.m_btn8Split_Click);
            // 
            // m_btnStaticWikiw
            // 
            this.m_btnStaticWikiw.Enabled = false;
            this.m_btnStaticWikiw.Location = new System.Drawing.Point(13, 350);
            this.m_btnStaticWikiw.Name = "m_btnStaticWikiw";
            this.m_btnStaticWikiw.Size = new System.Drawing.Size(93, 38);
            this.m_btnStaticWikiw.TabIndex = 3;
            this.m_btnStaticWikiw.Text = "wiki中文字符统计";
            this.m_btnStaticWikiw.UseVisualStyleBackColor = true;
            this.m_btnStaticWikiw.Click += new System.EventHandler(this.m_btnStaticWikiw_Click);
            // 
            // m_btnTest
            // 
            this.m_btnTest.Location = new System.Drawing.Point(737, 365);
            this.m_btnTest.Name = "m_btnTest";
            this.m_btnTest.Size = new System.Drawing.Size(75, 23);
            this.m_btnTest.TabIndex = 4;
            this.m_btnTest.Text = "test";
            this.m_btnTest.UseVisualStyleBackColor = true;
            this.m_btnTest.Click += new System.EventHandler(this.m_btnTest_Click);
            // 
            // m_btnWiki2DB
            // 
            this.m_btnWiki2DB.Enabled = false;
            this.m_btnWiki2DB.Location = new System.Drawing.Point(723, 8);
            this.m_btnWiki2DB.Name = "m_btnWiki2DB";
            this.m_btnWiki2DB.Size = new System.Drawing.Size(89, 55);
            this.m_btnWiki2DB.TabIndex = 5;
            this.m_btnWiki2DB.Text = "维基数据写入到数据库（1-8阶）";
            this.m_btnWiki2DB.UseVisualStyleBackColor = true;
            this.m_btnWiki2DB.Click += new System.EventHandler(this.m_btnWiki2DB_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(103, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "维基数据路径：";
            // 
            // m_dataDir
            // 
            this.m_dataDir.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_dataDir.Location = new System.Drawing.Point(218, 4);
            this.m_dataDir.Name = "m_dataDir";
            this.m_dataDir.Size = new System.Drawing.Size(422, 26);
            this.m_dataDir.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(103, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "写入数据表：";
            // 
            // m_rb4
            // 
            this.m_rb4.AutoSize = true;
            this.m_rb4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_rb4.Location = new System.Drawing.Point(213, 30);
            this.m_rb4.Name = "m_rb4";
            this.m_rb4.Size = new System.Drawing.Size(98, 20);
            this.m_rb4.TabIndex = 9;
            this.m_rb4.TabStop = true;
            this.m_rb4.Text = "1阶关联词";
            this.m_rb4.UseVisualStyleBackColor = true;
            // 
            // m_rb5
            // 
            this.m_rb5.AutoSize = true;
            this.m_rb5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_rb5.Location = new System.Drawing.Point(305, 30);
            this.m_rb5.Name = "m_rb5";
            this.m_rb5.Size = new System.Drawing.Size(98, 20);
            this.m_rb5.TabIndex = 10;
            this.m_rb5.TabStop = true;
            this.m_rb5.Text = "2阶关联词";
            this.m_rb5.UseVisualStyleBackColor = true;
            // 
            // m_rb6
            // 
            this.m_rb6.AutoSize = true;
            this.m_rb6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_rb6.Location = new System.Drawing.Point(397, 30);
            this.m_rb6.Name = "m_rb6";
            this.m_rb6.Size = new System.Drawing.Size(98, 20);
            this.m_rb6.TabIndex = 11;
            this.m_rb6.TabStop = true;
            this.m_rb6.Text = "3阶关联词";
            this.m_rb6.UseVisualStyleBackColor = true;
            // 
            // m_rb7
            // 
            this.m_rb7.AutoSize = true;
            this.m_rb7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_rb7.Location = new System.Drawing.Point(495, 30);
            this.m_rb7.Name = "m_rb7";
            this.m_rb7.Size = new System.Drawing.Size(98, 20);
            this.m_rb7.TabIndex = 12;
            this.m_rb7.TabStop = true;
            this.m_rb7.Text = "7阶关联词";
            this.m_rb7.UseVisualStyleBackColor = true;
            // 
            // m_rb8
            // 
            this.m_rb8.AutoSize = true;
            this.m_rb8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_rb8.Location = new System.Drawing.Point(588, 30);
            this.m_rb8.Name = "m_rb8";
            this.m_rb8.Size = new System.Drawing.Size(98, 20);
            this.m_rb8.TabIndex = 13;
            this.m_rb8.TabStop = true;
            this.m_rb8.Text = "8阶关联词";
            this.m_rb8.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(103, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "写入进度：";
            // 
            // m_tbWriteInProgress
            // 
            this.m_tbWriteInProgress.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.m_tbWriteInProgress.Location = new System.Drawing.Point(211, 50);
            this.m_tbWriteInProgress.Name = "m_tbWriteInProgress";
            this.m_tbWriteInProgress.ReadOnly = true;
            this.m_tbWriteInProgress.Size = new System.Drawing.Size(429, 26);
            this.m_tbWriteInProgress.TabIndex = 15;
            // 
            // m_btnZhFileSplit
            // 
            this.m_btnZhFileSplit.Location = new System.Drawing.Point(39, 230);
            this.m_btnZhFileSplit.Name = "m_btnZhFileSplit";
            this.m_btnZhFileSplit.Size = new System.Drawing.Size(66, 41);
            this.m_btnZhFileSplit.TabIndex = 16;
            this.m_btnZhFileSplit.Text = "中文文件分词";
            this.m_btnZhFileSplit.UseVisualStyleBackColor = true;
            this.m_btnZhFileSplit.Click += new System.EventHandler(this.m_btnZhFileSplit_Click);
            // 
            // m_btnPKU2DB
            // 
            this.m_btnPKU2DB.Enabled = false;
            this.m_btnPKU2DB.Location = new System.Drawing.Point(723, 81);
            this.m_btnPKU2DB.Name = "m_btnPKU2DB";
            this.m_btnPKU2DB.Size = new System.Drawing.Size(89, 39);
            this.m_btnPKU2DB.TabIndex = 17;
            this.m_btnPKU2DB.Text = "PKU入库1-8阶";
            this.m_btnPKU2DB.UseVisualStyleBackColor = true;
            this.m_btnPKU2DB.Click += new System.EventHandler(this.m_btnPKU2DB_Click);
            // 
            // m_btnMSR2DB
            // 
            this.m_btnMSR2DB.Enabled = false;
            this.m_btnMSR2DB.Location = new System.Drawing.Point(723, 189);
            this.m_btnMSR2DB.Name = "m_btnMSR2DB";
            this.m_btnMSR2DB.Size = new System.Drawing.Size(89, 51);
            this.m_btnMSR2DB.TabIndex = 18;
            this.m_btnMSR2DB.Text = "MSR入库1-8阶";
            this.m_btnMSR2DB.UseVisualStyleBackColor = true;
            this.m_btnMSR2DB.Click += new System.EventHandler(this.m_btnMSR2DB_Click);
            // 
            // m_btnPkuTest2DB
            // 
            this.m_btnPkuTest2DB.Enabled = false;
            this.m_btnPkuTest2DB.Location = new System.Drawing.Point(723, 126);
            this.m_btnPkuTest2DB.Name = "m_btnPkuTest2DB";
            this.m_btnPkuTest2DB.Size = new System.Drawing.Size(89, 36);
            this.m_btnPkuTest2DB.TabIndex = 17;
            this.m_btnPkuTest2DB.Text = "PKUTest入库1-8阶";
            this.m_btnPkuTest2DB.UseVisualStyleBackColor = true;
            this.m_btnPkuTest2DB.Click += new System.EventHandler(this.m_btnPKUTest2DB_Click);
            // 
            // m_btnPKUMSRCWSMaster
            // 
            this.m_btnPKUMSRCWSMaster.Enabled = false;
            this.m_btnPKUMSRCWSMaster.Location = new System.Drawing.Point(723, 246);
            this.m_btnPKUMSRCWSMaster.Name = "m_btnPKUMSRCWSMaster";
            this.m_btnPKUMSRCWSMaster.Size = new System.Drawing.Size(89, 45);
            this.m_btnPKUMSRCWSMaster.TabIndex = 18;
            this.m_btnPKUMSRCWSMaster.Text = "PKUMSR1-8阶入库CWSMaster";
            this.m_btnPKUMSRCWSMaster.UseVisualStyleBackColor = true;
            this.m_btnPKUMSRCWSMaster.Click += new System.EventHandler(this.m_btnPKUMSRMaster2DB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(824, 400);
            this.Controls.Add(this.m_btnPKUMSRCWSMaster);
            this.Controls.Add(this.m_btnMSR2DB);
            this.Controls.Add(this.m_btnPkuTest2DB);
            this.Controls.Add(this.m_btnPKU2DB);
            this.Controls.Add(this.m_btnZhFileSplit);
            this.Controls.Add(this.m_tbWriteInProgress);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.m_rb8);
            this.Controls.Add(this.m_rb7);
            this.Controls.Add(this.m_rb6);
            this.Controls.Add(this.m_rb5);
            this.Controls.Add(this.m_rb4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.m_dataDir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.m_btnWiki2DB);
            this.Controls.Add(this.m_btnTest);
            this.Controls.Add(this.m_btnStaticWikiw);
            this.Controls.Add(this.m_btn8Split);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.m_btnCharStatics);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnCharStatics;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button m_btn8Split;
        private System.Windows.Forms.Button m_btnStaticWikiw;
        private System.Windows.Forms.Button m_btnTest;
        private System.Windows.Forms.Button m_btnWiki2DB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox m_dataDir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton m_rb4;
        private System.Windows.Forms.RadioButton m_rb5;
        private System.Windows.Forms.RadioButton m_rb6;
        private System.Windows.Forms.RadioButton m_rb7;
        private System.Windows.Forms.RadioButton m_rb8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox m_tbWriteInProgress;
        private System.Windows.Forms.Button m_btnZhFileSplit;
        private System.Windows.Forms.Button m_btnPKU2DB;
        private System.Windows.Forms.Button m_btnMSR2DB;
        private System.Windows.Forms.Button m_btnPkuTest2DB;
        private System.Windows.Forms.Button m_btnPKUMSRCWSMaster;
    }
}

