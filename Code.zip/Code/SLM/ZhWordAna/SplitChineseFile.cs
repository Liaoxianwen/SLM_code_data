﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

using System.IO;
using System.Windows.Forms;

namespace ZhWordAna
{
    public class SplitChineseFile
    {
        public SplitChineseFile(string sFileName)
        {
            m_sFileName = sFileName;
        }

        public void Split2ShortSents()
        {
            StreamReader sr = new StreamReader(m_sFileName);
            StreamWriter sw = new StreamWriter("短句_" + m_sFileName, false);

            int Cnt = 1;

            while (!sr.EndOfStream)
            {
                string sL = sr.ReadLine();

                string[] aRes = sL.Split(NatrualSp, StringSplitOptions.RemoveEmptyEntries);

                SplitSentsByNum_DateTime ssdt = new SplitSentsByNum_DateTime();

                int i = 0;
                int j = 0;

                for (i = 0; i < aRes.Length; ++i)
                {
                    List<RSplitRes> spres = ssdt.RSplit(aRes[i]);

                    for (j = 0; j < spres.Count; ++j)
                    {
                        sw.WriteLine(Cnt.ToString() + "__" + i.ToString()+"__"+j.ToString() + ">"+spres[j].GetType()+">:" + spres[j].m_str);
                    }

                }

                Cnt++;

            }

            sr.Close();
            sw.Close();

            sr.Dispose();
            sr.Dispose();
        }

        public void SplitFiles()
        {
            string str = "";

            TotalDictionary TDict = new TotalDictionary("TotalDicBase.txt");

            DBConn db = new DBConn();

            CalcProbCond cpc = new CalcProbCond(db, TDict.m_WordDic);

            CalcAvgLR_IE calrie_noUse = new CalcAvgLR_IE(db, TDict.m_WordDic);

            /*int[] PKUAssWordNum = {   1826471+172733, 
                                      1824546+172538, 
                                      1822621+172343, 
                                      1820696+172148, 
                                      1818771+171953, 
                                      1816846+171758, 
                                      1814921+171563, 
                                      1812996+171368 };
            cpc.UpdateWordNum(1925 + 195, PKUAssWordNum); 原始pku+原始 pkutest  */

            /*
            int[] PKUAssWordNum = {   5584568 +152265, 
                                      5573970 +150734, 
                                      5563372 +149203, 
                                      5552774 +147672, 
                                      5542176 +146141, 
                                      5531578 +144610, 
                                      5520980 +143079, 
                                      5510382 +141548 };
            cpc.UpdateWordNum(10598 + 1531, PKUAssWordNum);// cws pku msr train + puktest */


            int[] PKUAssWordNum = {   5584568 +160757, 
                                      5573970 +159118, 
                                      5563372 +157479, 
                                      5552774 +155840, 
                                      5542176 +154201, 
                                      5531578 +152562, 
                                      5520980 +150923, 
                                      5510382 +149284 };
            cpc.UpdateWordNum(10598 + 1639, PKUAssWordNum);// cws pku msr train + puktest 


            SplitSents sps = new SplitSents(cpc, str, calrie_noUse);

            //sps.doSplit(str);

            string sFile2Read = @"D:\C_Sharp_Proj\ViWordAna\pku\CWS-Master\msr\msr_train__shortSents4StatisticalSeg";//

            string sFile2save = @"CWSmsr_train__shortSents4StatisticalSeg_分词结果cwspkumsr目标函数概率和最大+词间校验.txt";
            string TmpFile = "tmp111111";
            string preTemp = TmpFile + "_presplit";
            
            //StreamWriter sw2 = new StreamWriter("短句_pku_trainingNEW_original_分词结果__02.txt", false);
            //StreamWriter sw3 = new StreamWriter("短句_pku_trainingNEW_original_分词结果__03.txt", false);

            SplitSentsByNum_DateTime ssbd = new SplitSentsByNum_DateTime();

            ssbd.PreSplit(sFile2Read, preTemp); // 正则 分词

            StreamReader sr = new StreamReader(preTemp);

            StreamWriter sw1 = new StreamWriter(TmpFile, false); // 目标临时文件


            List<string> Lst = new List<string>();


            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();
                Lst.Add(str);
            }

            Thread t1 = new Thread(() => DoSplit(Lst, sw1, sps));

            //t1.Start();

            DoSplit(Lst, sw1, sps);

            sr.Close();
            sr.Dispose();

            
            ssbd.RestorePresplitSents_From_RexpSplit(TmpFile, TmpFile + "_restore_from_Rexp_Presplit");

            ssbd.GenerateFinalFile(TmpFile + "_restore_from_Rexp_Presplit", sFile2save);

            File.Delete(TmpFile);
            File.Delete(preTemp);
            File.Delete(TmpFile + "_restore_from_Rexp_Presplit");

            MessageBox.Show("分词完成~！");

        }

        public void DoSplit(List<string> Lst, StreamWriter sw, SplitSents sps)
        {
            int i = 0;
            OptRes orTmp = new OptRes();
            bool isproc = true;

            for (i = 0; i < Lst.Count; ++i)
            {
                List<string> lst = SplitSents(Lst[i]);

                if (lst.Count != 2)
                {
                    continue;
                }
                lst[0] = ">>"+ i.ToString()+">>:"+lst[0];
                m_tbInfo.Text = lst[0];

                /*if (!lst[0].Equals("18742__8__0>NONE>:") && isproc)
                {
                    continue;
                }

                isproc = false;*/

                if (lst[0].IndexOf("REXP") > 0)
                {
                    orTmp.Write2FileREXP(sw, lst[1], lst[0]);
                }
                else
                {

                    CalcOptimalSplit cos = new CalcOptimalSplit(lst[1], sps);

                    // sps.m_cpc.m_DicProHasCalc.Clear(); //清除缓存！！

                    OptRes opres = cos.CalcOptimal();

                    opres.Write2File(sw, lst[1], lst[0]);
                }
            }

            sw.Close();
            sw.Dispose();
        }

        private List<string> SplitSents(string str)
        {
            List<string> Lrt = new List<string>();
            string sSp = ">:";

            int iPos = str.IndexOf(sSp);

            if (iPos <= 0)
            {
                Lrt.Add(str); // 针对没有 “>:”的情况 
                Lrt.Add(str);
                return Lrt;
            }

            Lrt.Add(str.Substring(0,iPos+sSp.Length));
            Lrt.Add(str.Substring(iPos + sSp.Length));

            return Lrt;
        }




        private string m_sFileName = null;

        private static string[] NatrualSp = { "。", "，", "、", "《", "》", "）", "（", "”", "“", "", "’", "‘", "』", "『", "？",
                                            "！","：","；","-"};

        public TextBox m_tbInfo = null;

    }
}
